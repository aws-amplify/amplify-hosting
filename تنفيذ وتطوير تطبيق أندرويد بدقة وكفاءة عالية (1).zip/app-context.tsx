import { createContext, useContext, useState, useEffect, useCallback, ReactNode } from "react";
import { Platform } from "react-native";
import {
  notifyInvoiceApproved,
  notifyInvoiceRejected,
  notifyInvoicePaid,
  scheduleDueSoonNotification,
} from "./notifications";
import {
  authStorage,
  vesselStorage,
  invoiceStorage,
  memoStorage,
  archiveStorage,
  notificationStorage,
  paymentStorage,
  pricingStorage,
  vesselFileStorage,
  usersStorage,
  invoiceItemStorage,
  invoiceReviewStorage,
  auditStorage,
  type AuthUser,
  type Vessel,
  type Invoice,
  type InvoiceItem,
  type InvoiceReview,
  type Memo,
  type Archive,
  type VesselFile,
  type Notification,
  type Payment,
  type PricingTable,
  type SystemUser,
  type AuditLog,
  ROLE_PERMISSIONS,
  hasPermission,
  type Permission,
} from "./storage";
import {
  defaultVessels,
  defaultInvoices,
  defaultMemos,
  defaultArchives,
  defaultNotifications,
  defaultPayments,
} from "./seed-data";

// Default users for authentication
const DEFAULT_USERS: SystemUser[] = [
  { id: 1, name: "مدير النظام - حبيب", email: "admin@habib.com", passwordHash: "admin123", role: "admin", isActive: true, permissions: [], createdAt: "2026-01-01T00:00:00Z", updatedAt: "2026-01-01T00:00:00Z" },
  { id: 2, name: "المحاسب", email: "accountant@habib.com", passwordHash: "acc123", role: "accountant", isActive: true, permissions: [], createdAt: "2026-01-01T00:00:00Z", updatedAt: "2026-01-01T00:00:00Z" },
  { id: 3, name: "المراجع", email: "reviewer@habib.com", passwordHash: "rev123", role: "reviewer", isActive: true, permissions: [], createdAt: "2026-01-01T00:00:00Z", updatedAt: "2026-01-01T00:00:00Z" },
  { id: 4, name: "مستخدم", email: "user@habib.com", passwordHash: "user123", role: "user", isActive: true, permissions: [], createdAt: "2026-01-01T00:00:00Z", updatedAt: "2026-01-01T00:00:00Z" },
  { id: 5, name: "عميل", email: "client@habib.com", passwordHash: "client123", role: "client", isActive: true, permissions: [], createdAt: "2026-01-01T00:00:00Z", updatedAt: "2026-01-01T00:00:00Z" },
];

const DEFAULT_PRICING: PricingTable = {
  exchangeRate: 250,
  lastUpdated: new Date().toISOString(),
  pilotageRates: [
    { code: "A001", grtMin: 0, grtMax: 200, ratePerHour: 0, ratePerTwoHours: 0 },
    { code: "A002", grtMin: 201, grtMax: 1000, ratePerHour: 325, ratePerTwoHours: 650 },
    { code: "A003", grtMin: 1001, grtMax: 5000, ratePerHour: 455, ratePerTwoHours: 910 },
    { code: "A004", grtMin: 5001, grtMax: 10000, ratePerHour: 357.5, ratePerTwoHours: 715 },
    { code: "A005", grtMin: 10001, grtMax: 15000, ratePerHour: 455, ratePerTwoHours: 910 },
    { code: "A006", grtMin: 15001, grtMax: 20000, ratePerHour: 552.5, ratePerTwoHours: 1105 },
    { code: "A007", grtMin: 20001, grtMax: 25000, ratePerHour: 650, ratePerTwoHours: 1300 },
    { code: "A008", grtMin: 25001, grtMax: 35000, ratePerHour: 845, ratePerTwoHours: 1690 },
    { code: "A009", grtMin: 35001, grtMax: 45000, ratePerHour: 975, ratePerTwoHours: 1950 },
    { code: "A010", grtMin: 45001, grtMax: -1, ratePerHour: 1040, ratePerTwoHours: 2080 },
  ],
  towageRates: [
    { grtMin: 0, grtMax: 200, rate: 390 },
    { grtMin: 201, grtMax: 1000, rate: 910 },
    { grtMin: 1001, grtMax: 5000, rate: 1300 },
    { grtMin: 5001, grtMax: 10000, rate: 1950 },
    { grtMin: 10001, grtMax: 15000, rate: 2600 },
    { grtMin: 15001, grtMax: 20000, rate: 3250 },
    { grtMin: 20001, grtMax: 25000, rate: 3900 },
    { grtMin: 25001, grtMax: 35000, rate: 4290 },
    { grtMin: 35001, grtMax: 45000, rate: 4550 },
    { grtMin: 45001, grtMax: -1, rate: 4550 },
  ],
  portFees: [
    { code: "F001", name: "رسم المخطاف", formula: "per_grt", rate: 1.95, unit: "لكل 100 GRT" },
    { code: "F002", name: "رسم الطن", formula: "per_nrt", rate: 0.104, unit: "لكل NRT" },
    { code: "F003", name: "المساعدات الملاحية", formula: "per_grt", rate: 7.8, unit: "لكل 100 GRT", minimum: 110.5 },
    { code: "F004", name: "رسم الميناء", formula: "per_grt", rate: 10.4, unit: "لكل 100 GRT", minimum: 149.5 },
    { code: "F005", name: "البقاء في الرصيف", formula: "per_length_hour", rate: 0.2, unit: "متر/ساعة" },
    { code: "F006", name: "البقاء في الحوض", formula: "per_grt_day", rate: 5.2, unit: "لكل 100 GRT/يوم" },
    { code: "F007", name: "الرباط وحل الرباط", formula: "per_grt", rate: 9.1, unit: "لكل 100 GRT" },
    { code: "F008", name: "تصريح المغادرة", formula: "fixed", rate: 39, unit: "لكل تصريح", minimum: 39 },
    { code: "F009", name: "أجر إشرافية", formula: "fixed", rate: 520, unit: "لكل زيارة", minimum: 520 },
    { code: "F010", name: "رسوم الحراسة", formula: "per_day", rate: 7.8, unit: "لكل يوم" },
    { code: "F011", name: "زوارق المواصلات", formula: "fixed", rate: 1500, unit: "لكل استخدام", minimum: 1500 },
    { code: "F012", name: "أجور انتظار المرشد", formula: "fixed", rate: 130, unit: "لكل انتظار" },
  ],
};

interface AppContextType {
  // Auth
  currentUser: AuthUser | null;
  isLoading: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  logout: () => Promise<void>;
  hasPermission: (permission: Permission) => boolean;

  // Vessels
  vessels: Vessel[];
  addVessel: (vessel: Omit<Vessel, "id" | "createdAt" | "updatedAt">) => Promise<void>;
  updateVessel: (id: number, updates: Partial<Vessel>) => Promise<void>;
  deleteVessel: (id: number) => Promise<void>;

  // Invoices
  invoices: Invoice[];
  addInvoice: (invoice: Omit<Invoice, "id" | "createdAt" | "updatedAt">) => Promise<void>;
  updateInvoice: (id: number, updates: Partial<Invoice>) => Promise<void>;
  deleteInvoice: (id: number) => Promise<void>;

  // Invoice Items
  invoiceItems: InvoiceItem[];
  addInvoiceItem: (item: Omit<InvoiceItem, "id">) => Promise<void>;
  updateInvoiceItem: (id: number, updates: Partial<InvoiceItem>) => Promise<void>;
  deleteInvoiceItem: (id: number) => Promise<void>;
  getInvoiceItems: (invoiceId: number) => InvoiceItem[];

  // Invoice Reviews
  invoiceReviews: InvoiceReview[];
  addInvoiceReview: (review: Omit<InvoiceReview, "id" | "createdAt">) => Promise<void>;
  updateInvoiceReview: (id: number, updates: Partial<InvoiceReview>) => Promise<void>;
  deleteInvoiceReview: (id: number) => Promise<void>;

  // Memos
  memos: Memo[];
  addMemo: (memo: Omit<Memo, "id" | "createdAt" | "updatedAt">) => Promise<void>;
  updateMemo: (id: number, updates: Partial<Memo>) => Promise<void>;
  deleteMemo: (id: number) => Promise<void>;

  // Archives
  archives: Archive[];
  addArchive: (archive: Omit<Archive, "id" | "createdAt">) => Promise<void>;
  deleteArchive: (id: number) => Promise<void>;

  // Vessel Files
  vesselFiles: VesselFile[];
  addVesselFile: (file: Omit<VesselFile, "id" | "createdAt" | "updatedAt">) => Promise<void>;
  updateVesselFile: (id: number, updates: Partial<VesselFile>) => Promise<void>;
  deleteVesselFile: (id: number) => Promise<void>;
  getVesselFiles: (vesselId: number) => VesselFile[];

  // Notifications
  notifications: Notification[];
  addNotification: (notification: Omit<Notification, "id" | "createdAt">) => Promise<void>;
  markNotificationRead: (id: number) => Promise<void>;
  markAllNotificationsRead: () => Promise<void>;
  unreadCount: number;

  // Payments
  payments: Payment[];
  addPayment: (payment: Omit<Payment, "id">) => Promise<void>;
  updatePayment: (id: number, updates: Partial<Payment>) => Promise<void>;

  // Pricing
  pricingTables: PricingTable;
  updatePricingTables: (updates: Partial<PricingTable>) => Promise<void>;

  // Users Management
  systemUsers: SystemUser[];
  addSystemUser: (user: Omit<SystemUser, "id" | "createdAt" | "updatedAt">) => Promise<void>;
  updateSystemUser: (id: number, updates: Partial<SystemUser>) => Promise<void>;
  deleteSystemUser: (id: number) => Promise<void>;

  // Audit Logs
  auditLogs: AuditLog[];
  addAuditLog: (log: Omit<AuditLog, "id" | "createdAt">) => Promise<void>;
}

const AppContext = createContext<AppContextType | null>(null);

export function AppProvider({ children }: { children: ReactNode }) {
  const [currentUser, setCurrentUser] = useState<AuthUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [vessels, setVessels] = useState<Vessel[]>([]);
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [invoiceItems, setInvoiceItems] = useState<InvoiceItem[]>([]);
  const [invoiceReviews, setInvoiceReviews] = useState<InvoiceReview[]>([]);
  const [memos, setMemos] = useState<Memo[]>([]);
  const [archives, setArchives] = useState<Archive[]>([]);
  const [vesselFiles, setVesselFiles] = useState<VesselFile[]>([]);
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [payments, setPayments] = useState<Payment[]>([]);
  const [pricingTables, setPricingTables] = useState<PricingTable>(DEFAULT_PRICING);
  const [systemUsers, setSystemUsers] = useState<SystemUser[]>(DEFAULT_USERS);
  const [auditLogs, setAuditLogs] = useState<AuditLog[]>([]);

  useEffect(() => {
    const init = async () => {
      try {
        const user = await authStorage.getUser();
        if (user) setCurrentUser(user);

        let storedVessels = await vesselStorage.getAll();
        if (!storedVessels || storedVessels.length === 0) {
          storedVessels = defaultVessels;
          await vesselStorage.setAll(storedVessels);
        }
        setVessels(storedVessels);

        let storedInvoices = await invoiceStorage.getAll();
        if (!storedInvoices || storedInvoices.length === 0) {
          storedInvoices = defaultInvoices;
          await invoiceStorage.setAll(storedInvoices);
        }
        setInvoices(storedInvoices);

        const storedItems = await invoiceItemStorage.getAll();
        if (storedItems) setInvoiceItems(storedItems);

        const storedReviews = await invoiceReviewStorage.getAll();
        if (storedReviews) setInvoiceReviews(storedReviews);

        let storedMemos = await memoStorage.getAll();
        if (!storedMemos || storedMemos.length === 0) {
          storedMemos = defaultMemos;
          await memoStorage.setAll(storedMemos);
        }
        setMemos(storedMemos);

        let storedArchives = await archiveStorage.getAll();
        if (!storedArchives || storedArchives.length === 0) {
          storedArchives = defaultArchives;
          await archiveStorage.setAll(storedArchives);
        }
        setArchives(storedArchives);

        const storedVesselFiles = await vesselFileStorage.getAll();
        if (storedVesselFiles) setVesselFiles(storedVesselFiles);

        let storedNotifications = await notificationStorage.getAll();
        if (!storedNotifications || storedNotifications.length === 0) {
          storedNotifications = defaultNotifications;
          await notificationStorage.setAll(storedNotifications);
        }
        setNotifications(storedNotifications);

        let storedPayments = await paymentStorage.getAll();
        if (!storedPayments || storedPayments.length === 0) {
          storedPayments = defaultPayments;
          await paymentStorage.setAll(storedPayments);
        }
        setPayments(storedPayments);

        const storedPricing = await pricingStorage.getAll();
        if (storedPricing) setPricingTables(storedPricing);

        const storedUsers = await usersStorage.getAll();
        if (storedUsers && storedUsers.length > 0) setSystemUsers(storedUsers);
        else await usersStorage.setAll(DEFAULT_USERS);

        const storedLogs = await auditStorage.getAll();
        if (storedLogs) setAuditLogs(storedLogs);
      } finally {
        setIsLoading(false);
      }
    };
    init();
  }, []);

  // Auth
  const login = useCallback(async (email: string, password: string): Promise<boolean> => {
    const allUsers = await usersStorage.getAll() || DEFAULT_USERS;
    const user = allUsers.find(
      (u) => (u.email === email || u.name === email) && u.passwordHash === password && u.isActive
    );
    if (user) {
      const authUser: AuthUser = {
        id: user.id,
        name: user.name,
        email: user.email,
        role: user.role,
        isActive: user.isActive,
        permissions: user.permissions,
        lastLogin: new Date().toISOString(),
      };
      await authStorage.setUser(authUser);
      setCurrentUser(authUser);
      return true;
    }
    return false;
  }, []);

  const logout = useCallback(async () => {
    await authStorage.clearUser();
    setCurrentUser(null);
  }, []);

  const checkPermission = useCallback((permission: Permission): boolean => {
    return hasPermission(currentUser, permission);
  }, [currentUser]);

  // Vessels
  const addVessel = useCallback(async (vessel: Omit<Vessel, "id" | "createdAt" | "updatedAt">) => {
    const newVessel: Vessel = { ...vessel, id: Date.now(), createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
    const updated = [...vessels, newVessel];
    setVessels(updated);
    await vesselStorage.setAll(updated);
  }, [vessels]);

  const updateVessel = useCallback(async (id: number, updates: Partial<Vessel>) => {
    const updated = vessels.map((v) => v.id === id ? { ...v, ...updates, updatedAt: new Date().toISOString() } : v);
    setVessels(updated);
    await vesselStorage.setAll(updated);
  }, [vessels]);

  const deleteVessel = useCallback(async (id: number) => {
    const updated = vessels.filter((v) => v.id !== id);
    setVessels(updated);
    await vesselStorage.setAll(updated);
  }, [vessels]);

  // Invoices
  const addInvoice = useCallback(async (invoice: Omit<Invoice, "id" | "createdAt" | "updatedAt">) => {
    const newInvoice: Invoice = { ...invoice, id: Date.now(), createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
    const updated = [...invoices, newInvoice];
    setInvoices(updated);
    await invoiceStorage.setAll(updated);
  }, [invoices]);

  const updateInvoice = useCallback(async (id: number, updates: Partial<Invoice>) => {
    const currentInvoice = invoices.find((inv) => inv.id === id);
    const updated = invoices.map((inv) => inv.id === id ? { ...inv, ...updates, updatedAt: new Date().toISOString() } : inv);
    setInvoices(updated);
    await invoiceStorage.setAll(updated);
    // إرسال إشعارات عند تغيير الحالة
    if (Platform.OS !== "web" && currentInvoice && updates.status && updates.status !== currentInvoice.status) {
      const updatedInvoice = { ...currentInvoice, ...updates };
      if (updates.status === "approved") {
        notifyInvoiceApproved(updatedInvoice).catch(console.error);
        scheduleDueSoonNotification(updatedInvoice, 3).catch(console.error);
      } else if (updates.status === "rejected") {
        notifyInvoiceRejected(updatedInvoice, updates.rejectedReason).catch(console.error);
      } else if (updates.status === "paid") {
        notifyInvoicePaid(updatedInvoice).catch(console.error);
      }
    }
  }, [invoices]);

  const deleteInvoice = useCallback(async (id: number) => {
    const updated = invoices.filter((inv) => inv.id !== id);
    setInvoices(updated);
    await invoiceStorage.setAll(updated);
  }, [invoices]);

  // Invoice Items
  const addInvoiceItem = useCallback(async (item: Omit<InvoiceItem, "id">) => {
    const newItem: InvoiceItem = { ...item, id: Date.now() };
    const updated = [...invoiceItems, newItem];
    setInvoiceItems(updated);
    await invoiceItemStorage.setAll(updated);
  }, [invoiceItems]);

  const updateInvoiceItem = useCallback(async (id: number, updates: Partial<InvoiceItem>) => {
    const updated = invoiceItems.map((item) => item.id === id ? { ...item, ...updates } : item);
    setInvoiceItems(updated);
    await invoiceItemStorage.setAll(updated);
  }, [invoiceItems]);

  const deleteInvoiceItem = useCallback(async (id: number) => {
    const updated = invoiceItems.filter((item) => item.id !== id);
    setInvoiceItems(updated);
    await invoiceItemStorage.setAll(updated);
  }, [invoiceItems]);

  const getInvoiceItems = useCallback((invoiceId: number): InvoiceItem[] => {
    return invoiceItems.filter((item) => item.invoiceId === invoiceId);
  }, [invoiceItems]);

  // Invoice Reviews
  const addInvoiceReview = useCallback(async (review: Omit<InvoiceReview, "id" | "createdAt">) => {
    const newReview: InvoiceReview = { ...review, id: Date.now(), createdAt: new Date().toISOString() };
    const updated = [...invoiceReviews, newReview];
    setInvoiceReviews(updated);
    await invoiceReviewStorage.setAll(updated);
  }, [invoiceReviews]);

  const updateInvoiceReview = useCallback(async (id: number, updates: Partial<InvoiceReview>) => {
    const updated = invoiceReviews.map((r) => r.id === id ? { ...r, ...updates } : r);
    setInvoiceReviews(updated);
    await invoiceReviewStorage.setAll(updated);
  }, [invoiceReviews]);

  const deleteInvoiceReview = useCallback(async (id: number) => {
    const updated = invoiceReviews.filter((r) => r.id !== id);
    setInvoiceReviews(updated);
    await invoiceReviewStorage.setAll(updated);
  }, [invoiceReviews]);

  // Memos
  const addMemo = useCallback(async (memo: Omit<Memo, "id" | "createdAt" | "updatedAt">) => {
    const newMemo: Memo = { ...memo, id: Date.now(), createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
    const updated = [...memos, newMemo];
    setMemos(updated);
    await memoStorage.setAll(updated);
  }, [memos]);

  const updateMemo = useCallback(async (id: number, updates: Partial<Memo>) => {
    const updated = memos.map((m) => m.id === id ? { ...m, ...updates, updatedAt: new Date().toISOString() } : m);
    setMemos(updated);
    await memoStorage.setAll(updated);
  }, [memos]);

  const deleteMemo = useCallback(async (id: number) => {
    const updated = memos.filter((m) => m.id !== id);
    setMemos(updated);
    await memoStorage.setAll(updated);
  }, [memos]);

  // Archives
  const addArchive = useCallback(async (archive: Omit<Archive, "id" | "createdAt">) => {
    const newArchive: Archive = { ...archive, id: Date.now(), createdAt: new Date().toISOString() };
    const updated = [...archives, newArchive];
    setArchives(updated);
    await archiveStorage.setAll(updated);
  }, [archives]);

  const deleteArchive = useCallback(async (id: number) => {
    const updated = archives.filter((a) => a.id !== id);
    setArchives(updated);
    await archiveStorage.setAll(updated);
  }, [archives]);

  // Vessel Files
  const addVesselFile = useCallback(async (file: Omit<VesselFile, "id" | "createdAt" | "updatedAt">) => {
    const newFile: VesselFile = { ...file, id: Date.now(), createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
    const updated = [...vesselFiles, newFile];
    setVesselFiles(updated);
    await vesselFileStorage.setAll(updated);
  }, [vesselFiles]);

  const updateVesselFile = useCallback(async (id: number, updates: Partial<VesselFile>) => {
    const updated = vesselFiles.map((f) => f.id === id ? { ...f, ...updates, updatedAt: new Date().toISOString() } : f);
    setVesselFiles(updated);
    await vesselFileStorage.setAll(updated);
  }, [vesselFiles]);

  const deleteVesselFile = useCallback(async (id: number) => {
    const updated = vesselFiles.filter((f) => f.id !== id);
    setVesselFiles(updated);
    await vesselFileStorage.setAll(updated);
  }, [vesselFiles]);

  const getVesselFiles = useCallback((vesselId: number): VesselFile[] => {
    return vesselFiles.filter((f) => f.vesselId === vesselId);
  }, [vesselFiles]);

  // Notifications
  const addNotification = useCallback(async (notification: Omit<Notification, "id" | "createdAt">) => {
    const newNotif: Notification = { ...notification, id: Date.now(), createdAt: new Date().toISOString() };
    const updated = [newNotif, ...notifications];
    setNotifications(updated);
    await notificationStorage.setAll(updated);
  }, [notifications]);

  const markNotificationRead = useCallback(async (id: number) => {
    const updated = notifications.map((n) => n.id === id ? { ...n, isRead: true } : n);
    setNotifications(updated);
    await notificationStorage.setAll(updated);
  }, [notifications]);

  const markAllNotificationsRead = useCallback(async () => {
    const updated = notifications.map((n) => ({ ...n, isRead: true }));
    setNotifications(updated);
    await notificationStorage.setAll(updated);
  }, [notifications]);

  const unreadCount = notifications.filter((n) => !n.isRead).length;

  // Payments
  const addPayment = useCallback(async (payment: Omit<Payment, "id">) => {
    const newPayment: Payment = { ...payment, id: Date.now() };
    const updated = [...payments, newPayment];
    setPayments(updated);
    await paymentStorage.setAll(updated);
  }, [payments]);

  const updatePayment = useCallback(async (id: number, updates: Partial<Payment>) => {
    const updated = payments.map((p) => p.id === id ? { ...p, ...updates } : p);
    setPayments(updated);
    await paymentStorage.setAll(updated);
  }, [payments]);

  // Pricing
  const updatePricingTables = useCallback(async (updates: Partial<PricingTable>) => {
    const updated = { ...pricingTables, ...updates, lastUpdated: new Date().toISOString() };
    setPricingTables(updated);
    await pricingStorage.setAll(updated);
  }, [pricingTables]);

  // System Users
  const addSystemUser = useCallback(async (user: Omit<SystemUser, "id" | "createdAt" | "updatedAt">) => {
    const newUser: SystemUser = { ...user, id: Date.now(), createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() };
    const updated = [...systemUsers, newUser];
    setSystemUsers(updated);
    await usersStorage.setAll(updated);
  }, [systemUsers]);

  const updateSystemUser = useCallback(async (id: number, updates: Partial<SystemUser>) => {
    const updated = systemUsers.map((u) => u.id === id ? { ...u, ...updates, updatedAt: new Date().toISOString() } : u);
    setSystemUsers(updated);
    await usersStorage.setAll(updated);
  }, [systemUsers]);

  const deleteSystemUser = useCallback(async (id: number) => {
    const updated = systemUsers.filter((u) => u.id !== id);
    setSystemUsers(updated);
    await usersStorage.setAll(updated);
  }, [systemUsers]);

  // Audit Logs
  const addAuditLog = useCallback(async (log: Omit<AuditLog, "id" | "createdAt">) => {
    const newLog: AuditLog = { ...log, id: Date.now(), createdAt: new Date().toISOString() };
    const updated = [newLog, ...auditLogs].slice(0, 500); // Keep last 500
    setAuditLogs(updated);
    await auditStorage.setAll(updated);
  }, [auditLogs]);

  return (
    <AppContext.Provider
      value={{
        currentUser,
        isLoading,
        login,
        logout,
        hasPermission: checkPermission,
        vessels,
        addVessel,
        updateVessel,
        deleteVessel,
        invoices,
        addInvoice,
        updateInvoice,
        deleteInvoice,
        invoiceItems,
        addInvoiceItem,
        updateInvoiceItem,
        deleteInvoiceItem,
        getInvoiceItems,
        invoiceReviews,
        addInvoiceReview,
        updateInvoiceReview,
        deleteInvoiceReview,
        memos,
        addMemo,
        updateMemo,
        deleteMemo,
        archives,
        addArchive,
        deleteArchive,
        vesselFiles,
        addVesselFile,
        updateVesselFile,
        deleteVesselFile,
        getVesselFiles,
        notifications,
        addNotification,
        markNotificationRead,
        markAllNotificationsRead,
        unreadCount,
        payments,
        addPayment,
        updatePayment,
        pricingTables,
        updatePricingTables,
        systemUsers,
        addSystemUser,
        updateSystemUser,
        deleteSystemUser,
        auditLogs,
        addAuditLog,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp() {
  const ctx = useContext(AppContext);
  if (!ctx) throw new Error("useApp must be used within AppProvider");
  return ctx;
}
