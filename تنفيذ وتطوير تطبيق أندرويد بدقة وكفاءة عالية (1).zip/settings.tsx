import { useState } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  Switch,
  Alert,
  FlatList,
} from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useApp } from "@/lib/app-context";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

type Tab = "notifications" | "users" | "settings";

// ─── Notifications Tab ────────────────────────────────────────────────────────
function NotificationsTab() {
  const { notifications, markNotificationRead, markAllNotificationsRead, unreadCount } = useApp();

  const typeColors: Record<string, string> = {
    info: "#2E86AB",
    warning: "#F39C12",
    error: "#E74C3C",
    success: "#27AE60",
  };
  const typeIcons: Record<string, string> = {
    info: "info",
    warning: "warning",
    error: "error",
    success: "check-circle",
  };

  return (
    <View style={{ flex: 1 }}>
      {unreadCount > 0 && (
        <View style={{ backgroundColor: "white", paddingHorizontal: 16, paddingVertical: 10, flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", borderBottomWidth: 1, borderBottomColor: "#F0F4F8" }}>
          <Text style={{ fontSize: 14, color: "#6B7C93" }}>{unreadCount} إشعار غير مقروء</Text>
          <TouchableOpacity onPress={markAllNotificationsRead} style={{ backgroundColor: "#EBF2FA", borderRadius: 8, paddingHorizontal: 12, paddingVertical: 6 }}>
            <Text style={{ color: "#1E3A5F", fontSize: 13, fontWeight: "600" }}>تمييز الكل كمقروء</Text>
          </TouchableOpacity>
        </View>
      )}
      <FlatList
        data={notifications.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime())}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => markNotificationRead(item.id)}
            style={{
              backgroundColor: item.isRead ? "white" : "#EBF2FA",
              borderRadius: 14,
              padding: 14,
              marginHorizontal: 16,
              marginBottom: 10,
              flexDirection: "row-reverse",
              gap: 12,
              shadowColor: "#000",
              shadowOffset: { width: 0, height: 1 },
              shadowOpacity: 0.05,
              shadowRadius: 4,
              elevation: 2,
            }}
          >
            <View style={{
              width: 44,
              height: 44,
              borderRadius: 12,
              backgroundColor: (typeColors[item.type] || "#6B7C93") + "20",
              alignItems: "center",
              justifyContent: "center",
              flexShrink: 0,
            }}>
              <MaterialIcons name={(typeIcons[item.type] || "notifications") as any} size={22} color={typeColors[item.type] || "#6B7C93"} />
            </View>
            <View style={{ flex: 1 }}>
              <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" }}>
                <Text style={{ fontSize: 14, fontWeight: item.isRead ? "600" : "800", color: "#1A2332" }}>{item.title}</Text>
                {!item.isRead && (
                  <View style={{ width: 8, height: 8, borderRadius: 4, backgroundColor: "#1E3A5F" }} />
                )}
              </View>
              <Text style={{ fontSize: 13, color: "#6B7C93", marginTop: 3 }}>{item.message}</Text>
              <Text style={{ fontSize: 11, color: "#9BA1A6", marginTop: 4 }}>
                {new Date(item.createdAt).toLocaleDateString("ar-SA")} - {new Date(item.createdAt).toLocaleTimeString("ar-SA", { hour: "2-digit", minute: "2-digit" })}
              </Text>
            </View>
          </TouchableOpacity>
        )}
        contentContainerStyle={{ paddingTop: 12, paddingBottom: 20 }}
        ListEmptyComponent={
          <View style={{ alignItems: "center", paddingVertical: 60 }}>
            <MaterialIcons name="notifications-none" size={60} color="#D1DCE8" />
            <Text style={{ color: "#6B7C93", fontSize: 16, marginTop: 16 }}>لا توجد إشعارات</Text>
          </View>
        }
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

// ─── Users Tab ────────────────────────────────────────────────────────────────
const MOCK_USERS = [
  { id: 1, name: "مدير النظام", email: "admin@habib.com", role: "admin", isActive: true, lastLogin: "2026-02-25" },
  { id: 2, name: "المحاسب", email: "accountant@habib.com", role: "accountant", isActive: true, lastLogin: "2026-02-24" },
  { id: 3, name: "المراجع", email: "reviewer@habib.com", role: "reviewer", isActive: true, lastLogin: "2026-02-23" },
  { id: 4, name: "مستخدم عادي", email: "user@habib.com", role: "user", isActive: false, lastLogin: "2026-02-20" },
  { id: 5, name: "عميل", email: "client@habib.com", role: "client", isActive: true, lastLogin: "2026-02-22" },
];

const ROLE_LABELS: Record<string, string> = {
  admin: "مدير النظام",
  accountant: "محاسب",
  reviewer: "مراجع",
  user: "مستخدم",
  client: "عميل",
};
const ROLE_COLORS: Record<string, string> = {
  admin: "#1E3A5F",
  accountant: "#27AE60",
  reviewer: "#F39C12",
  user: "#6B7C93",
  client: "#9B59B6",
};

function UsersTab() {
  const { currentUser } = useApp();
  const isAdmin = currentUser?.role === "admin";

  if (!isAdmin) {
    return (
      <View style={{ flex: 1, alignItems: "center", justifyContent: "center", padding: 40 }}>
        <MaterialIcons name="lock" size={60} color="#D1DCE8" />
        <Text style={{ color: "#6B7C93", fontSize: 16, marginTop: 16, textAlign: "center" }}>
          هذا القسم متاح للمدير فقط
        </Text>
      </View>
    );
  }

  return (
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16 }}>
      <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
        <Text style={{ fontSize: 16, fontWeight: "700", color: "#1A2332" }}>المستخدمون ({MOCK_USERS.length})</Text>
        <TouchableOpacity
          onPress={() => Alert.alert("إضافة مستخدم", "ستتوفر هذه الميزة قريباً")}
          style={{ backgroundColor: "#1E3A5F", borderRadius: 10, paddingHorizontal: 14, paddingVertical: 8, flexDirection: "row-reverse", alignItems: "center", gap: 4 }}
        >
          <MaterialIcons name="add" size={18} color="white" />
          <Text style={{ color: "white", fontSize: 13, fontWeight: "700" }}>إضافة</Text>
        </TouchableOpacity>
      </View>

      {MOCK_USERS.map((user) => (
        <View key={user.id} style={{ backgroundColor: "white", borderRadius: 14, padding: 14, marginBottom: 10, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
          <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" }}>
            <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 12 }}>
              <View style={{ width: 44, height: 44, borderRadius: 22, backgroundColor: ROLE_COLORS[user.role] + "20", alignItems: "center", justifyContent: "center" }}>
                <MaterialIcons name="person" size={22} color={ROLE_COLORS[user.role]} />
              </View>
              <View>
                <Text style={{ fontSize: 14, fontWeight: "700", color: "#1A2332" }}>{user.name}</Text>
                <Text style={{ fontSize: 12, color: "#6B7C93" }}>{user.email}</Text>
                <Text style={{ fontSize: 11, color: "#9BA1A6", marginTop: 2 }}>آخر دخول: {user.lastLogin}</Text>
              </View>
            </View>
            <View style={{ alignItems: "flex-end", gap: 6 }}>
              <View style={{ backgroundColor: ROLE_COLORS[user.role] + "20", borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 }}>
                <Text style={{ color: ROLE_COLORS[user.role], fontSize: 11, fontWeight: "700" }}>{ROLE_LABELS[user.role]}</Text>
              </View>
              <View style={{ backgroundColor: user.isActive ? "#EAFAF1" : "#F0F4F8", borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 }}>
                <Text style={{ color: user.isActive ? "#27AE60" : "#6B7C93", fontSize: 11, fontWeight: "600" }}>
                  {user.isActive ? "نشط" : "غير نشط"}
                </Text>
              </View>
            </View>
          </View>
        </View>
      ))}

      {/* Audit Log */}
      <Text style={{ fontSize: 16, fontWeight: "700", color: "#1A2332", textAlign: "right", marginTop: 8, marginBottom: 12 }}>
        سجل العمليات الأخيرة
      </Text>
      {[
        { action: "تسجيل دخول", user: "مدير النظام", time: "منذ 5 دقائق", icon: "login" },
        { action: "إنشاء فاتورة INV-2026-005", user: "المحاسب", time: "منذ 30 دقيقة", icon: "description" },
        { action: "تحديث بيانات سفينة SEA FALCON", user: "مدير النظام", time: "منذ ساعة", icon: "edit" },
        { action: "إرسال مذكرة", user: "المحاسب", time: "منذ 2 ساعة", icon: "send" },
      ].map((log, i) => (
        <View key={i} style={{ backgroundColor: "white", borderRadius: 12, padding: 12, marginBottom: 8, flexDirection: "row-reverse", alignItems: "center", gap: 10 }}>
          <View style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: "#EBF2FA", alignItems: "center", justifyContent: "center" }}>
            <MaterialIcons name={log.icon as any} size={18} color="#1E3A5F" />
          </View>
          <View style={{ flex: 1 }}>
            <Text style={{ fontSize: 13, fontWeight: "600", color: "#1A2332" }}>{log.action}</Text>
            <Text style={{ fontSize: 12, color: "#6B7C93" }}>{log.user} - {log.time}</Text>
          </View>
        </View>
      ))}
    </ScrollView>
  );
}

// ─── Settings Tab ─────────────────────────────────────────────────────────────
function SettingsTab() {
  const { currentUser, logout } = useApp();
  const router = useRouter();
  const [darkMode, setDarkMode] = useState(false);
  const [notifications, setNotifications] = useState(true);
  const [autoBackup, setAutoBackup] = useState(true);

  const handleLogout = () => {
    Alert.alert(
      "تسجيل الخروج",
      "هل أنت متأكد من تسجيل الخروج؟",
      [
        { text: "إلغاء", style: "cancel" },
        {
          text: "تسجيل الخروج",
          style: "destructive",
          onPress: async () => {
            await logout();
            router.replace("/login");
          },
        },
      ]
    );
  };

  return (
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16 }}>
      {/* Profile Card */}
      <View style={{ backgroundColor: "#1E3A5F", borderRadius: 16, padding: 20, marginBottom: 20 }}>
        <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 14 }}>
          <View style={{ width: 60, height: 60, borderRadius: 30, backgroundColor: "rgba(255,255,255,0.2)", alignItems: "center", justifyContent: "center" }}>
            <MaterialIcons name="person" size={30} color="white" />
          </View>
          <View>
            <Text style={{ color: "white", fontSize: 18, fontWeight: "700" }}>{currentUser?.name}</Text>
            <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 13 }}>{currentUser?.email}</Text>
            <View style={{ backgroundColor: "rgba(255,255,255,0.2)", borderRadius: 8, paddingHorizontal: 10, paddingVertical: 3, marginTop: 4, alignSelf: "flex-start" }}>
              <Text style={{ color: "white", fontSize: 12, fontWeight: "600" }}>
                {currentUser?.role === "admin" ? "مدير النظام" : currentUser?.role === "accountant" ? "محاسب" : currentUser?.role === "reviewer" ? "مراجع" : "مستخدم"}
              </Text>
            </View>
          </View>
        </View>
      </View>

      {/* App Settings */}
      <Text style={{ fontSize: 15, fontWeight: "700", color: "#6B7C93", textAlign: "right", marginBottom: 10 }}>إعدادات التطبيق</Text>
      <View style={{ backgroundColor: "white", borderRadius: 16, marginBottom: 20, overflow: "hidden", shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
        {[
          { label: "الوضع الليلي", icon: "dark-mode", value: darkMode, onChange: setDarkMode },
          { label: "الإشعارات", icon: "notifications", value: notifications, onChange: setNotifications },
          { label: "النسخ الاحتياطي التلقائي", icon: "backup", value: autoBackup, onChange: setAutoBackup },
        ].map((setting, i, arr) => (
          <View key={setting.label} style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: i < arr.length - 1 ? 1 : 0, borderBottomColor: "#F0F4F8" }}>
            <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 12 }}>
              <View style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: "#EBF2FA", alignItems: "center", justifyContent: "center" }}>
                <MaterialIcons name={setting.icon as any} size={18} color="#1E3A5F" />
              </View>
              <Text style={{ fontSize: 15, color: "#1A2332", fontWeight: "500" }}>{setting.label}</Text>
            </View>
            <Switch
              value={setting.value}
              onValueChange={setting.onChange}
              trackColor={{ false: "#D1DCE8", true: "#1E3A5F" }}
              thumbColor="white"
            />
          </View>
        ))}
      </View>

      {/* Quick Links */}
      <Text style={{ fontSize: 15, fontWeight: "700", color: "#6B7C93", textAlign: "right", marginBottom: 10 }}>الوصول السريع</Text>
      <View style={{ backgroundColor: "white", borderRadius: 16, marginBottom: 20, overflow: "hidden", shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
        {[
          { label: "نظام الأسعار والرسوم", icon: "calculate", route: "/pricing" },
          { label: "مراجعة الفواتير الخارجية", icon: "rate-review", route: "/review" },
          { label: "إدارة المستخدمين والصلاحيات", icon: "manage-accounts", route: "/users" },
          { label: "الأرشيف الشامل", icon: "folder", route: "/archive" },
        ].map((link, i, arr) => (
          <TouchableOpacity
            key={link.label}
            onPress={() => router.push(link.route as any)}
            style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: i < arr.length - 1 ? 1 : 0, borderBottomColor: "#F0F4F8" }}
          >
            <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 12 }}>
              <View style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: "#EBF2FA", alignItems: "center", justifyContent: "center" }}>
                <MaterialIcons name={link.icon as any} size={18} color="#1E3A5F" />
              </View>
              <Text style={{ fontSize: 15, color: "#1A2332", fontWeight: "500" }}>{link.label}</Text>
            </View>
            <MaterialIcons name="chevron-left" size={20} color="#9BA1A6" />
          </TouchableOpacity>
        ))}
      </View>

      {/* System Info */}
      <Text style={{ fontSize: 15, fontWeight: "700", color: "#6B7C93", textAlign: "right", marginBottom: 10 }}>معلومات النظام</Text>
      <View style={{ backgroundColor: "white", borderRadius: 16, marginBottom: 20, overflow: "hidden", shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
        {[
          { label: "إصدار التطبيق", value: "2.0.0", icon: "info" },
          { label: "اسم النظام", value: "نظام حبيب", icon: "anchor" },
          { label: "المطوّر", value: "حبيب", icon: "person" },
          { label: "قاعدة البيانات", value: "محلية آمنة", icon: "storage" },
          { label: "اللغة", value: "العربية (RTL)", icon: "language" },
        ].map((info, i, arr) => (
          <View key={info.label} style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", paddingHorizontal: 16, paddingVertical: 14, borderBottomWidth: i < arr.length - 1 ? 1 : 0, borderBottomColor: "#F0F4F8" }}>
            <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 12 }}>
              <View style={{ width: 36, height: 36, borderRadius: 10, backgroundColor: "#F0F4F8", alignItems: "center", justifyContent: "center" }}>
                <MaterialIcons name={info.icon as any} size={18} color="#6B7C93" />
              </View>
              <Text style={{ fontSize: 15, color: "#1A2332", fontWeight: "500" }}>{info.label}</Text>
            </View>
            <Text style={{ fontSize: 14, color: "#6B7C93" }}>{info.value}</Text>
          </View>
        ))}
      </View>

      {/* Logout */}
      <TouchableOpacity
        onPress={handleLogout}
        style={{ backgroundColor: "#FDEDEC", borderRadius: 14, paddingVertical: 16, alignItems: "center", flexDirection: "row-reverse", justifyContent: "center", gap: 8, marginBottom: 20 }}
      >
        <MaterialIcons name="logout" size={20} color="#E74C3C" />
        <Text style={{ color: "#E74C3C", fontSize: 16, fontWeight: "700" }}>تسجيل الخروج</Text>
      </TouchableOpacity>
    </ScrollView>
  );
}

// ─── Main Screen ──────────────────────────────────────────────────────────────
export default function SettingsScreen() {
  const [activeTab, setActiveTab] = useState<Tab>("notifications");
  const { unreadCount } = useApp();

  const tabs: { key: Tab; label: string; icon: string }[] = [
    { key: "notifications", label: "الإشعارات", icon: "notifications" },
    { key: "users", label: "المستخدمون", icon: "group" },
    { key: "settings", label: "الإعدادات", icon: "settings" },
  ];

  return (
    <ScreenContainer containerClassName="bg-background">
      {/* Header */}
      <View style={{ backgroundColor: "#1E3A5F", paddingHorizontal: 20, paddingTop: 16, paddingBottom: 16 }}>
        <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" }}>
          <Text style={{ color: "white", fontSize: 22, fontWeight: "800" }}>
            {tabs.find((t) => t.key === activeTab)?.label}
          </Text>
          {unreadCount > 0 && activeTab === "notifications" && (
            <View style={{ backgroundColor: "#E74C3C", borderRadius: 12, paddingHorizontal: 10, paddingVertical: 4 }}>
              <Text style={{ color: "white", fontSize: 13, fontWeight: "700" }}>{unreadCount}</Text>
            </View>
          )}
        </View>
      </View>

      {/* Tab Bar */}
      <View style={{ backgroundColor: "white", flexDirection: "row-reverse", paddingHorizontal: 8, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: "#F0F4F8" }}>
        {tabs.map((tab) => (
          <TouchableOpacity
            key={tab.key}
            onPress={() => setActiveTab(tab.key)}
            style={{
              flex: 1,
              alignItems: "center",
              paddingVertical: 8,
              borderRadius: 10,
              backgroundColor: activeTab === tab.key ? "#EBF2FA" : "transparent",
              gap: 3,
              position: "relative",
            }}
          >
            <View style={{ position: "relative" }}>
              <MaterialIcons name={tab.icon as any} size={20} color={activeTab === tab.key ? "#1E3A5F" : "#6B7C93"} />
              {tab.key === "notifications" && unreadCount > 0 && (
                <View style={{ position: "absolute", top: -4, right: -4, backgroundColor: "#E74C3C", borderRadius: 6, minWidth: 12, height: 12, alignItems: "center", justifyContent: "center" }}>
                  <Text style={{ color: "white", fontSize: 8, fontWeight: "700" }}>{unreadCount}</Text>
                </View>
              )}
            </View>
            <Text style={{ fontSize: 11, fontWeight: "600", color: activeTab === tab.key ? "#1E3A5F" : "#6B7C93" }}>
              {tab.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Content */}
      <View style={{ flex: 1 }}>
        {activeTab === "notifications" && <NotificationsTab />}
        {activeTab === "users" && <UsersTab />}
        {activeTab === "settings" && <SettingsTab />}
      </View>
    </ScreenContainer>
  );
}
