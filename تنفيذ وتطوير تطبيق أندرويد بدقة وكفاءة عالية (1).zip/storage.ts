};

// Pricing Tables
export const pricingStorage = {
  getAll: () => getItem<PricingTable>(KEYS.PRICING_TABLES),
  setAll: (tables: PricingTable) => setItem(KEYS.PRICING_TABLES, tables),
};

// Vessel Files
export const vesselFileStorage = {
  getAll: () => getItem<VesselFile[]>(KEYS.VESSEL_FILES),
  setAll: (files: VesselFile[]) => setItem(KEYS.VESSEL_FILES, files),
};

// Users
export const usersStorage = {
  getAll: () => getItem<SystemUser[]>(KEYS.USERS),
  setAll: (users: SystemUser[]) => setItem(KEYS.USERS, users),
};

// Exchange Rate
export const exchangeRateStorage = {
  get: () => getItem<number>(KEYS.EXCHANGE_RATE),
  set: (rate: number) => setItem(KEYS.EXCHANGE_RATE, rate),
};

// Audit Logs
export const auditStorage = {
  getAll: () => getItem<AuditLog[]>(KEYS.AUDIT_LOGS),
  setAll: (logs: AuditLog[]) => setItem(KEYS.AUDIT_LOGS, logs),
};

// ==================== TYPES ====================

export interface AuthUser {
  id: number;
  name: string;
  email: string;
  role: "admin" | "accountant" | "reviewer" | "user" | "client";
  isActive: boolean;
  permissions?: string[];
  lastLogin?: string;
}

export interface SystemUser {
  id: number;
  name: string;
  email: string;
  passwordHash: string;
  role: "admin" | "accountant" | "reviewer" | "user" | "client";
  isActive: boolean;
  permissions: string[];
  createdAt: string;
  updatedAt: string;
  lastLogin?: string;
}

export interface Vessel {
  id: number;
  name: string;
  type: string;
  imoNumber?: string;
  callSign?: string;
  grt?: number;
  nrt?: number;
  length?: number;
  flag?: string;
  owner?: string;
  agent?: string;
  captain?: string;
  arrivalDate?: string;
  departureDate?: string;
  status: "active" | "inactive" | "maintenance" | "docked";
  notes?: string;
  createdAt: string;
  updatedAt: string;
}

export interface Invoice {
  id: number;
  invoiceNumber: string;
  vesselId: number;
  vesselName?: string;
  vesselGrt?: number;
  vesselNrt?: number;
  vesselLength?: number;
  arrivalDate?: string;
  departureDate?: string;
  daysCount?: number;
  hoursCount?: number;
  totalHours?: number;
  amount: number;
  currency: string;
  amountLocal?: number;
  exchangeRate?: number;
  externalInvoiceAmount?: number;
  discrepancy?: number;
  description?: string;
  status: "draft" | "pending" | "approved" | "rejected" | "paid" | "overdue";
  issuedDate: string;
  dueDate?: string;
  paidDate?: string;
  approvedBy?: string;
  approvedAt?: string;
  rejectedBy?: string;
  rejectedReason?: string;
  notes?: string;
  attachmentUri?: string;
  attachmentName?: string;
  createdAt: string;
  updatedAt: string;
  createdBy?: string;
}

// بنود الفاتورة التفصيلية
export interface InvoiceItem {
  id: number;
  invoiceId: number;
  itemCode: string;
  itemName: string;
  formula?: string;
  quantity?: number;
  unit?: string;
  unitPrice: number;
  totalUSD: number;
  totalYER?: number;
  externalValue?: number;
  difference?: number;
  notes?: string;
}

// مراجعة الفاتورة الخارجية
export interface InvoiceReview {
  id: number;
  reviewNumber: string;
  vesselId: number;
  vesselName?: string;
  invoiceId?: number;
  externalInvoiceRef?: string;
  externalAmount: number;
  calculatedAmount: number;
  difference: number;
  differencePercent?: number;
  status: "pending" | "completed" | "disputed";
  reviewDate: string;
  reviewedBy?: string;
  findings?: string;
  recommendations?: string;
  items: InvoiceReviewItem[];
  archivedAt?: string;
  createdAt: string;
}

export interface InvoiceReviewItem {
  itemName: string;
  externalValue: number;
  calculatedValue: number;
  difference: number;
  notes?: string;
}

export interface Memo {
  id: number;
  vesselId?: number;
  vesselName?: string;
  title: string;
  content: string;
  recipientEntity?: string;
  recipientAddress?: string;
  subject?: string;
  memoType: "communication" | "complaint" | "inquiry" | "notification" | "port" | "customs" | "agent" | "company";
  status: "draft" | "sent" | "archived";
  sentDate?: string;
  sentBy?: string;
  archivedAt?: string;
  createdAt: string;
  updatedAt: string;
  createdBy?: string;
}

export interface Archive {
  id: number;
  referenceType: "invoice" | "memo" | "vessel" | "document" | "review" | "file";
  referenceId?: number;
  title: string;
  description?: string;
  fileUri?: string;
  fileUrl?: string;
  fileName?: string;
  fileType?: string;
  fileSize?: number;
  tags?: string;
  category?: string;
  vesselId?: number;
  vesselName?: string;
  archivedBy: string;
  createdAt: string;
}

export interface VesselFile {
  id: number;
  vesselId: number;
  vesselName?: string;
  fileType: "certificate" | "permit" | "report" | "contract" | "other";
  title: string;
  description?: string;
  fileUri?: string;
  fileName?: string;
  fileSize?: number;
  issuedDate?: string;
  expiryDate?: string;
  issuedBy?: string;
  status: "valid" | "expired" | "pending";
  createdAt: string;
  updatedAt: string;
}

export interface Notification {
  id: number;
  title: string;
  message: string;
  type: "info" | "warning" | "error" | "success";
  priority: "low" | "medium" | "high" | "critical";
  isRead: boolean;
  relatedType?: string;
  relatedId?: number;
  createdAt: string;
}

export interface Payment {
  id: number;
  invoiceId?: number;
  invoiceNumber: string;
  vesselName?: string;
  amount: number;
  currency: string;
  amountLocal?: number;
  status: "completed" | "pending" | "failed" | "refunded";
  method: string;
  reference: string;
  bankName?: string;
  date: string;
  notes?: string;
  receivedBy?: string;
}

export interface AuditLog {
  id: number;
  userId: number;
  userName: string;