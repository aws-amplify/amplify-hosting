import { ScrollView, Text, TouchableOpacity, View, Share } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useApp } from "@/lib/app-context";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

const PILOTAGE_DEFAULT_COUNT = 10;
const TOWAGE_DEFAULT_COUNT = 10;
const FEES_DEFAULT_COUNT = 16;

export default function PricingReportScreen() {
  const router = useRouter();
  const { pricingTables, invoices, vessels } = useApp();

  const pilotageRates = pricingTables?.pilotageRates || [];
  const towageRates = pricingTables?.towageRates || [];
  const portFees = pricingTables?.portFees || [];
  const exchangeRate = pricingTables?.exchangeRate || 250;

  // إحصائيات الفواتير حسب الرسوم
  const totalInvoices = invoices?.length || 0;
  const paidInvoices = invoices?.filter((i) => i.status === "paid") || [];
  const totalRevenue = paidInvoices.reduce((s, i) => s + (i.amount || 0), 0);

  const handleShare = async () => {
    let report = "تقرير جداول الأسعار - نظام حبيب\n";
    report += "================================\n\n";
    report += `تاريخ التقرير: ${new Date().toLocaleDateString("ar-YE")}\n`;
    report += `سعر الصرف: 1$ = ${exchangeRate} ريال\n\n`;

    report += "جدول الإرشاد:\n";
    report += `عدد البنود: ${pilotageRates.length}\n`;
    pilotageRates.forEach((r) => {
      const range = r.grtMax === -1 ? `>${r.grtMin.toLocaleString()}` : `${r.grtMin.toLocaleString()}-${r.grtMax.toLocaleString()}`;
      report += `  ${r.code}: GRT ${range} | $${r.ratePerHour}/ساعة\n`;
    });

    report += "\nجدول القطر:\n";
    report += `عدد البنود: ${towageRates.length}\n`;
    towageRates.forEach((r) => {
      const range = r.grtMax === -1 ? `>${r.grtMin.toLocaleString()}` : `${r.grtMin.toLocaleString()}-${r.grtMax.toLocaleString()}`;
      report += `  GRT ${range} | $${r.rate}\n`;
    });

    report += "\nجدول الرسوم:\n";
    report += `عدد البنود: ${portFees.length}\n`;
    portFees.forEach((f) => {
      report += `  ${f.code}: ${f.name} | $${f.rate} ${f.unit}\n`;
    });

    report += `\n================================\n`;
    report += `إجمالي الفواتير: ${totalInvoices}\n`;
    report += `إجمالي الإيرادات المحصلة: $${totalRevenue.toLocaleString()}\n`;

    await Share.share({ message: report, title: "تقرير جداول الأسعار" });
  };

  const StatCard = ({ title, value, subtitle, color }: { title: string; value: string; subtitle: string; color: string }) => (
    <View style={{ flex: 1, backgroundColor: "white", borderRadius: 14, padding: 14, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
      <Text style={{ fontSize: 12, color: "#6B7C93", textAlign: "right", marginBottom: 4 }}>{title}</Text>
      <Text style={{ fontSize: 22, fontWeight: "800", color, textAlign: "right" }}>{value}</Text>
      <Text style={{ fontSize: 11, color: "#9BA1A6", textAlign: "right", marginTop: 2 }}>{subtitle}</Text>
    </View>
  );

  return (
    <ScreenContainer containerClassName="bg-background">
      {/* Header */}
      <View style={{ backgroundColor: "#1E3A5F", paddingHorizontal: 20, paddingTop: 16, paddingBottom: 20 }}>
        <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" }}>
          <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10 }}>
            <View style={{ width: 42, height: 42, borderRadius: 12, backgroundColor: "rgba(255,255,255,0.15)", alignItems: "center", justifyContent: "center" }}>
              <MaterialIcons name="assessment" size={22} color="white" />
            </View>
            <View>
              <Text style={{ color: "white", fontSize: 18, fontWeight: "800" }}>تقرير الأسعار</Text>
              <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 12 }}>ملخص جداول الأسعار والإحصائيات</Text>
            </View>
          </View>
          <View style={{ flexDirection: "row-reverse", gap: 8 }}>
            <TouchableOpacity onPress={handleShare} style={{ width: 38, height: 38, borderRadius: 10, backgroundColor: "rgba(39,174,96,0.3)", alignItems: "center", justifyContent: "center" }}>
              <MaterialIcons name="share" size={20} color="white" />
            </TouchableOpacity>
            <TouchableOpacity onPress={() => router.back()} style={{ width: 38, height: 38, borderRadius: 10, backgroundColor: "rgba(255,255,255,0.15)", alignItems: "center", justifyContent: "center" }}>
              <MaterialIcons name="arrow-forward" size={22} color="white" />
            </TouchableOpacity>
          </View>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>

        {/* إحصائيات عامة */}
        <Text style={{ fontSize: 15, fontWeight: "800", color: "#1A2332", textAlign: "right", marginBottom: 12 }}>إحصائيات الجداول</Text>
        <View style={{ flexDirection: "row-reverse", gap: 10, marginBottom: 16 }}>
          <StatCard title="بنود الإرشاد" value={String(pilotageRates.length || PILOTAGE_DEFAULT_COUNT)} subtitle="نطاق GRT" color="#1E3A5F" />
          <StatCard title="بنود القطر" value={String(towageRates.length || TOWAGE_DEFAULT_COUNT)} subtitle="نطاق GRT" color="#8E44AD" />
          <StatCard title="بنود الرسوم" value={String(portFees.length || FEES_DEFAULT_COUNT)} subtitle="رسم وأجر" color="#E67E22" />
        </View>

        {/* سعر الصرف */}
        <View style={{ backgroundColor: "#EBF4FF", borderRadius: 14, padding: 16, marginBottom: 16, flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between" }}>
          <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10 }}>
            <View style={{ width: 40, height: 40, borderRadius: 10, backgroundColor: "#1E3A5F", alignItems: "center", justifyContent: "center" }}>
              <MaterialIcons name="currency-exchange" size={20} color="white" />
            </View>
            <View>
              <Text style={{ fontSize: 13, color: "#6B7C93" }}>سعر الصرف الحالي</Text>
              <Text style={{ fontSize: 18, fontWeight: "800", color: "#1E3A5F" }}>1$ = {exchangeRate} ريال</Text>
            </View>
          </View>
          <TouchableOpacity onPress={() => router.push("/pricing")} style={{ backgroundColor: "#1E3A5F", borderRadius: 10, paddingHorizontal: 14, paddingVertical: 8 }}>
            <Text style={{ color: "white", fontSize: 12, fontWeight: "700" }}>تعديل</Text>
          </TouchableOpacity>
        </View>

        {/* إحصائيات الفواتير */}
        <Text style={{ fontSize: 15, fontWeight: "800", color: "#1A2332", textAlign: "right", marginBottom: 12 }}>إحصائيات الفواتير</Text>
        <View style={{ flexDirection: "row-reverse", gap: 10, marginBottom: 16 }}>
          <StatCard title="إجمالي الفواتير" value={String(totalInvoices)} subtitle="فاتورة" color="#2980B9" />
          <StatCard title="الإيرادات المحصلة" value={`$${totalRevenue.toLocaleString()}`} subtitle="فواتير مدفوعة" color="#27AE60" />
        </View>

        {/* ملخص جدول الإرشاد */}
        <Text style={{ fontSize: 15, fontWeight: "800", color: "#1A2332", textAlign: "right", marginBottom: 10 }}>ملخص جدول الإرشاد</Text>
        <View style={{ backgroundColor: "white", borderRadius: 14, overflow: "hidden", marginBottom: 16, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
          <View style={{ flexDirection: "row-reverse", backgroundColor: "#1E3A5F", padding: 10 }}>
            {["الكود", "نطاق GRT", "$/ساعة"].map((h, i) => (
              <Text key={i} style={{ flex: 1, color: "white", fontSize: 11, fontWeight: "700", textAlign: "center" }}>{h}</Text>
            ))}
          </View>
          {(pilotageRates.length > 0 ? pilotageRates : []).slice(0, 5).map((r, idx) => (
            <View key={idx} style={{ flexDirection: "row-reverse", padding: 10, borderBottomWidth: 1, borderBottomColor: "#F0F4F8", backgroundColor: idx % 2 === 0 ? "white" : "#F8FAFC" }}>
              <Text style={{ flex: 1, textAlign: "center", fontSize: 11, fontWeight: "700", color: "#1E3A5F" }}>{r.code}</Text>
              <Text style={{ flex: 1, textAlign: "center", fontSize: 11, color: "#1A2332" }}>
                {r.grtMax === -1 ? `>${r.grtMin.toLocaleString()}` : `${r.grtMin.toLocaleString()}-${r.grtMax.toLocaleString()}`}
              </Text>
              <Text style={{ flex: 1, textAlign: "center", fontSize: 11, color: "#27AE60", fontWeight: "600" }}>{r.ratePerHour}</Text>
            </View>
          ))}
          {pilotageRates.length > 5 && (
            <View style={{ padding: 10, alignItems: "center" }}>
              <Text style={{ fontSize: 12, color: "#6B7C93" }}>... و {pilotageRates.length - 5} بنود أخرى</Text>
            </View>
          )}
        </View>

        {/* ملخص جدول الرسوم */}
        <Text style={{ fontSize: 15, fontWeight: "800", color: "#1A2332", textAlign: "right", marginBottom: 10 }}>أعلى الرسوم قيمةً</Text>
        <View style={{ backgroundColor: "white", borderRadius: 14, overflow: "hidden", marginBottom: 16, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
          {[...portFees].sort((a, b) => b.rate - a.rate).slice(0, 5).map((fee, idx) => (
            <View key={idx} style={{ flexDirection: "row-reverse", justifyContent: "space-between", padding: 14, borderBottomWidth: idx < 4 ? 1 : 0, borderBottomColor: "#F0F4F8", alignItems: "center" }}>
              <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 8 }}>
                <View style={{ width: 28, height: 28, borderRadius: 8, backgroundColor: "#EBF4FF", alignItems: "center", justifyContent: "center" }}>
                  <Text style={{ fontSize: 10, color: "#1E3A5F", fontWeight: "700" }}>{idx + 1}</Text>
                </View>
                <Text style={{ fontSize: 13, color: "#1A2332", fontWeight: "600" }}>{fee.name}</Text>
              </View>
              <Text style={{ fontSize: 14, fontWeight: "800", color: "#27AE60" }}>${fee.rate.toLocaleString()}</Text>
            </View>
          ))}
        </View>

        {/* زر الانتقال لجداول الأسعار */}
        <TouchableOpacity
          onPress={() => router.push("/pricing")}
          style={{ backgroundColor: "#1E3A5F", borderRadius: 14, paddingVertical: 16, alignItems: "center", flexDirection: "row-reverse", justifyContent: "center", gap: 8 }}
        >
          <MaterialIcons name="price-change" size={20} color="white" />
          <Text style={{ color: "white", fontSize: 15, fontWeight: "700" }}>إدارة جداول الأسعار</Text>
        </TouchableOpacity>
      </ScrollView>
    </ScreenContainer>
  );
}
