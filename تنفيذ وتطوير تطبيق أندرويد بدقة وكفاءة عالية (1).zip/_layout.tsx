import { Tabs } from "expo-router";
import { useSafeAreaInsets } from "react-native-safe-area-context";
import { HapticTab } from "@/components/haptic-tab";
import { IconSymbol } from "@/components/ui/icon-symbol";
import { Platform, View, Text } from "react-native";
import { useColors } from "@/hooks/use-colors";
import { useApp } from "@/lib/app-context";

export default function TabLayout() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const { unreadCount } = useApp();
  const bottomPadding = Platform.OS === "web" ? 12 : Math.max(insets.bottom, 8);
  const tabBarHeight = 60 + bottomPadding;

  return (
    <Tabs
      screenOptions={{
        tabBarActiveTintColor: "#1E3A5F",
        tabBarInactiveTintColor: "#9BA1A6",
        headerShown: false,
        tabBarButton: HapticTab,
        tabBarStyle: {
          paddingTop: 8,
          paddingBottom: bottomPadding,
          height: tabBarHeight,
          backgroundColor: "#FFFFFF",
          borderTopColor: "#E5E7EB",
          borderTopWidth: 0.5,
          shadowColor: "#000",
          shadowOffset: { width: 0, height: -2 },
          shadowOpacity: 0.06,
          shadowRadius: 8,
          elevation: 8,
        },
        tabBarLabelStyle: {
          fontSize: 11,
          fontWeight: "600",
          marginTop: 2,
        },
      }}
    >
      <Tabs.Screen
        name="index"
        options={{
          title: "الرئيسية",
          tabBarIcon: ({ color, focused }) => (
            <IconSymbol size={26} name="house.fill" color={focused ? "#1E3A5F" : "#9BA1A6"} />
          ),
        }}
      />
      <Tabs.Screen
        name="vessels"
        options={{
          title: "السفن",
          tabBarIcon: ({ color, focused }) => (
            <IconSymbol size={26} name="vessel.fill" color={focused ? "#1E3A5F" : "#9BA1A6"} />
          ),
        }}
      />
      <Tabs.Screen
        name="invoices"
        options={{
          title: "الفواتير",
          tabBarIcon: ({ color, focused }) => (
            <IconSymbol size={26} name="invoice.fill" color={focused ? "#1E3A5F" : "#9BA1A6"} />
          ),
        }}
      />
      <Tabs.Screen
        name="reports"
        options={{
          title: "التقارير",
          tabBarIcon: ({ color, focused }) => (
            <IconSymbol size={26} name="reports.fill" color={focused ? "#1E3A5F" : "#9BA1A6"} />
          ),
        }}
      />
      <Tabs.Screen
        name="settings"
        options={{
          title: "الإعدادات",
          tabBarIcon: ({ color, focused }) => (
            <View>
              <IconSymbol size={26} name="settings.fill" color={focused ? "#1E3A5F" : "#9BA1A6"} />
              {unreadCount > 0 && (
                <View style={{
                  position: "absolute",
                  top: -4,
                  right: -6,
                  backgroundColor: "#E74C3C",
                  borderRadius: 8,
                  minWidth: 16,
                  height: 16,
                  alignItems: "center",
                  justifyContent: "center",
                  paddingHorizontal: 3,
                }}>
                  <Text style={{ color: "white", fontSize: 9, fontWeight: "800" }}>
                    {unreadCount > 99 ? "99+" : unreadCount}
                  </Text>
                </View>
              )}
            </View>
          ),
        }}
      />
    </Tabs>
  );
}
