import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import Home from "@/pages/Home";
import Invoices from "@/pages/Invoices";
import Vessels from "@/pages/Vessels";
import Memos from "@/pages/Memos";
import Archives from "@/pages/Archives";
import Reports from "@/pages/Reports";
import ClientLogin from "@/pages/ClientLogin";
import ClientDashboard from "@/pages/ClientDashboard";
import AdvancedReports from "@/pages/AdvancedReports";
import SmartNotifications from "@/pages/SmartNotifications";
import PaymentManagement from "@/pages/PaymentManagement";
import FinancialReports from "@/pages/FinancialReports";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";

function Router() {
  return (
    <Switch>
      <Route path={"/"} component={Home} />
      <Route path={"/invoices"} component={Invoices} />
      <Route path={"/vessels"} component={Vessels} />
      <Route path={"/memos"} component={Memos} />
      <Route path={"/archives"} component={Archives} />
      <Route path={"/reports"} component={Reports} />
      <Route path={"/client/login"} component={ClientLogin} />
      <Route path={"/client/dashboard"} component={ClientDashboard} />
      <Route path={"/advanced-reports"} component={AdvancedReports} />
      <Route path={"/notifications"} component={SmartNotifications} />
      <Route path={"/payments"} component={PaymentManagement} />
      <Route path={"/financial-reports"} component={FinancialReports} />
      <Route path={"/404"} component={NotFound} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider
        defaultTheme="light"
      >
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
