          { key: "all", label: `الكل (${invoices.length})` },
          { key: "pending", label: "معلق" },
          { key: "overdue", label: "متأخر" },
          { key: "paid", label: "مدفوع" },
          { key: "approved", label: "موافق عليه" },
          { key: "draft", label: "مسودة" },
        ].map((tab) => (
          <TouchableOpacity
            key={tab.key}
            onPress={() => setFilterStatus(tab.key)}
            style={{
              backgroundColor: filterStatus === tab.key ? "#1E3A5F" : "#F0F4F8",
              borderRadius: 10,
              paddingHorizontal: 14,
              paddingVertical: 6,
            }}
          >
            <Text style={{
              color: filterStatus === tab.key ? "white" : "#6B7C93",
              fontSize: 13,
              fontWeight: "600",
            }}>{tab.label}</Text>
          </TouchableOpacity>
        ))}
      </ScrollView>

      {/* Invoices List */}
      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <InvoiceCard
            invoice={item}
            onPress={() => router.push(`/invoice/${item.id}` as any)}
            onDelete={() => handleDelete(item)}
          />
        )}
        contentContainerStyle={{ padding: 16 }}
        ListEmptyComponent={
          <View style={{ alignItems: "center", paddingVertical: 60 }}>
            <MaterialIcons name="description" size={60} color="#D1DCE8" />
            <Text style={{ color: "#6B7C93", fontSize: 16, marginTop: 16 }}>لا توجد فواتير</Text>
          </View>
        }
        showsVerticalScrollIndicator={false}
      />

      <AddInvoiceModal
        visible={showAddModal}
        onClose={() => setShowAddModal(false)}
        onAdd={addInvoice}
      />
    </ScreenContainer>
  );
}
