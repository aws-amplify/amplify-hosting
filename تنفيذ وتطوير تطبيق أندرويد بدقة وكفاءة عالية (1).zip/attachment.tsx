import { View, Text, ScrollView, TouchableOpacity, TextInput, Alert, Modal } from "react-native";
import { useRouter, useLocalSearchParams } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useApp } from "@/lib/app-context";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useState, useMemo } from "react";
import * as DocumentPicker from "expo-document-picker";
import { InvoiceItem } from "@/lib/storage";

const SERVICE_ITEMS = [
  { code: "P001", name: "رسوم الإرشاد - دخول", category: "إرشاد" },
  { code: "P002", name: "رسوم الإرشاد - خروج", category: "إرشاد" },
  { code: "P003", name: "رسوم القطر - دخول", category: "قطر" },
  { code: "P004", name: "رسوم القطر - خروج", category: "قطر" },
  { code: "F001", name: "رسم المخطاف", category: "رسوم ميناء" },
  { code: "F002", name: "رسم الطن", category: "رسوم ميناء" },
  { code: "F003", name: "المساعدات الملاحية", category: "رسوم ميناء" },
  { code: "F004", name: "رسم الميناء", category: "رسوم ميناء" },
  { code: "F005", name: "البقاء في الرصيف", category: "رسوم ميناء" },
  { code: "F006", name: "البقاء في الحوض", category: "رسوم ميناء" },
  { code: "F007", name: "الرباط وحل الرباط", category: "رسوم ميناء" },
  { code: "F008", name: "تصريح المغادرة", category: "رسوم ميناء" },
  { code: "F009", name: "أجر إشرافية", category: "رسوم ميناء" },
  { code: "F010", name: "رسوم الحراسة", category: "رسوم ميناء" },
  { code: "F011", name: "زوارق المواصلات", category: "رسوم ميناء" },
  { code: "F012", name: "أجور انتظار المرشد", category: "رسوم ميناء" },
  { code: "X001", name: "خدمات أخرى", category: "متنوع" },
];

export default function InvoiceAttachmentScreen() {
  const router = useRouter();
  const params = useLocalSearchParams();
  const invoiceId = parseInt(String(params.id));
  const { invoices, invoiceItems, addInvoiceItem, updateInvoiceItem, deleteInvoiceItem, getInvoiceItems, addArchive, currentUser, pricingTables } = useApp();

  const invoice = invoices.find((inv) => inv.id === invoiceId);
  const items = getInvoiceItems(invoiceId);

  const [showAddItem, setShowAddItem] = useState(false);
  const [editingItem, setEditingItem] = useState<InvoiceItem | null>(null);
  const [pickedFile, setPickedFile] = useState<{ name: string; uri: string; size?: number } | null>(null);

  // Item form
  const [serviceCode, setServiceCode] = useState("");
  const [serviceName, setServiceName] = useState("");
  const [quantity, setQuantity] = useState("1");
  const [unitPrice, setUnitPrice] = useState("");
  const [unit, setUnit] = useState("وحدة");
  const [notes, setNotes] = useState("");
  const [category, setCategory] = useState("");
  const [formula, setFormula] = useState("");

  const totalAmount = useMemo(() => {
    return items.reduce((sum, item) => sum + item.totalUSD, 0);
  }, [items]);

  const exchangeRate = pricingTables?.exchangeRate || 250;

  const openAddItem = () => {
    setEditingItem(null);
    setServiceCode(""); setServiceName(""); setQuantity("1"); setUnitPrice(""); setUnit("وحدة"); setNotes(""); setCategory("");
    setShowAddItem(true);
  };

  const openEditItem = (item: InvoiceItem) => {
    setEditingItem(item);
    setServiceCode(item.itemCode || "");
    setServiceName(item.itemName);
    setQuantity(String(item.quantity || 1));
    setUnitPrice(String(item.unitPrice));
    setUnit(item.unit || "وحدة");
    setNotes(item.notes || "");
    setCategory("");
    setFormula(item.formula || "");
    setShowAddItem(true);
  };

  const selectService = (service: typeof SERVICE_ITEMS[0]) => {
    setServiceCode(service.code);
    setServiceName(service.name);
    setCategory(service.category);
    setFormula("");
  };

  const handleSaveItem = async () => {
    if (!serviceName.trim()) {
      Alert.alert("خطأ", "يرجى إدخال اسم الخدمة");
      return;
    }
    const qty = parseFloat(quantity) || 1;
    const price = parseFloat(unitPrice) || 0;
    const total = qty * price;

    if (editingItem) {
      await updateInvoiceItem(editingItem.id, {
        itemCode: serviceCode.trim() || editingItem.itemCode,
        itemName: serviceName.trim(),
        quantity: qty,
        unitPrice: price,
        totalUSD: total,
        totalYER: total * exchangeRate,
        unit: unit.trim(),
        notes: notes.trim() || undefined,
        formula: formula.trim() || undefined,
      });
    } else {
      await addInvoiceItem({
        invoiceId,
        itemCode: serviceCode.trim() || "X001",
        itemName: serviceName.trim(),
        quantity: qty,
        unitPrice: price,
        totalUSD: total,
        totalYER: total * exchangeRate,
        unit: unit.trim(),
        notes: notes.trim() || undefined,
        formula: formula.trim() || undefined,
      });
    }
    setShowAddItem(false);
  };

  const handleDeleteItem = (item: InvoiceItem) => {
    Alert.alert("تأكيد", `حذف "${item.itemName}"?`, [
      { text: "إلغاء", style: "cancel" },
      { text: "حذف", style: "destructive", onPress: () => deleteInvoiceItem(item.id) },
    ]);
  };

  const pickDocument = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({ type: "*/*", copyToCacheDirectory: true });
      if (!result.canceled && result.assets?.[0]) {
        const asset = result.assets[0];
        setPickedFile({ name: asset.name, uri: asset.uri, size: asset.size });
        await addArchive({
          referenceType: "invoice",
          referenceId: invoiceId,
          title: `مرفق فاتورة: ${invoice?.invoiceNumber} - ${asset.name}`,
          description: `مرفق للفاتورة رقم ${invoice?.invoiceNumber}`,
          category: "فواتير",
          vesselId: invoice?.vesselId || undefined,
          vesselName: invoice?.vesselName,
          fileName: asset.name,
          fileUri: asset.uri,
          fileSize: asset.size,
          archivedBy: currentUser?.name || "النظام",
          tags: "مرفق فاتورة",
        });
        Alert.alert("نجاح", "تم رفع المرفق وحفظه في الأرشيف");
      }
    } catch {
      Alert.alert("خطأ", "تعذر رفع الملف");
    }
  };

  const groupedItems = useMemo(() => {
    const groups: Record<string, InvoiceItem[]> = {};
    items.forEach((item) => {
      const cat = item.formula || "خدمات";
      if (!groups[cat]) groups[cat] = [];
      groups[cat].push(item);
    });
    return groups;
  }, [items]);

  if (!invoice) {
    return (
      <ScreenContainer>
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <Text style={{ color: "#E74C3C", fontSize: 16 }}>الفاتورة غير موجودة</Text>
        </View>
      </ScreenContainer>
    );
  }

  return (
    <ScreenContainer containerClassName="bg-background">
      {/* Header */}
      <View style={{ backgroundColor: "#1E3A5F", paddingHorizontal: 20, paddingTop: 16, paddingBottom: 20 }}>
        <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" }}>
          <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10 }}>
            <View style={{ width: 42, height: 42, borderRadius: 12, backgroundColor: "rgba(255,255,255,0.15)", alignItems: "center", justifyContent: "center" }}>
              <MaterialIcons name="attach-file" size={22} color="white" />
            </View>
            <View>
              <Text style={{ color: "white", fontSize: 16, fontWeight: "800" }}>مرفق الفاتورة</Text>
              <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 12 }}>{invoice.invoiceNumber} • {invoice.vesselName}</Text>
            </View>
          </View>
          <TouchableOpacity onPress={() => router.back()} style={{ width: 38, height: 38, borderRadius: 10, backgroundColor: "rgba(255,255,255,0.15)", alignItems: "center", justifyContent: "center" }}>
            <MaterialIcons name="arrow-forward" size={22} color="white" />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16 }}>
        {/* Invoice Summary */}
        <View style={{ backgroundColor: "#1E3A5F", borderRadius: 16, padding: 16, marginBottom: 16 }}>
          <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 12, textAlign: "right" }}>إجمالي الفاتورة</Text>
          <Text style={{ color: "white", fontSize: 28, fontWeight: "800", textAlign: "right", marginTop: 4 }}>
            {totalAmount.toLocaleString("ar-SA")} ر.ي
          </Text>
          <Text style={{ color: "rgba(255,255,255,0.6)", fontSize: 13, textAlign: "right", marginTop: 2 }}>
            ≈ {(totalAmount / exchangeRate).toLocaleString("ar-SA", { maximumFractionDigits: 2 })} USD
          </Text>
          <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", marginTop: 12, paddingTop: 12, borderTopWidth: 1, borderTopColor: "rgba(255,255,255,0.2)" }}>
            <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 12 }}>{items.length} بند</Text>
            <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 12 }}>سعر الصرف: {exchangeRate} ر.ي/USD</Text>
          </View>
        </View>

        {/* Action Buttons */}
        <View style={{ flexDirection: "row-reverse", gap: 10, marginBottom: 16 }}>
          <TouchableOpacity
            onPress={openAddItem}
            style={{ flex: 1, backgroundColor: "#27AE60", borderRadius: 12, paddingVertical: 12, alignItems: "center", flexDirection: "row-reverse", justifyContent: "center", gap: 6 }}
          >
            <MaterialIcons name="add-circle" size={18} color="white" />
            <Text style={{ color: "white", fontSize: 13, fontWeight: "700" }}>إضافة بند</Text>
          </TouchableOpacity>
          <TouchableOpacity
            onPress={pickDocument}
            style={{ flex: 1, backgroundColor: "#3498DB", borderRadius: 12, paddingVertical: 12, alignItems: "center", flexDirection: "row-reverse", justifyContent: "center", gap: 6 }}
          >
            <MaterialIcons name="upload-file" size={18} color="white" />
            <Text style={{ color: "white", fontSize: 13, fontWeight: "700" }}>رفع مستند</Text>
          </TouchableOpacity>
        </View>

        {/* Items by Category */}
        {Object.entries(groupedItems).map(([cat, catItems]) => (
          <View key={cat} style={{ marginBottom: 12 }}>
            <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 8, marginBottom: 8 }}>
              <View style={{ flex: 1, height: 1, backgroundColor: "#E5E7EB" }} />
              <Text style={{ fontSize: 12, color: "#6B7C93", fontWeight: "700" }}>{cat}</Text>
            </View>
              {catItems.map((item) => (
              <View key={item.id} style={{ backgroundColor: "white", borderRadius: 12, padding: 14, marginBottom: 8, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 3, elevation: 1 }}>
                <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "flex-start" }}>
                  <View style={{ flex: 1 }}>
                    <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 6 }}>
                      {item.itemCode && (
                        <View style={{ backgroundColor: "#EBF4FF", borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 }}>
                          <Text style={{ fontSize: 10, color: "#1E3A5F", fontWeight: "700" }}>{item.itemCode}</Text>
                        </View>
                      )}
                      <Text style={{ fontSize: 14, fontWeight: "700", color: "#1A2332" }}>{item.itemName}</Text>
                    </View>
                    <View style={{ flexDirection: "row-reverse", gap: 16, marginTop: 8 }}>
                      <View style={{ alignItems: "center" }}>
                        <Text style={{ fontSize: 10, color: "#9BA1A6" }}>الكمية</Text>
                        <Text style={{ fontSize: 13, fontWeight: "600", color: "#1A2332" }}>{item.quantity || 1} {item.unit}</Text>
                      </View>
                      <View style={{ alignItems: "center" }}>
                        <Text style={{ fontSize: 10, color: "#9BA1A6" }}>سعر الوحدة</Text>
                        <Text style={{ fontSize: 13, fontWeight: "600", color: "#1A2332" }}>{item.unitPrice.toLocaleString("ar-SA")}</Text>
                      </View>
                      <View style={{ alignItems: "center" }}>
                        <Text style={{ fontSize: 10, color: "#9BA1A6" }}>الإجمالي</Text>
                        <Text style={{ fontSize: 13, fontWeight: "700", color: "#27AE60" }}>{item.totalUSD.toLocaleString("ar-SA")}</Text>
                      </View>
                    </View>
                    {item.notes && <Text style={{ fontSize: 11, color: "#9BA1A6", marginTop: 6, textAlign: "right" }}>{item.notes}</Text>}
                  </View>
                  <View style={{ gap: 6, marginRight: 8 }}>
                    <TouchableOpacity onPress={() => openEditItem(item)} style={{ backgroundColor: "#EBF4FF", borderRadius: 8, padding: 6 }}>
                      <MaterialIcons name="edit" size={14} color="#1E3A5F" />
                    </TouchableOpacity>
                    <TouchableOpacity onPress={() => handleDeleteItem(item)} style={{ backgroundColor: "#FEE2E2", borderRadius: 8, padding: 6 }}>
                      <MaterialIcons name="delete" size={14} color="#E74C3C" />
                    </TouchableOpacity>
                  </View>
                </View>
              </View>
            ))}
          </View>
        ))}

        {items.length === 0 && (
          <View style={{ alignItems: "center", paddingVertical: 40 }}>
            <MaterialIcons name="receipt-long" size={56} color="#D1D5DB" />
            <Text style={{ fontSize: 15, color: "#9BA1A6", marginTop: 12 }}>لا توجد بنود بعد</Text>
            <Text style={{ fontSize: 13, color: "#C4C9D0", marginTop: 4 }}>اضغط "إضافة بند" لإضافة خدمات</Text>
          </View>
        )}

        {/* Total Summary */}
        {items.length > 0 && (
          <View style={{ backgroundColor: "white", borderRadius: 16, padding: 16, marginTop: 8, borderWidth: 2, borderColor: "#1E3A5F" }}>
            <Text style={{ fontSize: 14, fontWeight: "800", color: "#1A2332", textAlign: "right", marginBottom: 12 }}>ملخص الاحتساب</Text>
            {Object.entries(groupedItems).map(([cat, catItems]) => {
              const catTotal = catItems.reduce((s, i) => s + i.totalUSD, 0);
              return (
                <View key={cat} style={{ flexDirection: "row-reverse", justifyContent: "space-between", paddingVertical: 6, borderBottomWidth: 1, borderBottomColor: "#F0F4F8" }}>
                  <Text style={{ fontSize: 13, color: "#6B7C93" }}>{cat}</Text>
                  <Text style={{ fontSize: 13, fontWeight: "600", color: "#1A2332" }}>{catTotal.toLocaleString("ar-SA")} ر.ي</Text>
                </View>
              );
            })}
            <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", paddingTop: 12, marginTop: 4 }}>
              <Text style={{ fontSize: 15, fontWeight: "800", color: "#1A2332" }}>الإجمالي الكلي</Text>
              <Text style={{ fontSize: 15, fontWeight: "800", color: "#27AE60" }}>{totalAmount.toLocaleString("ar-SA")} ر.ي</Text>
            </View>
            <View style={{ flexDirection: "row-reverse", justifyContent: "flex-start", marginTop: 4 }}>
              <Text style={{ fontSize: 12, color: "#9BA1A6" }}>≈ {(totalAmount / exchangeRate).toLocaleString("ar-SA", { maximumFractionDigits: 2 })} USD (سعر الصرف: {exchangeRate})</Text>
            </View>
          </View>
        )}
      </ScrollView>

      {/* Add/Edit Item Modal */}
      <Modal visible={showAddItem} transparent animationType="slide">
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}>
          <View style={{ backgroundColor: "white", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, maxHeight: "90%" }}>
            <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <Text style={{ fontSize: 17, fontWeight: "800", color: "#1A2332" }}>{editingItem ? "تعديل البند" : "إضافة بند جديد"}</Text>
              <TouchableOpacity onPress={() => setShowAddItem(false)}>
                <MaterialIcons name="close" size={24} color="#6B7C93" />
              </TouchableOpacity>
            </View>
            <ScrollView showsVerticalScrollIndicator={false}>
              {/* Quick Select */}
              <Text style={{ fontSize: 13, color: "#6B7C93", textAlign: "right", marginBottom: 8 }}>اختيار سريع</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 14 }}>
                <View style={{ flexDirection: "row-reverse", gap: 8 }}>
                  {SERVICE_ITEMS.map((s) => (
                    <TouchableOpacity
                      key={s.code}
                      onPress={() => selectService(s)}
                      style={{ paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8, backgroundColor: serviceCode === s.code ? "#1E3A5F" : "#F0F4F8" }}
                    >
                      <Text style={{ fontSize: 11, color: serviceCode === s.code ? "white" : "#6B7C93" }}>{s.name}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </ScrollView>

              {[
                { label: "كود الخدمة", value: serviceCode, setter: setServiceCode, placeholder: "F001" },
                { label: "اسم الخدمة *", value: serviceName, setter: setServiceName, placeholder: "رسوم الإرشاد" },
                { label: "الفئة", value: category, setter: setCategory, placeholder: "رسوم ميناء" },
                { label: "الوحدة", value: unit, setter: setUnit, placeholder: "ساعة / رحلة / وحدة" },
              ].map((field, idx) => (
                <View key={idx} style={{ marginBottom: 12 }}>
                  <Text style={{ fontSize: 12, color: "#6B7C93", textAlign: "right", marginBottom: 4 }}>{field.label}</Text>
                  <TextInput
                    value={field.value}
                    onChangeText={field.setter}
                    placeholder={field.placeholder}
                    style={{ backgroundColor: "#F8FAFC", borderRadius: 10, padding: 12, fontSize: 13, textAlign: "right", borderWidth: 1, borderColor: "#E5E7EB" }}
                  />
                </View>
              ))}

              <View style={{ flexDirection: "row-reverse", gap: 12, marginBottom: 12 }}>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 12, color: "#6B7C93", textAlign: "right", marginBottom: 4 }}>الكمية</Text>
                  <TextInput
                    value={quantity}
                    onChangeText={setQuantity}
                    keyboardType="numeric"
                    style={{ backgroundColor: "#F8FAFC", borderRadius: 10, padding: 12, fontSize: 14, textAlign: "right", borderWidth: 1, borderColor: "#E5E7EB" }}
                  />
                </View>
                <View style={{ flex: 1 }}>
                  <Text style={{ fontSize: 12, color: "#6B7C93", textAlign: "right", marginBottom: 4 }}>سعر الوحدة (ر.ي)</Text>
                  <TextInput
                    value={unitPrice}
                    onChangeText={setUnitPrice}
                    keyboardType="numeric"
                    style={{ backgroundColor: "#F8FAFC", borderRadius: 10, padding: 12, fontSize: 14, textAlign: "right", borderWidth: 1, borderColor: "#E5E7EB" }}
                  />
                </View>
              </View>

              {quantity && unitPrice && (
                <View style={{ backgroundColor: "#F0FFF4", borderRadius: 10, padding: 12, marginBottom: 12, flexDirection: "row-reverse", justifyContent: "space-between" }}>
                  <Text style={{ fontSize: 13, color: "#27AE60" }}>الإجمالي</Text>
                  <Text style={{ fontSize: 15, fontWeight: "800", color: "#27AE60" }}>
                    {((parseFloat(quantity) || 0) * (parseFloat(unitPrice) || 0)).toLocaleString("ar-SA")} ر.ي
                  </Text>
                </View>
              )}

              <View style={{ marginBottom: 20 }}>
                <Text style={{ fontSize: 12, color: "#6B7C93", textAlign: "right", marginBottom: 4 }}>ملاحظات</Text>
                <TextInput
                  value={notes}
                  onChangeText={setNotes}
                  placeholder="ملاحظات إضافية"
                  multiline
                  numberOfLines={3}
                  textAlignVertical="top"
                  style={{ backgroundColor: "#F8FAFC", borderRadius: 10, padding: 12, fontSize: 13, textAlign: "right", borderWidth: 1, borderColor: "#E5E7EB", minHeight: 70 }}
                />
              </View>

              <TouchableOpacity
                onPress={handleSaveItem}
                style={{ backgroundColor: "#1E3A5F", borderRadius: 14, paddingVertical: 16, alignItems: "center" }}
              >
                <Text style={{ color: "white", fontSize: 15, fontWeight: "700" }}>{editingItem ? "حفظ التعديل" : "إضافة البند"}</Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}
