import * as Print from "expo-print";
import { shareAsync } from "expo-sharing";
import { Platform, Alert } from "react-native";
import type { Invoice, Vessel, InvoiceItem, Memo } from "./storage";

// ─── توليد HTML للفاتورة ──────────────────────────────────────────────────────
export function generateInvoiceHTML(
  invoice: Invoice,
  vessel: Vessel | undefined,
  items: InvoiceItem[],
  exchangeRate: number = 250
): string {
  const statusLabels: Record<string, string> = {
    draft: "مسودة",
    pending: "معلق",
    approved: "موافق عليه",
    paid: "مدفوع",
    overdue: "متأخر",
    cancelled: "ملغي",
  };

  const statusColors: Record<string, string> = {
    draft: "#6B7C93",
    pending: "#F39C12",
    approved: "#2E86AB",
    paid: "#27AE60",
    overdue: "#E74C3C",
    cancelled: "#9B59B6",
  };

  const statusColor = statusColors[invoice.status] || "#6B7C93";
  const statusLabel = statusLabels[invoice.status] || invoice.status;
  const amountLocal = invoice.amount * exchangeRate;
  const today = new Date().toLocaleDateString("ar-YE", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  const itemsHTML = items.length > 0 ? `
    <table>
      <thead>
        <tr>
          <th>البند</th>
          <th>الوصف</th>
          <th>الكمية</th>
          <th>السعر ($)</th>
          <th>الإجمالي ($)</th>
        </tr>
      </thead>
      <tbody>
        ${items.map((item) => `
          <tr>
            <td>${item.itemCode || "-"}</td>
            <td>${item.itemName}</td>
            <td>${item.quantity ?? 1}</td>
            <td>${item.unitPrice.toFixed(2)}</td>
            <td>${item.totalUSD.toFixed(2)}</td>
          </tr>
        `).join("")}  
      </tbody>
    </table>
  ` : "";

  return `<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0" />
  <style>
    @page { margin: 20px; }
    * { box-sizing: border-box; }
    body {
      font-family: 'Arial', 'Helvetica', sans-serif;
      direction: rtl;
      color: #1A2332;
      font-size: 13px;
      margin: 0;
      padding: 20px;
      background: #fff;
    }
    .header {
      background: linear-gradient(135deg, #1E3A5F 0%, #2E5A8F 100%);
      color: white;
      padding: 24px;
      border-radius: 12px;
      margin-bottom: 20px;
    }
    .header-top {
      display: flex;
      justify-content: space-between;
      align-items: flex-start;
      margin-bottom: 16px;
    }
    .company-name {
      font-size: 22px;
      font-weight: 900;
      letter-spacing: 1px;
    }
    .company-sub {
      font-size: 12px;
      opacity: 0.8;
      margin-top: 4px;
    }
    .invoice-title {
      font-size: 28px;
      font-weight: 900;
      text-align: left;
    }
    .invoice-number {
      font-size: 14px;
      opacity: 0.8;
      text-align: left;
    }
    .status-badge {
      display: inline-block;
      background: rgba(255,255,255,0.2);
      border: 2px solid rgba(255,255,255,0.4);
      color: white;
      padding: 6px 16px;
      border-radius: 20px;
      font-size: 13px;
      font-weight: 700;
    }
    .info-grid {
      display: grid;
      grid-template-columns: 1fr 1fr;
      gap: 16px;
      margin-bottom: 20px;
    }
    .info-card {
      background: #F8FAFC;
      border: 1px solid #E5E7EB;
      border-radius: 10px;
      padding: 16px;
    }
    .info-card-title {
      font-size: 11px;
      color: #6B7C93;
      font-weight: 700;
      text-transform: uppercase;
      letter-spacing: 0.5px;
      margin-bottom: 8px;
    }
    .info-row {
      display: flex;
      justify-content: space-between;
      margin-bottom: 6px;
    }
    .info-label {
      color: #6B7C93;
      font-size: 12px;
    }
    .info-value {
      color: #1A2332;
      font-weight: 600;
      font-size: 12px;
    }
    table {
      width: 100%;
      border-collapse: collapse;
      margin-bottom: 20px;
      font-size: 12px;
    }
    thead tr {
      background: #1E3A5F;
      color: white;
    }
    th {
      padding: 10px 12px;
      text-align: right;
      font-weight: 700;
    }
    td {
      padding: 9px 12px;
      border-bottom: 1px solid #F0F4F8;
    }
    tr:nth-child(even) td {
      background: #F8FAFC;
    }
    .totals {
      background: #F8FAFC;
      border: 1px solid #E5E7EB;
      border-radius: 10px;
      padding: 16px;
      margin-bottom: 20px;
    }
    .total-row {
      display: flex;
      justify-content: space-between;
      padding: 6px 0;
      border-bottom: 1px solid #E5E7EB;
    }
    .total-row:last-child {
      border-bottom: none;
      padding-top: 12px;
      margin-top: 6px;
    }
    .total-final {
      font-size: 16px;
      font-weight: 900;
      color: #1E3A5F;
    }
    .total-amount {
      font-size: 16px;
      font-weight: 900;
      color: #27AE60;
    }
    .notes {
      background: #FEF9E7;
      border: 1px solid #F39C12;
      border-radius: 10px;
      padding: 14px;
      margin-bottom: 20px;
    }
    .notes-title {
      font-weight: 700;
      color: #E67E22;
      margin-bottom: 6px;
    }
    .footer {
      text-align: center;
      color: #9BA1A6;
      font-size: 11px;
      border-top: 1px solid #E5E7EB;
      padding-top: 14px;
      margin-top: 20px;
    }
    .discrepancy {
      background: #FDEDEC;
      border: 1px solid #E74C3C;
      border-radius: 10px;
      padding: 14px;
      margin-bottom: 20px;
    }
    .discrepancy-title {
      font-weight: 700;
      color: #E74C3C;
      margin-bottom: 6px;
    }
  </style>
</head>
<body>

  <!-- Header -->
  <div class="header">
    <div class="header-top">
      <div>
        <div class="company-name">نظام حبيب</div>
        <div class="company-sub">إدارة السفن والفواتير البحرية</div>
      </div>
      <div style="text-align:left;">
        <div class="invoice-title">فاتورة</div>
        <div class="invoice-number">${invoice.invoiceNumber}</div>
      </div>
    </div>
    <div style="display:flex; justify-content:space-between; align-items:center;">
      <span class="status-badge">${statusLabel}</span>
      <span style="font-size:12px; opacity:0.8;">تاريخ الطباعة: ${today}</span>
    </div>
  </div>

  <!-- Info Grid -->
  <div class="info-grid">
    <div class="info-card">
      <div class="info-card-title">بيانات السفينة</div>
      <div class="info-row">
        <span class="info-label">اسم السفينة:</span>
        <span class="info-value">${vessel?.name || invoice.vesselName || "-"}</span>
      </div>
      <div class="info-row">
        <span class="info-label">نوع السفينة:</span>
        <span class="info-value">${vessel?.type || "-"}</span>
      </div>
      <div class="info-row">
        <span class="info-label">GRT:</span>
        <span class="info-value">${vessel?.grt?.toLocaleString() || "-"}</span>
      </div>
      <div class="info-row">
        <span class="info-label">NRT:</span>
        <span class="info-value">${vessel?.nrt?.toLocaleString() || "-"}</span>
      </div>
      ${vessel?.flag ? `<div class="info-row"><span class="info-label">علم السفينة:</span><span class="info-value">${vessel.flag}</span></div>` : ""}
    </div>
    <div class="info-card">
      <div class="info-card-title">بيانات الفاتورة</div>
      <div class="info-row">
        <span class="info-label">رقم الفاتورة:</span>
        <span class="info-value">${invoice.invoiceNumber}</span>
      </div>
      <div class="info-row">
        <span class="info-label">تاريخ الإصدار:</span>
        <span class="info-value">${new Date(invoice.issuedDate).toLocaleDateString("ar-YE")}</span>
      </div>
      <div class="info-row">
        <span class="info-label">تاريخ الاستحقاق:</span>
        <span class="info-value">${invoice.dueDate ? new Date(invoice.dueDate).toLocaleDateString("ar-YE") : "-"}</span>
      </div>
      ${invoice.arrivalDate ? `<div class="info-row"><span class="info-label">تاريخ الوصول:</span><span class="info-value">${new Date(invoice.arrivalDate).toLocaleDateString("ar-YE")}</span></div>` : ""}
      ${invoice.departureDate ? `<div class="info-row"><span class="info-label">تاريخ المغادرة:</span><span class="info-value">${new Date(invoice.departureDate).toLocaleDateString("ar-YE")}</span></div>` : ""}
      ${invoice.totalHours ? `<div class="info-row"><span class="info-label">إجمالي الساعات:</span><span class="info-value">${invoice.totalHours} ساعة</span></div>` : ""}
    </div>
  </div>

  <!-- Items Table -->
  ${items.length > 0 ? `
    <h3 style="color:#1E3A5F; margin-bottom:10px; font-size:14px;">تفاصيل بنود الفاتورة</h3>
    ${itemsHTML}
  ` : ""}

  <!-- Totals -->
  <div class="totals">
    <div class="total-row">
      <span class="info-label">المبلغ الإجمالي (دولار):</span>
      <span style="font-weight:600; color:#1A2332;">$${invoice.amount.toFixed(2)}</span>
    </div>
    ${invoice.externalInvoiceAmount ? `
    <div class="total-row">
      <span class="info-label">مبلغ الفاتورة الخارجية:</span>
      <span style="font-weight:600; color:#E67E22;">$${invoice.externalInvoiceAmount.toFixed(2)}</span>
    </div>
    ` : ""}
    ${invoice.discrepancy ? `
    <div class="total-row">
      <span class="info-label">الفرق:</span>
      <span style="font-weight:600; color:${invoice.discrepancy > 0 ? "#27AE60" : "#E74C3C"};">$${Math.abs(invoice.discrepancy).toFixed(2)} ${invoice.discrepancy > 0 ? "(زيادة)" : "(نقص)"}</span>
    </div>
    ` : ""}
    <div class="total-row">
      <span class="total-final">الإجمالي المستحق:</span>
      <div>
        <div class="total-amount">$${invoice.amount.toFixed(2)}</div>
        <div style="font-size:12px; color:#6B7C93; text-align:left;">${amountLocal.toLocaleString()} ريال يمني</div>
      </div>
    </div>
  </div>

  <!-- Discrepancy Note -->
  ${invoice.discrepancy && Math.abs(invoice.discrepancy) > 0 ? `
  <div class="discrepancy">
    <div class="discrepancy-title">ملاحظة الفروقات</div>
    <p style="margin:0; font-size:12px;">يوجد فرق بين المبلغ المحتسب والفاتورة الخارجية بقيمة $${Math.abs(invoice.discrepancy).toFixed(2)}. يرجى المراجعة والتدقيق.</p>
  </div>
  ` : ""}

  <!-- Notes -->
  ${invoice.notes ? `
  <div class="notes">
    <div class="notes-title">ملاحظات</div>
    <p style="margin:0; font-size:12px;">${invoice.notes}</p>
  </div>
  ` : ""}

  <!-- Footer -->
  <div class="footer">
    <p>نظام حبيب لإدارة السفن والفواتير البحرية | جميع الحقوق محفوظة © ${new Date().getFullYear()}</p>
    <p>تم إنشاء هذه الفاتورة إلكترونياً وهي صالحة بدون توقيع</p>
  </div>

</body>
</html>`;
}

// ─── توليد HTML للمذكرة ───────────────────────────────────────────────────────
export function generateMemoHTML(memo: Memo, vesselName?: string): string {
  const typeLabels: Record<string, string> = {
    communication: "مخاطبة رسمية",
    complaint: "شكوى",
    inquiry: "استفسار",
    notification: "إشعار",
    port: "مخاطبة ميناء",
    customs: "مخاطبة جمارك",
    agent: "مخاطبة وكيل",
    company: "مخاطبة شركة",
  };

  const today = new Date().toLocaleDateString("ar-YE", {
    year: "numeric",
    month: "long",
    day: "numeric",
  });

  return `<!DOCTYPE html>
<html dir="rtl" lang="ar">
<head>
  <meta charset="UTF-8" />
  <style>
    @page { margin: 30px; }
    body {
      font-family: 'Arial', 'Helvetica', sans-serif;
      direction: rtl;
      color: #1A2332;
      font-size: 13px;
      margin: 0;
      padding: 30px;
      background: #fff;
    }
    .letterhead {
      border-bottom: 3px solid #1E3A5F;
      padding-bottom: 20px;
      margin-bottom: 30px;
      display: flex;
      justify-content: space-between;
      align-items: flex-end;
    }
    .company-name { font-size: 20px; font-weight: 900; color: #1E3A5F; }
    .company-sub { font-size: 11px; color: #6B7C93; margin-top: 4px; }
    .memo-meta { text-align: left; font-size: 12px; color: #6B7C93; }
    .memo-title {
      text-align: center;
      font-size: 18px;
      font-weight: 900;
      color: #1E3A5F;
      margin: 20px 0;
      padding: 12px;
      border: 2px solid #1E3A5F;
      border-radius: 8px;
    }
    .memo-info {
      background: #F8FAFC;
      border: 1px solid #E5E7EB;
      border-radius: 8px;
      padding: 16px;
      margin-bottom: 24px;
    }
    .memo-info-row {
      display: flex;
      justify-content: space-between;
      margin-bottom: 8px;
      font-size: 12px;
    }
    .memo-info-label { color: #6B7C93; font-weight: 600; }
    .memo-info-value { color: #1A2332; font-weight: 700; }
    .memo-body {
      line-height: 2;
      font-size: 14px;
      text-align: justify;
      margin-bottom: 40px;
      min-height: 200px;
    }
    .signature-area {
      display: flex;
      justify-content: space-between;
      margin-top: 60px;
      padding-top: 20px;
      border-top: 1px solid #E5E7EB;
    }
    .signature-box { text-align: center; }
    .signature-line {
      width: 150px;
      border-bottom: 1px solid #1A2332;
      margin: 0 auto 8px;
    }
    .footer {
      text-align: center;
      color: #9BA1A6;
      font-size: 10px;
      border-top: 1px solid #E5E7EB;
      padding-top: 12px;
      margin-top: 30px;
    }
  </style>
</head>
<body>

  <div class="letterhead">
    <div>
      <div class="company-name">نظام حبيب</div>
      <div class="company-sub">إدارة السفن والفواتير البحرية</div>
    </div>
    <div class="memo-meta">
      <div>التاريخ: ${today}</div>
      <div>رقم المذكرة: ${memo.id}</div>
    </div>
  </div>

  <div class="memo-title">${typeLabels[memo.memoType] || "مذكرة رسمية"}</div>

  <div class="memo-info">
    <div class="memo-info-row">
      <span class="memo-info-label">الموضوع:</span>
      <span class="memo-info-value">${memo.title}</span>
    </div>
    ${memo.recipientEntity ? `
    <div class="memo-info-row">
      <span class="memo-info-label">إلى:</span>
      <span class="memo-info-value">${memo.recipientEntity}</span>
    </div>
    ` : ""}
    ${memo.recipientAddress ? `
    <div class="memo-info-row">
      <span class="memo-info-label">العنوان:</span>
      <span class="memo-info-value">${memo.recipientAddress}</span>
    </div>
    ` : ""}
    ${vesselName ? `
    <div class="memo-info-row">
      <span class="memo-info-label">السفينة:</span>
      <span class="memo-info-value">${vesselName}</span>
    </div>
    ` : ""}
    <div class="memo-info-row">
      <span class="memo-info-label">التاريخ:</span>
      <span class="memo-info-value">${new Date(memo.createdAt).toLocaleDateString("ar-YE")}</span>
    </div>
  </div>

  <div class="memo-body">
    ${memo.content.replace(/\n/g, "<br/>")}
  </div>

  <div class="signature-area">
    <div class="signature-box">
      <div class="signature-line"></div>
      <div style="font-size:12px; color:#6B7C93;">توقيع المرسل</div>
    </div>
    <div class="signature-box">
      <div class="signature-line"></div>
      <div style="font-size:12px; color:#6B7C93;">توقيع المستلم</div>
    </div>
    <div class="signature-box">
      <div class="signature-line"></div>
      <div style="font-size:12px; color:#6B7C93;">الختم الرسمي</div>
    </div>
  </div>

  <div class="footer">
    <p>نظام حبيب لإدارة السفن والفواتير البحرية | جميع الحقوق محفوظة © ${new Date().getFullYear()}</p>
  </div>

</body>
</html>`;
}

// ─── دوال المشاركة والطباعة ────────────────────────────────────────────────────
export async function printInvoice(
  invoice: Invoice,
  vessel: Vessel | undefined,
  items: InvoiceItem[],
  exchangeRate: number = 250
): Promise<void> {
  try {
    const html = generateInvoiceHTML(invoice, vessel, items, exchangeRate);
    if (Platform.OS === "web") {
      await Print.printAsync({});
    } else {
      await Print.printAsync({ html });
    }
  } catch (error) {
    Alert.alert("خطأ", "فشل في الطباعة. يرجى المحاولة مرة أخرى.");
  }
}

export async function shareInvoicePDF(
  invoice: Invoice,
  vessel: Vessel | undefined,
  items: InvoiceItem[],
  exchangeRate: number = 250
): Promise<void> {
  try {
    const html = generateInvoiceHTML(invoice, vessel, items, exchangeRate);
    const { uri } = await Print.printToFileAsync({ html });
    await shareAsync(uri, {
      mimeType: "application/pdf",
      dialogTitle: `فاتورة ${invoice.invoiceNumber}`,
      UTI: ".pdf",
    });
  } catch (error) {
    Alert.alert("خطأ", "فشل في إنشاء ملف PDF. يرجى المحاولة مرة أخرى.");
  }
}

export async function shareMemoPDF(
  memo: Memo,
  vesselName?: string
): Promise<void> {
  try {
    const html = generateMemoHTML(memo, vesselName);
    const { uri } = await Print.printToFileAsync({ html });
    await shareAsync(uri, {
      mimeType: "application/pdf",
      dialogTitle: `مذكرة: ${memo.title}`,
      UTI: ".pdf",
    });
  } catch (error) {
    Alert.alert("خطأ", "فشل في إنشاء ملف PDF. يرجى المحاولة مرة أخرى.");
  }
}

export async function printMemo(memo: Memo, vesselName?: string): Promise<void> {
  try {
    const html = generateMemoHTML(memo, vesselName);
    if (Platform.OS === "web") {
      await Print.printAsync({});
    } else {
      await Print.printAsync({ html });
    }
  } catch (error) {
    Alert.alert("خطأ", "فشل في الطباعة. يرجى المحاولة مرة أخرى.");
  }
}
