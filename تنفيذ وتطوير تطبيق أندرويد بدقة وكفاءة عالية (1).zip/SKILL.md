---
name: vessel-management-system
description: |
  Build complete vessel and invoice management systems with advanced features including invoicing, memos, archives, PDF generation, and secure client portals. Use for creating maritime/shipping management applications, building multi-user admin dashboards, implementing role-based access control, generating financial reports, and deploying secure client-facing portals.
---

# Vessel Management System Skill

## Overview

This skill guides the creation of a comprehensive vessel and invoice management system with advanced features including multi-user administration, financial reporting, document archiving, and secure client portals. The system is designed for maritime companies, shipping agencies, and port authorities that need to manage vessel operations, track invoices, and communicate with clients.

The skill encapsulates a complete workflow for building production-ready management systems using React, Express, tRPC, and MySQL, with built-in support for PDF generation, role-based access control, and secure authentication.

## Core Capabilities

### 1. Vessel Management

Create a comprehensive vessel database and management interface with:

- **Vessel Information Storage**: Track vessel names, types, tonnage (GRT/NRT), length, and operational status
- **Arrival/Departure Tracking**: Record and manage vessel arrival and departure dates with time tracking
- **Vessel Search and Filtering**: Implement advanced search capabilities to find vessels by name, type, or status
- **Bulk Operations**: Support for importing vessel data from Excel files (using xlsx parsing)

### 2. Invoice Management and Financial Tracking

Build a complete invoicing system with:

- **Invoice Creation and Tracking**: Generate invoices linked to specific vessels with automatic numbering
- **Multi-Currency Support**: Handle both USD and local currency (e.g., Yemeni Riyal) calculations
- **Discrepancy Tracking**: Automatically calculate and track differences between internal and external calculations
- **Invoice Status Management**: Track invoice status (paid, pending, overdue) with visual indicators
- **PDF Export**: Generate professional PDF invoices with vessel information, calculations, and totals

### 3. Memo and Communication System

Enable internal communication and external correspondence:

- **Memo Creation**: Create memos for communicating with external entities (government agencies, port authorities, clients)
- **Memo Routing**: Assign memos to specific vessels and recipients
- **Archive Integration**: Automatically archive memos after sending or on demand
- **Status Tracking**: Monitor memo status (draft, sent, archived)

### 4. Archive and Document Management

Implement a comprehensive archiving system:

- **Multi-Document Storage**: Archive invoices, memos, reports, and external documents
- **Search and Filtering**: Find archived documents by date, vessel, type, or content
- **File Attachments**: Support uploading and storing external files (PDFs, Excel, images)
- **Audit Trail**: Maintain records of all archived documents with timestamps and user information

### 5. Financial Reporting and Analytics

Create detailed financial reports and dashboards:

- **Monthly Revenue Reports**: Generate monthly summaries of invoices and revenue
- **Discrepancy Analysis**: Identify and report on calculation differences
- **Statistical Dashboards**: Display key metrics (total invoices, revenue, pending amounts)
- **PDF Report Export**: Generate comprehensive financial reports for stakeholders

### 6. Secure Client Portal

Build a separate client-facing website with:

- **Authentication System**: Implement secure login with email and password
- **Invoice Viewing**: Allow clients to view their invoices with status indicators
- **PDF Download**: Enable clients to download invoices as PDF files
- **Restricted Access**: Ensure clients can only view their own data
- **Responsive Design**: Provide mobile-friendly interface for all devices

## Workflow: Building a Vessel Management System

### Phase 1: Project Setup and Database Design

1. **Initialize the project** using the tRPC + React + Express template with database support
2. **Design the database schema** with tables for:
   - `users` (with role-based access control: admin, accountant, reviewer, user)
   - `vessels` (vessel information and metadata)
   - `invoices` (invoice records with vessel references)
   - `memos` (internal memos and communications)
   - `archives` (archived documents and records)
   - `audit_logs` (system activity tracking)
3. **Set up authentication** using OAuth with role-based access control
4. **Configure environment variables** for database, OAuth, and API keys

### Phase 2: Core Admin Dashboard

1. **Create the main dashboard** with statistics cards showing:
   - Total vessels count
   - Total invoices count
   - Total memos count
   - Total archived files count
2. **Build navigation** with links to all major sections
3. **Implement user profile** with logout functionality
4. **Add role-based navigation** showing different options based on user role

### Phase 3: Vessel Management Module

1. **Create vessel listing page** with:
   - Table showing all vessels
   - Search and filter functionality
   - Add/Edit/Delete buttons
2. **Build vessel detail page** with:
   - Complete vessel information
   - Related invoices
   - Associated memos
3. **Implement vessel import** from Excel files using xlsx library
4. **Add validation** for vessel data (required fields, data types)

### Phase 4: Invoice Management Module

1. **Create invoice listing page** with:
   - Table of all invoices
   - Status indicators (paid, pending, overdue)
   - Search and filter by vessel, date, or amount
2. **Build invoice detail view** showing:
   - Vessel information
   - Financial calculations
   - Discrepancy information
3. **Implement invoice creation form** with:
   - Vessel selection
   - Amount and fee inputs
   - Multi-currency support
4. **Add PDF generation** for individual invoices

### Phase 5: Memo and Archive System

1. **Create memo management page** with:
   - Memo creation form
   - Memo listing with status
   - Archive functionality
2. **Build archive page** with:
   - Document search and filtering
   - File upload capability
   - Archive browsing by date or type
3. **Implement memo-to-archive workflow**

### Phase 6: Financial Reports

1. **Create reports dashboard** with:
   - Monthly revenue summary
   - Discrepancy analysis
   - Statistical charts
2. **Implement PDF report generation** with:
   - Monthly summaries
   - Detailed tables
   - Visual charts
3. **Add export functionality** for reports

### Phase 7: Client Portal

1. **Create separate login page** for clients
2. **Build client dashboard** showing:
   - Client's invoices
   - Invoice status
   - Download buttons
3. **Implement invoice detail view** for clients
4. **Add PDF download** functionality
5. **Ensure data isolation** (clients only see their own data)

### Phase 8: Security and Deployment

1. **Implement role-based access control** in all procedures
2. **Add audit logging** for all operations
3. **Encrypt sensitive data** (passwords, payment information)
4. **Configure CORS** for client portal domain
5. **Set up SSL/TLS** for secure communication
6. **Deploy to production** environment

## Data Import from Excel

The system supports importing vessel and invoice data from Excel files. The workflow:

1. **Prepare Excel file** with columns:
   - Vessel name, type, GRT, NRT, length
   - Invoice number, date, amount, fees
   - Arrival/departure dates
2. **Parse Excel file** using `xlsx` library
3. **Validate data** before insertion
4. **Insert into database** with error handling
5. **Display import results** with success/failure counts

See `references/excel-import-guide.md` for detailed Excel format specifications.

## PDF Generation

The system uses `jsPDF` library for generating professional PDF documents:

- **Invoice PDFs**: Include vessel info, calculations, and payment details
- **Report PDFs**: Contain monthly summaries, tables, and charts
- **Memo PDFs**: Archive memo content with metadata

All PDFs support Arabic text and professional formatting with headers, footers, and branding.

## Role-Based Access Control

Implement four user roles with specific permissions:

| Role | Vessels | Invoices | Memos | Archives | Reports |
|------|---------|----------|-------|----------|---------|
| Admin | Full | Full | Full | Full | Full |
| Accountant | View | Full | View | View | Full |
| Reviewer | View | View | Full | Full | View |
| User | View | View | View | View | View |

Use `protectedProcedure` with role checks in tRPC routers to enforce permissions.

## Key Implementation Patterns

### Database Schema Pattern

```sql
CREATE TABLE vessels (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL,
  type VARCHAR(100),
  grt INT,
  nrt INT,
  length DECIMAL(10,2),
  status ENUM('active', 'inactive', 'maintenance'),
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE invoices (
  id INT PRIMARY KEY AUTO_INCREMENT,
  invoiceNum INT UNIQUE,
  vesselId INT NOT NULL,
  amount DECIMAL(12,2),
  fees DECIMAL(10,2),
  feesYemen DECIMAL(12,2),
  status ENUM('paid', 'pending', 'overdue'),
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  FOREIGN KEY (vesselId) REFERENCES vessels(id)
);
```

### tRPC Procedure Pattern

```typescript
// Protected procedure with role check
const adminOnlyProcedure = protectedProcedure.use(({ ctx, next }) => {
  if (ctx.user.role !== 'admin') {
    throw new TRPCError({ code: 'FORBIDDEN' });
  }
  return next({ ctx });
});

// Usage in router
export const vesselRouter = router({
  create: adminOnlyProcedure
    .input(z.object({ name: z.string(), grt: z.number() }))
    .mutation(async ({ input }) => {
      // Create vessel logic
    }),
});
```

### PDF Generation Pattern

```typescript
const generateInvoicePDF = (invoice: InvoiceData): void => {
  const doc = new jsPDF('p', 'mm', 'a4');
  
  // Add header with logo and title
  doc.setFontSize(20);
  doc.text('Vessel Management System', 105, 20, { align: 'center' });
  
  // Add invoice details
  doc.setFontSize(10);
  doc.text(`Invoice #${invoice.invoiceNum}`, 20, 45);
  
  // Add vessel information table
  // Add financial details
  
  // Save file
  doc.save(`invoice_${invoice.invoiceNum}.pdf`);
};
```

## Resources

### scripts/
- `import-excel.py` - Parse and validate Excel files for bulk import
- `generate-reports.py` - Generate monthly financial reports
- `backup-database.py` - Automated database backup script

### references/
- `excel-import-guide.md` - Detailed Excel format specifications
- `role-permissions.md` - Complete role-based access control matrix
- `api-endpoints.md` - tRPC procedure documentation
- `database-schema.md` - Complete database schema with relationships

### templates/
- `invoice-template.html` - HTML template for invoice PDF generation
- `report-template.html` - HTML template for financial reports
- `logo.svg` - Company logo for documents

## Common Workflows

### Importing Vessels from Excel

1. Prepare Excel file with vessel data
2. Navigate to Vessels page
3. Click "Import from Excel"
4. Select file and confirm
5. Review import results
6. Vessels are now available in the system

### Creating and Archiving a Memo

1. Navigate to Memos page
2. Click "New Memo"
3. Select vessel, recipient, and enter content
4. Click "Send"
5. Memo automatically archives after sending
6. View in Archives page

### Generating Financial Reports

1. Navigate to Reports page
2. Select date range
3. Click "Generate Report"
4. Review statistics and charts
5. Click "Download PDF" to export
6. Share with stakeholders

## Best Practices

1. **Data Validation**: Always validate user input before database operations
2. **Error Handling**: Provide clear error messages for failed operations
3. **Audit Logging**: Log all critical operations (create, update, delete)
4. **Performance**: Use database indexes on frequently queried fields
5. **Security**: Never expose sensitive data in API responses
6. **Testing**: Write unit tests for all tRPC procedures
7. **Documentation**: Keep inline code comments for complex logic
8. **Backup**: Implement automated daily database backups

## Troubleshooting

### Common Issues

**Issue**: Excel import fails with encoding errors
- **Solution**: Ensure Excel file is saved as UTF-8 or XLSX format, not XLS

**Issue**: PDF generation shows garbled Arabic text
- **Solution**: Ensure jsPDF is configured with Arabic font support

**Issue**: Client portal shows "Unauthorized" error
- **Solution**: Verify client token is stored in localStorage and hasn't expired

**Issue**: Discrepancy calculations don't match
- **Solution**: Check that both USD and local currency conversion rates are correct

## Next Steps

After implementing the core system:

1. **Add email notifications** for invoice reminders
2. **Implement payment gateway** integration (Stripe, PayPal)
3. **Add SMS notifications** for urgent memos
4. **Create mobile app** for on-the-go access
5. **Implement real-time updates** using WebSockets
6. **Add advanced analytics** with data visualization
7. **Create API documentation** for third-party integrations
8. **Implement multi-language support** (Arabic, English)
