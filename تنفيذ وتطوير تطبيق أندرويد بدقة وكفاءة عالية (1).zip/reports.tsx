import { useState } from "react";
import {
  View,
  Text,
  ScrollView,
  TouchableOpacity,
  FlatList,
  Modal,
  TextInput,
  Alert,
} from "react-native";
import { ScreenContainer } from "@/components/screen-container";
import { useApp } from "@/lib/app-context";
import type { Memo, Archive, Payment } from "@/lib/storage";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useRouter } from "expo-router";

type Tab = "reports" | "memos" | "archive" | "payments";

// ─── Reports Tab ─────────────────────────────────────────────────────────────
function ReportsTab() {
  const { invoices, vessels, payments } = useApp();
  const router = useRouter();

  const totalRevenue = invoices.filter((i) => i.status === "paid").reduce((s, i) => s + i.amount, 0);
  const pendingRevenue = invoices.filter((i) => i.status === "pending").reduce((s, i) => s + i.amount, 0);
  const overdueRevenue = invoices.filter((i) => i.status === "overdue").reduce((s, i) => s + i.amount, 0);
  const totalDiscrepancy = invoices.reduce((s, i) => s + (i.discrepancy || 0), 0);

  const byStatus = [
    { label: "مدفوع", value: invoices.filter((i) => i.status === "paid").length, color: "#27AE60" },
    { label: "معلق", value: invoices.filter((i) => i.status === "pending").length, color: "#F39C12" },
    { label: "متأخر", value: invoices.filter((i) => i.status === "overdue").length, color: "#E74C3C" },
    { label: "موافق عليه", value: invoices.filter((i) => i.status === "approved").length, color: "#2E86AB" },
    { label: "مسودة", value: invoices.filter((i) => i.status === "draft").length, color: "#6B7C93" },
  ];

  const vesselStats = vessels.map((v) => ({
    name: v.name,
    invoiceCount: invoices.filter((i) => i.vesselId === v.id).length,
    totalAmount: invoices.filter((i) => i.vesselId === v.id).reduce((s, i) => s + i.amount, 0),
  })).sort((a, b) => b.totalAmount - a.totalAmount);

  return (
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16 }}>
      {/* Financial Summary */}
      <Text style={{ fontSize: 16, fontWeight: "700", color: "#1A2332", textAlign: "right", marginBottom: 12 }}>
        الملخص المالي
      </Text>
      <View style={{ flexDirection: "row-reverse", gap: 10, marginBottom: 16 }}>
        <View style={{ flex: 1, backgroundColor: "#EAFAF1", borderRadius: 14, padding: 14 }}>
          <MaterialIcons name="paid" size={22} color="#27AE60" />
          <Text style={{ fontSize: 20, fontWeight: "800", color: "#27AE60", marginTop: 8 }}>${totalRevenue.toLocaleString()}</Text>
          <Text style={{ fontSize: 12, color: "#6B7C93", marginTop: 4 }}>إيرادات محصلة</Text>
        </View>
        <View style={{ flex: 1, backgroundColor: "#FEF9E7", borderRadius: 14, padding: 14 }}>
          <MaterialIcons name="schedule" size={22} color="#F39C12" />
          <Text style={{ fontSize: 20, fontWeight: "800", color: "#F39C12", marginTop: 8 }}>${pendingRevenue.toLocaleString()}</Text>
          <Text style={{ fontSize: 12, color: "#6B7C93", marginTop: 4 }}>إيرادات معلقة</Text>
        </View>
      </View>
      <View style={{ flexDirection: "row-reverse", gap: 10, marginBottom: 20 }}>
        <View style={{ flex: 1, backgroundColor: "#FDEDEC", borderRadius: 14, padding: 14 }}>
          <MaterialIcons name="warning" size={22} color="#E74C3C" />
          <Text style={{ fontSize: 20, fontWeight: "800", color: "#E74C3C", marginTop: 8 }}>${overdueRevenue.toLocaleString()}</Text>
          <Text style={{ fontSize: 12, color: "#6B7C93", marginTop: 4 }}>إيرادات متأخرة</Text>
        </View>
        <View style={{ flex: 1, backgroundColor: "#F5EEF8", borderRadius: 14, padding: 14 }}>
          <MaterialIcons name="compare-arrows" size={22} color="#9B59B6" />
          <Text style={{ fontSize: 20, fontWeight: "800", color: "#9B59B6", marginTop: 8 }}>${totalDiscrepancy.toLocaleString()}</Text>
          <Text style={{ fontSize: 12, color: "#6B7C93", marginTop: 4 }}>إجمالي الفروقات</Text>
        </View>
      </View>

      {/* Invoice Status Chart */}
      <Text style={{ fontSize: 16, fontWeight: "700", color: "#1A2332", textAlign: "right", marginBottom: 12 }}>
        توزيع الفواتير حسب الحالة
      </Text>
      <View style={{ backgroundColor: "white", borderRadius: 16, padding: 16, marginBottom: 20, shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 6, elevation: 2 }}>
        {byStatus.map((item) => {
          const total = invoices.length || 1;
          const pct = Math.round((item.value / total) * 100);
          return (
            <View key={item.label} style={{ marginBottom: 12 }}>
              <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", marginBottom: 4 }}>
                <Text style={{ fontSize: 13, fontWeight: "600", color: "#1A2332" }}>{item.label}</Text>
                <Text style={{ fontSize: 13, color: "#6B7C93" }}>{item.value} ({pct}%)</Text>
              </View>
              <View style={{ backgroundColor: "#F0F4F8", borderRadius: 6, height: 8, overflow: "hidden" }}>
                <View style={{ backgroundColor: item.color, width: `${pct}%`, height: "100%", borderRadius: 6 }} />
              </View>
            </View>
          );
        })}
      </View>

      {/* Vessels Performance */}
      <Text style={{ fontSize: 16, fontWeight: "700", color: "#1A2332", textAlign: "right", marginBottom: 12 }}>
        أداء السفن
      </Text>
      {/* Pricing Report Link */}
      <TouchableOpacity
        onPress={() => router.push("/pricing-report")}
        style={{ backgroundColor: "#1E3A5F", borderRadius: 14, padding: 16, marginBottom: 20, flexDirection: "row-reverse", alignItems: "center", justifyContent: "space-between" }}
      >
        <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10 }}>
          <MaterialIcons name="price-change" size={22} color="white" />
          <View>
            <Text style={{ color: "white", fontSize: 14, fontWeight: "700" }}>تقرير جداول الأسعار</Text>
            <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 12 }}>عرض وإدارة جميع الأسعار والرسوم</Text>
          </View>
        </View>
        <MaterialIcons name="chevron-left" size={22} color="rgba(255,255,255,0.7)" />
      </TouchableOpacity>

      {vesselStats.map((v, i) => (
        <View key={v.name} style={{
          backgroundColor: "white",
          borderRadius: 14,
          padding: 14,
          marginBottom: 10,
          flexDirection: "row-reverse",
          justifyContent: "space-between",
          alignItems: "center",
          shadowColor: "#000",
          shadowOffset: { width: 0, height: 1 },
          shadowOpacity: 0.05,
          shadowRadius: 4,
          elevation: 2,
        }}>
          <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10 }}>
            <View style={{
              width: 32,
              height: 32,
              borderRadius: 8,
              backgroundColor: i === 0 ? "#FEF9E7" : "#F0F4F8",
              alignItems: "center",
              justifyContent: "center",
            }}>
              <Text style={{ fontSize: 14, fontWeight: "700", color: i === 0 ? "#F39C12" : "#6B7C93" }}>#{i + 1}</Text>
            </View>
            <View>
              <Text style={{ fontSize: 14, fontWeight: "700", color: "#1A2332" }}>{v.name}</Text>
              <Text style={{ fontSize: 12, color: "#6B7C93" }}>{v.invoiceCount} فاتورة</Text>
            </View>
          </View>
          <Text style={{ fontSize: 15, fontWeight: "700", color: "#1E3A5F" }}>${v.totalAmount.toLocaleString()}</Text>
        </View>
      ))}
    </ScrollView>
  );
}

// ─── Memos Tab ────────────────────────────────────────────────────────────────
const MEMO_STATUS_COLORS: Record<string, string> = {
  draft: "#6B7C93",
  sent: "#27AE60",
  archived: "#9B59B6",
};
const MEMO_STATUS_LABELS: Record<string, string> = {
  draft: "مسودة",
  sent: "مُرسلة",
  archived: "مؤرشفة",
};
const MEMO_TYPE_LABELS: Record<string, string> = {
  communication: "تواصل",
  complaint: "شكوى",
  inquiry: "استفسار",
  notification: "إشعار",
};
const MEMO_TYPE_COLORS: Record<string, string> = {
  communication: "#2E86AB",
  complaint: "#E74C3C",
  inquiry: "#F39C12",
  notification: "#27AE60",
};

function AddMemoModal({ visible, onClose, onAdd }: {
  visible: boolean;
  onClose: () => void;
  onAdd: (memo: Omit<Memo, "id" | "createdAt" | "updatedAt">) => void;
}) {
  const { vessels } = useApp();
  const [selectedVesselId, setSelectedVesselId] = useState<number | null>(null);
  const [title, setTitle] = useState("");
  const [content, setContent] = useState("");
  const [recipientEntity, setRecipientEntity] = useState("");
  const [memoType, setMemoType] = useState<Memo["memoType"]>("communication");
  const [status, setStatus] = useState<Memo["status"]>("draft");

  const handleAdd = () => {
    if (!selectedVesselId || !title.trim() || !content.trim()) {
      Alert.alert("خطأ", "يرجى ملء جميع الحقول المطلوبة");
      return;
    }
    const vessel = vessels.find((v) => v.id === selectedVesselId);
    onAdd({
      vesselId: selectedVesselId,
      vesselName: vessel?.name,
      title: title.trim(),
      content: content.trim(),
      recipientEntity: recipientEntity.trim() || undefined,
      memoType,
      status,
    });
    setTitle(""); setContent(""); setRecipientEntity("");
    setSelectedVesselId(null); setMemoType("communication"); setStatus("draft");
    onClose();
  };

  const inputStyle = {
    backgroundColor: "#F0F4F8",
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 12,
    fontSize: 15,
    color: "#1A2332",
    textAlign: "right" as const,
    borderWidth: 1,
    borderColor: "#D1DCE8",
    marginBottom: 12,
  };

  return (
    <Modal visible={visible} animationType="slide" presentationStyle="pageSheet">
      <View style={{ flex: 1, backgroundColor: "#F0F4F8" }}>
        <View style={{ backgroundColor: "#1E3A5F", paddingHorizontal: 20, paddingTop: 50, paddingBottom: 20, flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" }}>
          <Text style={{ color: "white", fontSize: 20, fontWeight: "700" }}>إنشاء مذكرة جديدة</Text>
          <TouchableOpacity onPress={onClose}><MaterialIcons name="close" size={24} color="white" /></TouchableOpacity>
        </View>
        <ScrollView style={{ flex: 1, padding: 20 }}>
          <Text style={{ fontSize: 13, fontWeight: "600", color: "#6B7C93", textAlign: "right", marginBottom: 8 }}>اختيار السفينة *</Text>
          <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 12 }}>
            <View style={{ flexDirection: "row", gap: 8 }}>
              {vessels.map((v) => (
                <TouchableOpacity key={v.id} onPress={() => setSelectedVesselId(v.id)} style={{ backgroundColor: selectedVesselId === v.id ? "#1E3A5F" : "white", borderRadius: 10, paddingHorizontal: 14, paddingVertical: 8, borderWidth: 1, borderColor: selectedVesselId === v.id ? "#1E3A5F" : "#D1DCE8" }}>
                  <Text style={{ color: selectedVesselId === v.id ? "white" : "#1A2332", fontSize: 13, fontWeight: "600" }}>{v.name}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </ScrollView>
          <Text style={{ fontSize: 13, fontWeight: "600", color: "#6B7C93", textAlign: "right", marginBottom: 6 }}>عنوان المذكرة *</Text>
          <TextInput value={title} onChangeText={setTitle} placeholder="عنوان المذكرة" placeholderTextColor="#9BA1A6" style={inputStyle} />
          <Text style={{ fontSize: 13, fontWeight: "600", color: "#6B7C93", textAlign: "right", marginBottom: 6 }}>المحتوى *</Text>
          <TextInput value={content} onChangeText={setContent} placeholder="محتوى المذكرة..." placeholderTextColor="#9BA1A6" multiline numberOfLines={5} style={{ ...inputStyle, height: 120, textAlignVertical: "top" }} />
          <Text style={{ fontSize: 13, fontWeight: "600", color: "#6B7C93", textAlign: "right", marginBottom: 6 }}>الجهة المستلمة</Text>
          <TextInput value={recipientEntity} onChangeText={setRecipientEntity} placeholder="سلطة الميناء" placeholderTextColor="#9BA1A6" style={inputStyle} />
          <Text style={{ fontSize: 13, fontWeight: "600", color: "#6B7C93", textAlign: "right", marginBottom: 8 }}>نوع المذكرة</Text>
          <View style={{ flexDirection: "row-reverse", flexWrap: "wrap", gap: 8, marginBottom: 12 }}>
            {(["communication", "complaint", "inquiry", "notification"] as Memo["memoType"][]).map((t) => (
              <TouchableOpacity key={t} onPress={() => setMemoType(t)} style={{ backgroundColor: memoType === t ? MEMO_TYPE_COLORS[t] : "white", borderRadius: 10, paddingHorizontal: 14, paddingVertical: 8, borderWidth: 1, borderColor: memoType === t ? MEMO_TYPE_COLORS[t] : "#D1DCE8" }}>
                <Text style={{ color: memoType === t ? "white" : "#1A2332", fontSize: 13, fontWeight: "600" }}>{MEMO_TYPE_LABELS[t]}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <Text style={{ fontSize: 13, fontWeight: "600", color: "#6B7C93", textAlign: "right", marginBottom: 8 }}>الحالة</Text>
          <View style={{ flexDirection: "row-reverse", gap: 8, marginBottom: 20 }}>
            {(["draft", "sent"] as Memo["status"][]).map((s) => (
              <TouchableOpacity key={s} onPress={() => setStatus(s)} style={{ flex: 1, backgroundColor: status === s ? MEMO_STATUS_COLORS[s] : "white", borderRadius: 10, paddingVertical: 10, alignItems: "center", borderWidth: 1, borderColor: status === s ? MEMO_STATUS_COLORS[s] : "#D1DCE8" }}>
                <Text style={{ color: status === s ? "white" : "#1A2332", fontSize: 13, fontWeight: "600" }}>{MEMO_STATUS_LABELS[s]}</Text>
              </TouchableOpacity>
            ))}
          </View>
          <TouchableOpacity onPress={handleAdd} style={{ backgroundColor: "#1E3A5F", borderRadius: 14, paddingVertical: 16, alignItems: "center", marginBottom: 40 }}>
            <Text style={{ color: "white", fontSize: 17, fontWeight: "700" }}>إنشاء المذكرة</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
    </Modal>
  );
}

function MemosTab() {
  const { memos, deleteMemo, addMemo, updateMemo, currentUser } = useApp();
  const [search, setSearch] = useState("");
  const [showAddModal, setShowAddModal] = useState(false);
  const canEdit = currentUser?.role === "admin" || currentUser?.role === "accountant";

  const filtered = memos.filter((m) =>
    m.title.toLowerCase().includes(search.toLowerCase()) ||
    (m.vesselName || "").toLowerCase().includes(search.toLowerCase())
  );

  return (
    <View style={{ flex: 1 }}>
      <View style={{ backgroundColor: "white", paddingHorizontal: 16, paddingVertical: 12, flexDirection: "row-reverse", gap: 10, alignItems: "center" }}>
        <View style={{ flex: 1, backgroundColor: "#F0F4F8", borderRadius: 10, flexDirection: "row-reverse", alignItems: "center", paddingHorizontal: 12, paddingVertical: 8, gap: 6 }}>
          <MaterialIcons name="search" size={18} color="#6B7C93" />
          <TextInput value={search} onChangeText={setSearch} placeholder="بحث في المذكرات..." placeholderTextColor="#9BA1A6" style={{ flex: 1, color: "#1A2332", fontSize: 14, textAlign: "right" }} />
        </View>
        {canEdit && (
          <TouchableOpacity onPress={() => setShowAddModal(true)} style={{ backgroundColor: "#1E3A5F", borderRadius: 10, paddingHorizontal: 14, paddingVertical: 8 }}>
            <MaterialIcons name="add" size={20} color="white" />
          </TouchableOpacity>
        )}
      </View>
      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={{ backgroundColor: "white", borderRadius: 14, padding: 14, marginHorizontal: 16, marginBottom: 10, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2, borderRightWidth: 4, borderRightColor: MEMO_TYPE_COLORS[item.memoType] }}>
            <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "flex-start" }}>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 14, fontWeight: "700", color: "#1A2332", marginBottom: 4 }}>{item.title}</Text>
                <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 4 }}>
                  <MaterialIcons name="directions-boat" size={13} color="#6B7C93" />
                  <Text style={{ fontSize: 12, color: "#6B7C93" }}>{item.vesselName}</Text>
                </View>
                <Text style={{ fontSize: 12, color: "#9BA1A6", marginTop: 4 }} numberOfLines={2}>{item.content}</Text>
              </View>
              <View style={{ alignItems: "flex-end", gap: 6 }}>
                <View style={{ backgroundColor: MEMO_TYPE_COLORS[item.memoType] + "20", borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 }}>
                  <Text style={{ color: MEMO_TYPE_COLORS[item.memoType], fontSize: 11, fontWeight: "700" }}>{MEMO_TYPE_LABELS[item.memoType]}</Text>
                </View>
                <View style={{ backgroundColor: MEMO_STATUS_COLORS[item.status] + "20", borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 }}>
                  <Text style={{ color: MEMO_STATUS_COLORS[item.status], fontSize: 11, fontWeight: "700" }}>{MEMO_STATUS_LABELS[item.status]}</Text>
                </View>
              </View>
            </View>
            {canEdit && (
              <View style={{ flexDirection: "row-reverse", gap: 8, marginTop: 10, paddingTop: 10, borderTopWidth: 1, borderTopColor: "#F0F4F8" }}>
                {item.status === "draft" && (
                  <TouchableOpacity onPress={() => updateMemo(item.id, { status: "sent", sentDate: new Date().toISOString() })} style={{ flex: 1, backgroundColor: "#EAFAF1", borderRadius: 8, paddingVertical: 8, alignItems: "center" }}>
                    <Text style={{ color: "#27AE60", fontSize: 13, fontWeight: "600" }}>إرسال</Text>
                  </TouchableOpacity>
                )}
                {item.status === "sent" && (
                  <TouchableOpacity onPress={() => updateMemo(item.id, { status: "archived" })} style={{ flex: 1, backgroundColor: "#F5EEF8", borderRadius: 8, paddingVertical: 8, alignItems: "center" }}>
                    <Text style={{ color: "#9B59B6", fontSize: 13, fontWeight: "600" }}>أرشفة</Text>
                  </TouchableOpacity>
                )}
                <TouchableOpacity onPress={() => Alert.alert("حذف", "هل تريد حذف هذه المذكرة؟", [{ text: "إلغاء", style: "cancel" }, { text: "حذف", style: "destructive", onPress: () => deleteMemo(item.id) }])} style={{ width: 36, height: 36, backgroundColor: "#FEE2E2", borderRadius: 8, alignItems: "center", justifyContent: "center" }}>
                  <MaterialIcons name="delete" size={16} color="#E74C3C" />
                </TouchableOpacity>
              </View>
            )}
          </View>
        )}
        contentContainerStyle={{ paddingTop: 12, paddingBottom: 20 }}
        ListEmptyComponent={<View style={{ alignItems: "center", paddingVertical: 60 }}><MaterialIcons name="message" size={60} color="#D1DCE8" /><Text style={{ color: "#6B7C93", fontSize: 16, marginTop: 16 }}>لا توجد مذكرات</Text></View>}
        showsVerticalScrollIndicator={false}
      />
      <AddMemoModal visible={showAddModal} onClose={() => setShowAddModal(false)} onAdd={addMemo} />
    </View>
  );
}

// ─── Archive Tab ──────────────────────────────────────────────────────────────
function ArchiveTab() {
  const { archives } = useApp();
  const [search, setSearch] = useState("");
  const [filterType, setFilterType] = useState("all");

  const filtered = archives.filter((a) => {
    const matchSearch = a.title.toLowerCase().includes(search.toLowerCase()) ||
      (a.description || "").toLowerCase().includes(search.toLowerCase());
    const matchType = filterType === "all" || a.referenceType === filterType;
    return matchSearch && matchType;
  });

  const typeColors: Record<string, string> = {
    invoice: "#F39C12",
    memo: "#2E86AB",
    vessel: "#1E3A5F",
    document: "#9B59B6",
  };
  const typeLabels: Record<string, string> = {
    invoice: "فاتورة",
    memo: "مذكرة",
    vessel: "سفينة",
    document: "مستند",
  };
  const typeIcons: Record<string, string> = {
    invoice: "description",
    memo: "message",
    vessel: "directions-boat",
    document: "folder",
  };

  return (
    <View style={{ flex: 1 }}>
      <View style={{ backgroundColor: "white", paddingHorizontal: 16, paddingVertical: 12 }}>
        <View style={{ backgroundColor: "#F0F4F8", borderRadius: 10, flexDirection: "row-reverse", alignItems: "center", paddingHorizontal: 12, paddingVertical: 8, gap: 6, marginBottom: 10 }}>
          <MaterialIcons name="search" size={18} color="#6B7C93" />
          <TextInput value={search} onChangeText={setSearch} placeholder="بحث في الأرشيف..." placeholderTextColor="#9BA1A6" style={{ flex: 1, color: "#1A2332", fontSize: 14, textAlign: "right" }} />
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false}>
          <View style={{ flexDirection: "row", gap: 8 }}>
            {[{ key: "all", label: "الكل" }, { key: "invoice", label: "فواتير" }, { key: "memo", label: "مذكرات" }, { key: "document", label: "مستندات" }].map((t) => (
              <TouchableOpacity key={t.key} onPress={() => setFilterType(t.key)} style={{ backgroundColor: filterType === t.key ? "#1E3A5F" : "#F0F4F8", borderRadius: 10, paddingHorizontal: 14, paddingVertical: 6 }}>
                <Text style={{ color: filterType === t.key ? "white" : "#6B7C93", fontSize: 13, fontWeight: "600" }}>{t.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </ScrollView>
      </View>
      <FlatList
        data={filtered}
        keyExtractor={(item) => item.id.toString()}
        renderItem={({ item }) => (
          <View style={{ backgroundColor: "white", borderRadius: 14, padding: 14, marginHorizontal: 16, marginBottom: 10, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
            <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 12 }}>
              <View style={{ width: 44, height: 44, borderRadius: 12, backgroundColor: (typeColors[item.referenceType] || "#6B7C93") + "20", alignItems: "center", justifyContent: "center" }}>
                <MaterialIcons name={(typeIcons[item.referenceType] || "folder") as any} size={22} color={typeColors[item.referenceType] || "#6B7C93"} />
              </View>
              <View style={{ flex: 1 }}>
                <Text style={{ fontSize: 14, fontWeight: "700", color: "#1A2332", marginBottom: 2 }}>{item.title}</Text>
                {item.description && <Text style={{ fontSize: 12, color: "#6B7C93" }} numberOfLines={1}>{item.description}</Text>}
                <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 8, marginTop: 6 }}>
                  <View style={{ backgroundColor: (typeColors[item.referenceType] || "#6B7C93") + "20", borderRadius: 6, paddingHorizontal: 8, paddingVertical: 2 }}>
                    <Text style={{ color: typeColors[item.referenceType] || "#6B7C93", fontSize: 11, fontWeight: "600" }}>{typeLabels[item.referenceType] || item.referenceType}</Text>
                  </View>
                  <Text style={{ fontSize: 11, color: "#9BA1A6" }}>{new Date(item.createdAt).toLocaleDateString("ar-SA")}</Text>
                </View>
              </View>
            </View>
            {item.tags && (
              <View style={{ flexDirection: "row-reverse", flexWrap: "wrap", gap: 6, marginTop: 10 }}>
                {item.tags.split(",").map((tag, i) => (
                  <View key={i} style={{ backgroundColor: "#F0F4F8", borderRadius: 6, paddingHorizontal: 8, paddingVertical: 3 }}>
                    <Text style={{ fontSize: 11, color: "#6B7C93" }}>#{tag.trim()}</Text>
                  </View>
                ))}
              </View>
            )}
          </View>
        )}
        contentContainerStyle={{ paddingTop: 12, paddingBottom: 20 }}
        ListEmptyComponent={<View style={{ alignItems: "center", paddingVertical: 60 }}><MaterialIcons name="archive" size={60} color="#D1DCE8" /><Text style={{ color: "#6B7C93", fontSize: 16, marginTop: 16 }}>لا توجد ملفات مؤرشفة</Text></View>}
        showsVerticalScrollIndicator={false}
      />
    </View>
  );
}

// ─── Payments Tab ─────────────────────────────────────────────────────────────
function PaymentsTab() {
  const { payments, updatePayment } = useApp();

  const statusColors: Record<string, string> = {
    completed: "#27AE60",
    pending: "#F39C12",
    failed: "#E74C3C",
    refunded: "#9B59B6",
  };
  const statusLabels: Record<string, string> = {
    completed: "مكتمل",
    pending: "معلق",
    failed: "فاشل",
    refunded: "مُسترد",
  };

  const totalCompleted = payments.filter((p) => p.status === "completed").reduce((s, p) => s + p.amount, 0);
  const totalPending = payments.filter((p) => p.status === "pending").reduce((s, p) => s + p.amount, 0);
  const totalFailed = payments.filter((p) => p.status === "failed").reduce((s, p) => s + p.amount, 0);

  return (
    <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16 }}>
      {/* Summary */}
      <View style={{ flexDirection: "row-reverse", gap: 10, marginBottom: 16 }}>
        <View style={{ flex: 1, backgroundColor: "#EAFAF1", borderRadius: 14, padding: 12 }}>
          <MaterialIcons name="check-circle" size={20} color="#27AE60" />
          <Text style={{ fontSize: 16, fontWeight: "700", color: "#27AE60", marginTop: 6 }}>${totalCompleted.toLocaleString()}</Text>
          <Text style={{ fontSize: 11, color: "#6B7C93" }}>مكتمل</Text>
        </View>
        <View style={{ flex: 1, backgroundColor: "#FEF9E7", borderRadius: 14, padding: 12 }}>
          <MaterialIcons name="schedule" size={20} color="#F39C12" />
          <Text style={{ fontSize: 16, fontWeight: "700", color: "#F39C12", marginTop: 6 }}>${totalPending.toLocaleString()}</Text>
          <Text style={{ fontSize: 11, color: "#6B7C93" }}>معلق</Text>
        </View>
        <View style={{ flex: 1, backgroundColor: "#FDEDEC", borderRadius: 14, padding: 12 }}>
          <MaterialIcons name="cancel" size={20} color="#E74C3C" />
          <Text style={{ fontSize: 16, fontWeight: "700", color: "#E74C3C", marginTop: 6 }}>${totalFailed.toLocaleString()}</Text>
          <Text style={{ fontSize: 11, color: "#6B7C93" }}>فاشل</Text>
        </View>
      </View>

      {/* Payments List */}
      <Text style={{ fontSize: 16, fontWeight: "700", color: "#1A2332", textAlign: "right", marginBottom: 12 }}>سجل الدفعات</Text>
      {payments.map((payment) => (
        <View key={payment.id} style={{ backgroundColor: "white", borderRadius: 14, padding: 14, marginBottom: 10, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
          <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "flex-start" }}>
            <View>
              <Text style={{ fontSize: 14, fontWeight: "700", color: "#1A2332" }}>{payment.invoiceNumber}</Text>
              <Text style={{ fontSize: 12, color: "#6B7C93", marginTop: 2 }}>{payment.method}</Text>
              <Text style={{ fontSize: 12, color: "#9BA1A6", marginTop: 2 }}>Ref: {payment.reference}</Text>
            </View>
            <View style={{ alignItems: "flex-end" }}>
              <Text style={{ fontSize: 16, fontWeight: "800", color: "#1E3A5F" }}>${payment.amount.toLocaleString()}</Text>
              <View style={{ backgroundColor: (statusColors[payment.status] || "#6B7C93") + "20", borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3, marginTop: 4 }}>
                <Text style={{ color: statusColors[payment.status] || "#6B7C93", fontSize: 11, fontWeight: "700" }}>{statusLabels[payment.status] || payment.status}</Text>
              </View>
            </View>
          </View>
          {payment.notes && <Text style={{ fontSize: 12, color: "#6B7C93", marginTop: 8, textAlign: "right" }}>{payment.notes}</Text>}
          {payment.status === "failed" && (
            <TouchableOpacity
              onPress={() => updatePayment(payment.id, { status: "pending" })}
              style={{ backgroundColor: "#FEF9E7", borderRadius: 8, paddingVertical: 8, alignItems: "center", marginTop: 10 }}
            >
              <Text style={{ color: "#F39C12", fontSize: 13, fontWeight: "600" }}>إعادة المحاولة</Text>
            </TouchableOpacity>
          )}
        </View>
      ))}
    </ScrollView>
  );
}

// ─── Main Screen ──────────────────────────────────────────────────────────────
export default function ReportsScreen() {
  const [activeTab, setActiveTab] = useState<Tab>("reports");
  const router = useRouter();

  const tabs: { key: Tab; label: string; icon: string }[] = [
    { key: "reports", label: "التقارير", icon: "bar-chart" },
    { key: "memos", label: "المذكرات", icon: "message" },
    { key: "archive", label: "الأرشيف", icon: "archive" },
    { key: "payments", label: "الدفع", icon: "payment" },
  ];

  return (
    <ScreenContainer containerClassName="bg-background">
      {/* Header */}
      <View style={{ backgroundColor: "#1E3A5F", paddingHorizontal: 20, paddingTop: 16, paddingBottom: 16 }}>
        <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" }}>
          <Text style={{ color: "white", fontSize: 22, fontWeight: "800", textAlign: "right" }}>
            {tabs.find((t) => t.key === activeTab)?.label}
          </Text>
          {/* Quick Access Buttons */}
          <View style={{ flexDirection: "row-reverse", gap: 8 }}>
            <TouchableOpacity
              onPress={() => router.push("/pricing")}
              style={{ backgroundColor: "rgba(255,255,255,0.15)", borderRadius: 10, paddingHorizontal: 10, paddingVertical: 6, flexDirection: "row-reverse", alignItems: "center", gap: 4 }}
            >
              <MaterialIcons name="calculate" size={14} color="white" />
              <Text style={{ color: "white", fontSize: 11, fontWeight: "700" }}>الأسعار</Text>
            </TouchableOpacity>
            <TouchableOpacity
              onPress={() => router.push("/review")}
              style={{ backgroundColor: "rgba(255,255,255,0.15)", borderRadius: 10, paddingHorizontal: 10, paddingVertical: 6, flexDirection: "row-reverse", alignItems: "center", gap: 4 }}
            >
              <MaterialIcons name="rate-review" size={14} color="white" />
              <Text style={{ color: "white", fontSize: 11, fontWeight: "700" }}>مراجعة</Text>
            </TouchableOpacity>
          </View>
        </View>
      </View>

      {/* Tab Bar */}
      <View style={{ backgroundColor: "white", flexDirection: "row-reverse", paddingHorizontal: 8, paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: "#F0F4F8" }}>
        {tabs.map((tab) => (
          <TouchableOpacity
            key={tab.key}
            onPress={() => setActiveTab(tab.key)}
            style={{
              flex: 1,
              alignItems: "center",
              paddingVertical: 8,
              borderRadius: 10,
              backgroundColor: activeTab === tab.key ? "#EBF2FA" : "transparent",
              gap: 3,
            }}
          >
            <MaterialIcons name={tab.icon as any} size={20} color={activeTab === tab.key ? "#1E3A5F" : "#6B7C93"} />
            <Text style={{ fontSize: 11, fontWeight: "600", color: activeTab === tab.key ? "#1E3A5F" : "#6B7C93" }}>
              {tab.label}
            </Text>
          </TouchableOpacity>
        ))}
      </View>

      {/* Content */}
      <View style={{ flex: 1 }}>
        {activeTab === "reports" && <ReportsTab />}
        {activeTab === "memos" && <MemosTab />}
        {activeTab === "archive" && <ArchiveTab />}
        {activeTab === "payments" && <PaymentsTab />}
      </View>
    </ScreenContainer>
  );
}
