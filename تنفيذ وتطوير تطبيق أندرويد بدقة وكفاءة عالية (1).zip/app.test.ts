import { describe, it, expect } from "vitest";
import { defaultVessels, defaultInvoices, defaultMemos, defaultNotifications, defaultPayments } from "../lib/seed-data";

describe("Seed Data Tests", () => {
  it("should have vessels with required fields", () => {
    expect(defaultVessels.length).toBeGreaterThan(0);
    for (const vessel of defaultVessels) {
      expect(vessel.id).toBeDefined();
      expect(vessel.name).toBeTruthy();
      expect(vessel.type).toBeTruthy();
      expect(["active", "inactive", "maintenance", "docked"]).toContain(vessel.status);
      expect(vessel.createdAt).toBeTruthy();
      expect(vessel.updatedAt).toBeTruthy();
    }
  });

  it("should have invoices with required fields", () => {
    expect(defaultInvoices.length).toBeGreaterThan(0);
    for (const invoice of defaultInvoices) {
      expect(invoice.id).toBeDefined();
      expect(invoice.invoiceNumber).toBeTruthy();
      expect(invoice.vesselId).toBeDefined();
      expect(invoice.amount).toBeGreaterThan(0);
      expect(invoice.currency).toBeTruthy();
      expect(["draft", "pending", "approved", "rejected", "paid", "overdue"]).toContain(invoice.status);
    }
  });

  it("should have memos with required fields", () => {
    expect(defaultMemos.length).toBeGreaterThan(0);
    for (const memo of defaultMemos) {
      expect(memo.id).toBeDefined();
      expect(memo.title).toBeTruthy();
      expect(memo.content).toBeTruthy();
      expect(["communication", "complaint", "inquiry", "notification"]).toContain(memo.memoType);
      expect(["draft", "sent", "archived"]).toContain(memo.status);
    }
  });

  it("should have notifications with required fields", () => {
    expect(defaultNotifications.length).toBeGreaterThan(0);
    for (const notif of defaultNotifications) {
      expect(notif.id).toBeDefined();
      expect(notif.title).toBeTruthy();
      expect(notif.message).toBeTruthy();
      expect(["info", "warning", "error", "success"]).toContain(notif.type);
      expect(typeof notif.isRead).toBe("boolean");
    }
  });

  it("should have payments with required fields", () => {
    expect(defaultPayments.length).toBeGreaterThan(0);
    for (const payment of defaultPayments) {
      expect(payment.id).toBeDefined();
      expect(payment.invoiceNumber).toBeTruthy();
      expect(payment.amount).toBeGreaterThan(0);
      expect(["completed", "pending", "failed", "refunded"]).toContain(payment.status);
    }
  });

  it("should calculate total revenue correctly", () => {
    const paidInvoices = defaultInvoices.filter((i) => i.status === "paid");
    const totalRevenue = paidInvoices.reduce((sum, inv) => sum + inv.amount, 0);
    expect(totalRevenue).toBeGreaterThan(0);
    expect(totalRevenue).toBe(125000); // Only INV-2026-001 is paid
  });

  it("should count unread notifications correctly", () => {
    const unreadCount = defaultNotifications.filter((n) => !n.isRead).length;
    expect(unreadCount).toBeGreaterThan(0);
    expect(unreadCount).toBeLessThanOrEqual(defaultNotifications.length);
  });

  it("should have vessel invoices linked correctly", () => {
    for (const invoice of defaultInvoices) {
      const vessel = defaultVessels.find((v) => v.id === invoice.vesselId);
      expect(vessel).toBeDefined();
      expect(invoice.vesselName).toBe(vessel?.name);
    }
  });

  it("should have active vessels", () => {
    const activeVessels = defaultVessels.filter((v) => v.status === "active" || v.status === "docked");
    expect(activeVessels.length).toBeGreaterThan(0);
  });

  it("should have overdue invoices", () => {
    const overdueInvoices = defaultInvoices.filter((i) => i.status === "overdue");
    expect(overdueInvoices.length).toBeGreaterThan(0);
  });
});

describe("Authentication Logic Tests", () => {
  const DEFAULT_USERS = [
    { id: 1, name: "مدير النظام", email: "admin@habib.com", password: "admin123", role: "admin" },
    { id: 2, name: "المحاسب", email: "accountant@habib.com", password: "acc123", role: "accountant" },
    { id: 3, name: "المراجع", email: "reviewer@habib.com", password: "rev123", role: "reviewer" },
  ];

  const login = (email: string, password: string) => {
    return DEFAULT_USERS.find((u) => u.email === email && u.password === password) || null;
  };

  it("should login with valid credentials", () => {
    const user = login("admin@habib.com", "admin123");
    expect(user).not.toBeNull();
    expect(user?.role).toBe("admin");
  });

  it("should reject invalid password", () => {
    const user = login("admin@habib.com", "wrongpassword");
    expect(user).toBeNull();
  });

  it("should reject invalid email", () => {
    const user = login("unknown@habib.com", "admin123");
    expect(user).toBeNull();
  });

  it("should login accountant correctly", () => {
    const user = login("accountant@habib.com", "acc123");
    expect(user).not.toBeNull();
    expect(user?.role).toBe("accountant");
  });

  it("should login reviewer correctly", () => {
    const user = login("reviewer@habib.com", "rev123");
    expect(user).not.toBeNull();
    expect(user?.role).toBe("reviewer");
  });
});

describe("Business Logic Tests", () => {
  it("should filter invoices by status", () => {
    const pendingInvoices = defaultInvoices.filter((i) => i.status === "pending");
    const overdueInvoices = defaultInvoices.filter((i) => i.status === "overdue");
    expect(pendingInvoices.length + overdueInvoices.length).toBeGreaterThan(0);
  });

  it("should calculate discrepancy correctly", () => {
    const invoicesWithDiscrepancy = defaultInvoices.filter((i) => i.discrepancy && i.discrepancy > 0);
    expect(invoicesWithDiscrepancy.length).toBeGreaterThan(0);
    for (const inv of invoicesWithDiscrepancy) {
      expect(inv.discrepancy).toBeGreaterThan(0);
    }
  });

  it("should have vessel performance data", () => {
    const vesselStats = defaultVessels.map((v) => ({
      name: v.name,
      invoiceCount: defaultInvoices.filter((i) => i.vesselId === v.id).length,
      totalAmount: defaultInvoices.filter((i) => i.vesselId === v.id).reduce((s, i) => s + i.amount, 0),
    }));
    expect(vesselStats.length).toBe(defaultVessels.length);
    const topVessel = vesselStats.sort((a, b) => b.totalAmount - a.totalAmount)[0];
    expect(topVessel.totalAmount).toBeGreaterThan(0);
  });
});
