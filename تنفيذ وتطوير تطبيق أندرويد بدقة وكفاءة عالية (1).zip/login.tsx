import { useState } from "react";
import {
  View,
  Text,
  TextInput,
  TouchableOpacity,
  Image,
  ScrollView,
  KeyboardAvoidingView,
  Platform,
  Alert,
  ActivityIndicator,
} from "react-native";
import { useRouter } from "expo-router";
import { useApp } from "@/lib/app-context";
import { ScreenContainer } from "@/components/screen-container";

export default function LoginScreen() {
  const router = useRouter();
  const { login } = useApp();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);

  const handleLogin = async () => {
    if (!email.trim() || !password.trim()) {
      Alert.alert("خطأ", "يرجى إدخال البريد الإلكتروني وكلمة المرور");
      return;
    }
    setIsLoading(true);
    try {
      const success = await login(email.trim(), password.trim());
      if (success) {
        router.replace("/(tabs)");
      } else {
        Alert.alert("خطأ في تسجيل الدخول", "البريد الإلكتروني أو كلمة المرور غير صحيحة");
      }
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <ScreenContainer containerClassName="bg-primary" edges={["top", "left", "right", "bottom"]}>
      <KeyboardAvoidingView
        behavior={Platform.OS === "ios" ? "padding" : "height"}
        style={{ flex: 1 }}
      >
        <ScrollView
          contentContainerStyle={{ flexGrow: 1 }}
          keyboardShouldPersistTaps="handled"
        >
          {/* Header */}
          <View className="items-center pt-16 pb-10 px-6">
            <View className="w-28 h-28 bg-white rounded-full items-center justify-center mb-6 shadow-lg">
              <Image
                source={require("@/assets/images/icon.png")}
                style={{ width: 90, height: 90, borderRadius: 45 }}
                resizeMode="contain"
              />
            </View>
            <Text className="text-3xl font-bold text-white mb-2">نظام حبيب</Text>
            <Text className="text-base text-blue-200">لإدارة السفن والفواتير</Text>
          </View>

          {/* Login Form */}
          <View className="flex-1 bg-white rounded-t-3xl px-6 pt-10 pb-6">
            <Text className="text-2xl font-bold text-foreground mb-2 text-right">تسجيل الدخول</Text>
            <Text className="text-muted mb-8 text-right">أدخل بياناتك للوصول إلى النظام</Text>

            {/* Email Field */}
            <View className="mb-5">
              <Text className="text-sm font-semibold text-foreground mb-2 text-right">البريد الإلكتروني</Text>
              <TextInput
                value={email}
                onChangeText={setEmail}
                placeholder="admin@habib.com"
                placeholderTextColor="#9BA1A6"
                keyboardType="email-address"
                autoCapitalize="none"
                textAlign="right"
                style={{
                  backgroundColor: "#F0F4F8",
                  borderRadius: 12,
                  paddingHorizontal: 16,
                  paddingVertical: 14,
                  fontSize: 16,
                  color: "#1A2332",
                  textAlign: "right",
                  borderWidth: 1,
                  borderColor: "#D1DCE8",
                }}
              />
            </View>

            {/* Password Field */}
            <View className="mb-6">
              <Text className="text-sm font-semibold text-foreground mb-2 text-right">كلمة المرور</Text>
              <View style={{ position: "relative" }}>
                <TextInput
                  value={password}
                  onChangeText={setPassword}
                  placeholder="••••••••"
                  placeholderTextColor="#9BA1A6"
                  secureTextEntry={!showPassword}
                  textAlign="right"
                  style={{
                    backgroundColor: "#F0F4F8",
                    borderRadius: 12,
                    paddingHorizontal: 16,
                    paddingVertical: 14,
                    fontSize: 16,
                    color: "#1A2332",
                    textAlign: "right",
                    borderWidth: 1,
                    borderColor: "#D1DCE8",
                  }}
                />
                <TouchableOpacity
                  onPress={() => setShowPassword(!showPassword)}
                  style={{
                    position: "absolute",
                    left: 16,
                    top: 14,
                  }}
                >
                  <Text style={{ color: "#6B7C93", fontSize: 14 }}>
                    {showPassword ? "إخفاء" : "إظهار"}
                  </Text>
                </TouchableOpacity>
              </View>
            </View>

            {/* Login Button */}
            <TouchableOpacity
              onPress={handleLogin}
              disabled={isLoading}
              style={{
                backgroundColor: "#1E3A5F",
                borderRadius: 14,
                paddingVertical: 16,
                alignItems: "center",
                marginBottom: 20,
                opacity: isLoading ? 0.7 : 1,
              }}
            >
              {isLoading ? (
                <ActivityIndicator color="white" />
              ) : (
                <Text style={{ color: "white", fontSize: 17, fontWeight: "700" }}>
                  تسجيل الدخول
                </Text>
              )}
            </TouchableOpacity>

            {/* Demo Accounts */}
            <View style={{ backgroundColor: "#F0F4F8", borderRadius: 12, padding: 16 }}>
              <Text style={{ color: "#1A2332", fontWeight: "700", marginBottom: 8, textAlign: "right", fontSize: 14 }}>
                حسابات تجريبية:
              </Text>
              {[
                { label: "مدير النظام", email: "admin@habib.com", password: "admin123" },
                { label: "المحاسب", email: "accountant@habib.com", password: "acc123" },
                { label: "المراجع", email: "reviewer@habib.com", password: "rev123" },
              ].map((acc) => (
                <TouchableOpacity
                  key={acc.email}
                  onPress={() => { setEmail(acc.email); setPassword(acc.password); }}
                  style={{ flexDirection: "row-reverse", justifyContent: "space-between", paddingVertical: 6 }}
                >
                  <Text style={{ color: "#1E3A5F", fontWeight: "600", fontSize: 13 }}>{acc.label}</Text>
                  <Text style={{ color: "#6B7C93", fontSize: 12 }}>{acc.email}</Text>
                </TouchableOpacity>
              ))}
            </View>
          </View>
        </ScrollView>
      </KeyboardAvoidingView>
    </ScreenContainer>
  );
}
