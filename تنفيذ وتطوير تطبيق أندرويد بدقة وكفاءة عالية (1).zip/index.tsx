import { ScrollView, Text, View, TouchableOpacity, Image } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useApp } from "@/lib/app-context";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

function StatCard({ icon, label, value, color, bgColor }: {
  icon: string;
  label: string;
  value: string | number;
  color: string;
  bgColor: string;
}) {
  return (
    <View style={{
      flex: 1,
      backgroundColor: "white",
      borderRadius: 16,
      padding: 16,
      margin: 4,
      shadowColor: "#000",
      shadowOffset: { width: 0, height: 2 },
      shadowOpacity: 0.08,
      shadowRadius: 8,
      elevation: 3,
    }}>
      <View style={{
        width: 44,
        height: 44,
        borderRadius: 12,
        backgroundColor: bgColor,
        alignItems: "center",
        justifyContent: "center",
        marginBottom: 10,
        alignSelf: "flex-end",
      }}>
        <MaterialIcons name={icon as any} size={22} color={color} />
      </View>
      <Text style={{ fontSize: 26, fontWeight: "800", color: "#1A2332", textAlign: "right" }}>{value}</Text>
      <Text style={{ fontSize: 12, color: "#6B7C93", marginTop: 4, textAlign: "right" }}>{label}</Text>
    </View>
  );
}

function QuickActionButton({ icon, label, color, onPress }: {
  icon: string;
  label: string;
  color: string;
  onPress: () => void;
}) {
  return (
    <TouchableOpacity
      onPress={onPress}
      style={{
        flex: 1,
        backgroundColor: "white",
        borderRadius: 14,
        padding: 16,
        margin: 4,
        alignItems: "center",
        shadowColor: "#000",
        shadowOffset: { width: 0, height: 1 },
        shadowOpacity: 0.06,
        shadowRadius: 4,
        elevation: 2,
      }}
    >
      <View style={{
        width: 48,
        height: 48,
        borderRadius: 14,
        backgroundColor: color + "20",
        alignItems: "center",
        justifyContent: "center",
        marginBottom: 8,
      }}>
        <MaterialIcons name={icon as any} size={24} color={color} />
      </View>
      <Text style={{ fontSize: 12, fontWeight: "600", color: "#1A2332", textAlign: "center" }}>{label}</Text>
    </TouchableOpacity>
  );
}

function getRoleLabel(role: string) {
  switch (role) {
    case "admin": return "مدير النظام";
    case "accountant": return "محاسب";
    case "reviewer": return "مراجع";
    case "user": return "مستخدم";
    case "client": return "عميل";
    default: return role;
  }
}

function getRoleColor(role: string) {
  switch (role) {
    case "admin": return "#1E3A5F";
    case "accountant": return "#27AE60";
    case "reviewer": return "#F39C12";
    case "user": return "#6B7C93";
    case "client": return "#9B59B6";
    default: return "#6B7C93";
  }
}

function getInvoiceStatusLabel(status: string) {
  switch (status) {
    case "paid": return "مدفوع";
    case "pending": return "معلق";
    case "overdue": return "متأخر";
    case "approved": return "موافق عليه";
    case "draft": return "مسودة";
    case "rejected": return "مرفوض";
    default: return status;
  }
}

function getInvoiceStatusColor(status: string) {
  switch (status) {
    case "paid": return "#27AE60";
    case "pending": return "#F39C12";
    case "overdue": return "#E74C3C";
    case "approved": return "#2E86AB";
    case "draft": return "#6B7C93";
    case "rejected": return "#E74C3C";
    default: return "#6B7C93";
  }
}

export default function HomeScreen() {
  const router = useRouter();
  const { currentUser, vessels, invoices, memos, archives, notifications } = useApp();

  const activeVessels = vessels.filter((v) => v.status === "active" || v.status === "docked").length;
  const pendingInvoices = invoices.filter((v) => v.status === "pending" || v.status === "overdue").length;
  const unreadNotifications = notifications.filter((n) => !n.isRead).length;
  const recentInvoices = invoices.slice(0, 3);

  const totalRevenue = invoices
    .filter((inv) => inv.status === "paid")
    .reduce((sum, inv) => sum + inv.amount, 0);

  return (
    <ScreenContainer containerClassName="bg-background">
      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Header */}
        <View style={{
          backgroundColor: "#1E3A5F",
          paddingHorizontal: 20,
          paddingTop: 20,
          paddingBottom: 30,
        }}>
          <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
            <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 12 }}>
              <View style={{
                width: 46,
                height: 46,
                borderRadius: 23,
                backgroundColor: "rgba(255,255,255,0.2)",
                alignItems: "center",
                justifyContent: "center",
              }}>
                <MaterialIcons name="person" size={24} color="white" />
              </View>
              <View>
                <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 12 }}>مرحباً،</Text>
                <Text style={{ color: "white", fontSize: 16, fontWeight: "700" }}>
                  {currentUser?.name || "المستخدم"}
                </Text>
                <View style={{
                  backgroundColor: getRoleColor(currentUser?.role || "user") + "40",
                  borderRadius: 8,
                  paddingHorizontal: 8,
                  paddingVertical: 2,
                  marginTop: 2,
                  alignSelf: "flex-start",
                }}>
                  <Text style={{ color: "white", fontSize: 11, fontWeight: "600" }}>
                    {getRoleLabel(currentUser?.role || "user")}
                  </Text>
                </View>
              </View>
            </View>

            <View style={{ flexDirection: "row", gap: 12 }}>
              <TouchableOpacity
                onPress={() => router.push("/(tabs)/settings" as any)}
                style={{ position: "relative" }}
              >
                <MaterialIcons name="notifications" size={26} color="white" />
                {unreadNotifications > 0 && (
                  <View style={{
                    position: "absolute",
                    top: -4,
                    right: -4,
                    backgroundColor: "#E74C3C",
                    borderRadius: 8,
                    minWidth: 16,
                    height: 16,
                    alignItems: "center",
                    justifyContent: "center",
                  }}>
                    <Text style={{ color: "white", fontSize: 10, fontWeight: "700" }}>
                      {unreadNotifications}
                    </Text>
                  </View>
                )}
              </TouchableOpacity>
              <Image
                source={require("@/assets/images/icon.png")}
                style={{ width: 36, height: 36, borderRadius: 18 }}
                resizeMode="contain"
              />
            </View>
          </View>

          {/* Revenue Card */}
          <View style={{
            backgroundColor: "rgba(255,255,255,0.15)",
            borderRadius: 16,
            padding: 16,
          }}>
            <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 13, textAlign: "right" }}>
              إجمالي الإيرادات المحصلة
            </Text>
            <Text style={{ color: "white", fontSize: 28, fontWeight: "800", textAlign: "right", marginTop: 4 }}>
              ${totalRevenue.toLocaleString()}
            </Text>
            <Text style={{ color: "rgba(255,255,255,0.6)", fontSize: 12, textAlign: "right", marginTop: 2 }}>
              من {invoices.filter((i) => i.status === "paid").length} فاتورة مدفوعة
            </Text>
          </View>
        </View>

        <View style={{ padding: 16 }}>
          {/* Stats Grid */}
          <Text style={{ fontSize: 16, fontWeight: "700", color: "#1A2332", textAlign: "right", marginBottom: 12 }}>
            نظرة عامة
          </Text>
          <View style={{ flexDirection: "row-reverse", marginBottom: 8 }}>
            <StatCard
              icon="directions-boat"
              label="سفن نشطة"
              value={activeVessels}
              color="#1E3A5F"
              bgColor="#EBF2FA"
            />
            <StatCard
              icon="description"
              label="فواتير معلقة"
              value={pendingInvoices}
              color="#F39C12"
              bgColor="#FEF9E7"
            />
          </View>
          <View style={{ flexDirection: "row-reverse", marginBottom: 16 }}>
            <StatCard
              icon="message"
              label="مذكرات"
              value={memos.length}
              color="#27AE60"
              bgColor="#EAFAF1"
            />
            <StatCard
              icon="archive"
              label="ملفات مؤرشفة"
              value={archives.length}
              color="#9B59B6"
              bgColor="#F5EEF8"
            />
          </View>

          {/* Quick Actions */}
          <Text style={{ fontSize: 16, fontWeight: "700", color: "#1A2332", textAlign: "right", marginBottom: 12 }}>
            إجراءات سريعة
          </Text>
          <View style={{ flexDirection: "row-reverse", marginBottom: 8 }}>
            <QuickActionButton
              icon="directions-boat"
              label="إدارة السفن"
              color="#1E3A5F"
              onPress={() => router.push("/(tabs)/vessels" as any)}
            />
            <QuickActionButton
              icon="description"
              label="الفواتير"
              color="#F39C12"
              onPress={() => router.push("/(tabs)/invoices" as any)}
            />
            <QuickActionButton
              icon="message"
              label="مذكرة جديدة"
              color="#27AE60"
              onPress={() => router.push("/memo/new" as any)}
            />
          </View>
          <View style={{ flexDirection: "row-reverse", marginBottom: 8 }}>
            <QuickActionButton
              icon="folder"
              label="الأرشيف"
              color="#9B59B6"
              onPress={() => router.push("/archive" as any)}
            />
            <QuickActionButton
              icon="calculate"
              label="الأسعار"
              color="#2E86AB"
              onPress={() => router.push("/pricing" as any)}
            />
            <QuickActionButton
              icon="rate-review"
              label="مراجعة"
              color="#E74C3C"
              onPress={() => router.push("/review" as any)}
            />
          </View>
          <View style={{ flexDirection: "row-reverse", marginBottom: 16 }}>
            <QuickActionButton
              icon="bar-chart"
              label="التقارير"
              color="#16A085"
              onPress={() => router.push("/(tabs)/reports" as any)}
            />
            <QuickActionButton
              icon="payment"
              label="سجل الدفع"
              color="#8E44AD"
              onPress={() => router.push("/(tabs)/reports" as any)}
            />
            <QuickActionButton
              icon="add-circle"
              label="فاتورة جديدة"
              color="#C0392B"
              onPress={() => router.push("/invoice/new" as any)}
            />
          </View>

          {/* Recent Invoices */}
          <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
            <Text style={{ fontSize: 16, fontWeight: "700", color: "#1A2332" }}>
              آخر الفواتير
            </Text>
            <TouchableOpacity onPress={() => router.push("/(tabs)/invoices" as any)}>
              <Text style={{ fontSize: 13, color: "#1E3A5F", fontWeight: "600" }}>عرض الكل</Text>
            </TouchableOpacity>
          </View>

          {recentInvoices.map((invoice) => (
            <TouchableOpacity
              key={invoice.id}
              onPress={() => router.push(`/invoice/${invoice.id}` as any)}
              style={{
                backgroundColor: "white",
                borderRadius: 14,
                padding: 16,
                marginBottom: 10,
                flexDirection: "row-reverse",
                justifyContent: "space-between",
                alignItems: "center",
                shadowColor: "#000",
                shadowOffset: { width: 0, height: 1 },
                shadowOpacity: 0.06,
                shadowRadius: 4,
                elevation: 2,
              }}
            >
              <View style={{ flex: 1, alignItems: "flex-end" }}>
                <Text style={{ fontSize: 14, fontWeight: "700", color: "#1A2332" }}>
                  {invoice.invoiceNumber}
                </Text>
                <Text style={{ fontSize: 12, color: "#6B7C93", marginTop: 2 }}>
                  {invoice.vesselName}
                </Text>
              </View>
              <View style={{ alignItems: "flex-start" }}>
                <Text style={{ fontSize: 15, fontWeight: "700", color: "#1E3A5F" }}>
                  ${invoice.amount.toLocaleString()}
                </Text>
                <View style={{
                  backgroundColor: getInvoiceStatusColor(invoice.status) + "20",
                  borderRadius: 8,
                  paddingHorizontal: 8,
                  paddingVertical: 3,
                  marginTop: 4,
                }}>
                  <Text style={{
                    color: getInvoiceStatusColor(invoice.status),
                    fontSize: 11,
                    fontWeight: "700",
                  }}>
                    {getInvoiceStatusLabel(invoice.status)}
                  </Text>
                </View>
              </View>
            </TouchableOpacity>
          ))}
        </View>
      </ScrollView>
    </ScreenContainer>
  );
}
