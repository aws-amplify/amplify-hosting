import { Alert, FlatList, Modal, ScrollView, Text, TextInput, TouchableOpacity, View } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useApp } from "@/lib/app-context";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useState } from "react";
import { PERMISSIONS, PilotageRate, TowageRate, PortFee } from "@/lib/storage";

const PILOTAGE_RATES_DEFAULT: PilotageRate[] = [
  { code: "A001", grtMin: 0, grtMax: 200, ratePerHour: 0, ratePerTwoHours: 0 },
  { code: "A002", grtMin: 201, grtMax: 1000, ratePerHour: 325, ratePerTwoHours: 650 },
  { code: "A003", grtMin: 1001, grtMax: 5000, ratePerHour: 455, ratePerTwoHours: 910 },
  { code: "A004", grtMin: 5001, grtMax: 10000, ratePerHour: 357.5, ratePerTwoHours: 715 },
  { code: "A005", grtMin: 10001, grtMax: 15000, ratePerHour: 455, ratePerTwoHours: 910 },
  { code: "A006", grtMin: 15001, grtMax: 20000, ratePerHour: 552.5, ratePerTwoHours: 1105 },
  { code: "A007", grtMin: 20001, grtMax: 25000, ratePerHour: 650, ratePerTwoHours: 1300 },
  { code: "A008", grtMin: 25001, grtMax: 35000, ratePerHour: 845, ratePerTwoHours: 1690 },
  { code: "A009", grtMin: 35001, grtMax: 45000, ratePerHour: 975, ratePerTwoHours: 1950 },
  { code: "A010", grtMin: 45001, grtMax: -1, ratePerHour: 1040, ratePerTwoHours: 2080 },
];

const TOWAGE_RATES_DEFAULT: TowageRate[] = [
  { grtMin: 0, grtMax: 200, rate: 390 },
  { grtMin: 201, grtMax: 1000, rate: 910 },
  { grtMin: 1001, grtMax: 5000, rate: 1300 },
  { grtMin: 5001, grtMax: 10000, rate: 1950 },
  { grtMin: 10001, grtMax: 15000, rate: 2600 },
  { grtMin: 15001, grtMax: 20000, rate: 3250 },
  { grtMin: 20001, grtMax: 25000, rate: 3900 },
  { grtMin: 25001, grtMax: 35000, rate: 4290 },
  { grtMin: 35001, grtMax: 45000, rate: 4550 },
  { grtMin: 45001, grtMax: -1, rate: 4550 },
];

const PORT_FEES_DEFAULT: PortFee[] = [
  { code: "F001", name: "رسم المخطاف", formula: "per_grt", rate: 1.95, unit: "لكل 100 GRT" },
  { code: "F002", name: "رسم الطن", formula: "per_nrt", rate: 0.104, unit: "لكل NRT" },
  { code: "F003", name: "المساعدات الملاحية", formula: "per_grt", rate: 7.8, unit: "لكل 100 GRT", minimum: 110.5 },
  { code: "F004", name: "رسم الميناء", formula: "per_grt", rate: 10.4, unit: "لكل 100 GRT", minimum: 149.5 },
  { code: "F005", name: "البقاء في الرصيف", formula: "per_length_hour", rate: 0.2, unit: "متر/ساعة" },
  { code: "F006", name: "البقاء في الحوض", formula: "per_grt_day", rate: 5.2, unit: "لكل 100 GRT/يوم" },
  { code: "F007", name: "الرباط وحل الرباط", formula: "per_grt", rate: 9.1, unit: "لكل 100 GRT" },
  { code: "F008", name: "تصريح المغادرة", formula: "fixed", rate: 39, unit: "لكل تصريح", minimum: 39 },
  { code: "F009", name: "أجر إشرافية", formula: "fixed", rate: 520, unit: "لكل زيارة", minimum: 520 },
  { code: "F010", name: "رسوم الحراسة", formula: "per_day", rate: 7.8, unit: "لكل يوم" },
  { code: "F011", name: "زوارق المواصلات", formula: "fixed", rate: 1500, unit: "لكل استخدام", minimum: 1500 },
  { code: "F012", name: "رسم الإنارة", formula: "per_nrt", rate: 0.078, unit: "لكل NRT" },
  { code: "F013", name: "رسم المرور", formula: "per_grt", rate: 0, unit: "لكل 100 GRT" },
  { code: "F014", name: "رسم الركاب", formula: "per_person", rate: 0, unit: "لكل راكب" },
  { code: "F015", name: "أجور انتظار المرشد", formula: "fixed", rate: 130, unit: "لكل انتظار" },
  { code: "F016", name: "رسم الطن على البضاعة", formula: "per_ton_cargo", rate: 1, unit: "ريال/طن" },
];

type TabType = "pilotage" | "towage" | "fees" | "calculator";

// ---- نماذج التعديل ----
type PilotageFormData = {
  code: string;
  grtMin: string;
  grtMax: string;
  ratePerHour: string;
  ratePerTwoHours: string;
};

type TowageFormData = {
  grtMin: string;
  grtMax: string;
  rate: string;
};

type FeeFormData = {
  code: string;
  name: string;
  formula: string;
  rate: string;
  unit: string;
  minimum: string;
};

const FORMULA_OPTIONS = [
  { value: "per_grt", label: "لكل 100 GRT" },
  { value: "per_nrt", label: "لكل NRT" },
  { value: "per_length_hour", label: "متر × ساعة" },
  { value: "per_grt_day", label: "لكل 100 GRT/يوم" },
  { value: "per_day", label: "لكل يوم" },
  { value: "fixed", label: "مبلغ ثابت" },
  { value: "per_person", label: "لكل شخص" },
  { value: "per_ton_cargo", label: "لكل طن بضاعة" },
];

export default function PricingScreen() {
  const router = useRouter();
  const { currentUser, pricingTables, updatePricingTables } = useApp();
  const [activeTab, setActiveTab] = useState<TabType>("pilotage");
  const [exchangeRate, setExchangeRate] = useState(String(pricingTables?.exchangeRate || 250));

  // Calculator state
  const [calcGrt, setCalcGrt] = useState("");
  const [calcNrt, setCalcNrt] = useState("");
  const [calcLength, setCalcLength] = useState("");
  const [calcHours, setCalcHours] = useState("");
  const [calcDays, setCalcDays] = useState("");
  const [calcResult, setCalcResult] = useState<{ name: string; usd: number; yer: number }[]>([]);

  // Modal states
  const [showPilotageModal, setShowPilotageModal] = useState(false);
  const [showTowageModal, setShowTowageModal] = useState(false);
  const [showFeeModal, setShowFeeModal] = useState(false);
  const [editingPilotageIdx, setEditingPilotageIdx] = useState<number | null>(null);
  const [editingTowageIdx, setEditingTowageIdx] = useState<number | null>(null);
  const [editingFeeIdx, setEditingFeeIdx] = useState<number | null>(null);

  // Form states
  const [pilotageForm, setPilotageForm] = useState<PilotageFormData>({
    code: "", grtMin: "", grtMax: "", ratePerHour: "", ratePerTwoHours: "",
  });
  const [towageForm, setTowageForm] = useState<TowageFormData>({
    grtMin: "", grtMax: "", rate: "",
  });
  const [feeForm, setFeeForm] = useState<FeeFormData>({
    code: "", name: "", formula: "fixed", rate: "", unit: "", minimum: "",
  });

  const canEdit = currentUser?.role === "admin";

  const pilotageRates = pricingTables?.pilotageRates || PILOTAGE_RATES_DEFAULT;
  const towageRates = pricingTables?.towageRates || TOWAGE_RATES_DEFAULT;
  const portFees = pricingTables?.portFees || PORT_FEES_DEFAULT;
  const rate = parseFloat(exchangeRate) || 250;

  const getPilotageCode = (grt: number): PilotageRate | undefined => {
    return pilotageRates.find((r) => grt >= r.grtMin && (r.grtMax === -1 || grt <= r.grtMax));
  };

  const getTowageRate = (grt: number): TowageRate | undefined => {
    return towageRates.find((r) => grt >= r.grtMin && (r.grtMax === -1 || grt <= r.grtMax));
  };

  const calculateFees = () => {
    const grt = parseFloat(calcGrt) || 0;
    const nrt = parseFloat(calcNrt) || 0;
    const length = parseFloat(calcLength) || 0;
    const hours = parseFloat(calcHours) || 0;
    const days = parseFloat(calcDays) || 0;

    if (!grt) {
      Alert.alert("تنبيه", "يرجى إدخال الطنية الإجمالية GRT على الأقل");
      return;
    }

    const results: { name: string; usd: number; yer: number }[] = [];
    const pilotage = getPilotageCode(grt);
    const towage = getTowageRate(grt);

    portFees.forEach((fee) => {
      let usd = 0;
      switch (fee.formula) {
        case "per_grt":
          usd = Math.max((grt / 100) * fee.rate, fee.minimum || 0);
          break;
        case "per_nrt":
          usd = nrt * fee.rate;
          break;
        case "per_length_hour":
          usd = length * hours * fee.rate;
          break;
        case "per_grt_day":
          usd = (grt / 100) * fee.rate * days;
          break;
        case "per_day":
          usd = fee.rate * days;
          break;
        case "fixed":
          usd = fee.minimum || fee.rate;
          break;
        default:
          usd = fee.rate;
      }
      if (usd > 0) {
        results.push({ name: fee.name, usd, yer: usd * rate });
      }
    });

    if (pilotage && hours > 0) {
      const pilotageUsd = pilotage.ratePerHour * hours;
      results.push({ name: `أجر الإرشاد (${pilotage.code})`, usd: pilotageUsd, yer: pilotageUsd * rate });
    }

    if (towage) {
      results.push({ name: "أجر القطر", usd: towage.rate, yer: towage.rate * rate });
    }

    setCalcResult(results);
  };

  const totalUSD = calcResult.reduce((s, r) => s + r.usd, 0);
  const totalYER = calcResult.reduce((s, r) => s + r.yer, 0);

  const handleSaveExchangeRate = async () => {
    const rateNum = parseFloat(exchangeRate);
    if (!rateNum || rateNum <= 0) {
      Alert.alert("خطأ", "يرجى إدخال سعر صرف صحيح");
      return;
    }
    await updatePricingTables({ exchangeRate: rateNum });
    Alert.alert("نجاح", "تم حفظ سعر الصرف");
  };

  // ---- إدارة الإرشاد ----
  const openAddPilotage = () => {
    const nextCode = `A${String(pilotageRates.length + 1).padStart(3, "0")}`;
    setPilotageForm({ code: nextCode, grtMin: "", grtMax: "", ratePerHour: "", ratePerTwoHours: "" });
    setEditingPilotageIdx(null);
    setShowPilotageModal(true);
  };

  const openEditPilotage = (idx: number) => {
    const r = pilotageRates[idx];
    setPilotageForm({
      code: r.code,
      grtMin: String(r.grtMin),
      grtMax: r.grtMax === -1 ? "" : String(r.grtMax),
      ratePerHour: String(r.ratePerHour),
      ratePerTwoHours: String(r.ratePerTwoHours),
    });
    setEditingPilotageIdx(idx);
    setShowPilotageModal(true);
  };

  const savePilotage = async () => {
    if (!pilotageForm.code || !pilotageForm.grtMin || !pilotageForm.ratePerHour) {
      Alert.alert("خطأ", "يرجى ملء الحقول المطلوبة (الكود، الحد الأدنى، الأجر/ساعة)");
      return;
    }
    const newEntry: PilotageRate = {
      code: pilotageForm.code.trim(),
      grtMin: parseFloat(pilotageForm.grtMin) || 0,
      grtMax: pilotageForm.grtMax ? parseFloat(pilotageForm.grtMax) : -1,
      ratePerHour: parseFloat(pilotageForm.ratePerHour) || 0,
      ratePerTwoHours: parseFloat(pilotageForm.ratePerTwoHours) || (parseFloat(pilotageForm.ratePerHour) * 2),
    };
    const updated = [...pilotageRates];
    if (editingPilotageIdx !== null) {
      updated[editingPilotageIdx] = newEntry;
    } else {
      updated.push(newEntry);
    }
    await updatePricingTables({ pilotageRates: updated });
    setShowPilotageModal(false);
    Alert.alert("نجاح", editingPilotageIdx !== null ? "تم تحديث البند" : "تم إضافة البند الجديد");
  };

  const deletePilotage = (idx: number) => {
    Alert.alert("تأكيد الحذف", `هل تريد حذف البند ${pilotageRates[idx].code}؟`, [
      { text: "إلغاء", style: "cancel" },
      {
        text: "حذف", style: "destructive",
        onPress: async () => {
          const updated = pilotageRates.filter((_, i) => i !== idx);
          await updatePricingTables({ pilotageRates: updated });
        },
      },
    ]);
  };

  // ---- إدارة القطر ----
  const openAddTowage = () => {
    setTowageForm({ grtMin: "", grtMax: "", rate: "" });
    setEditingTowageIdx(null);
    setShowTowageModal(true);
  };

  const openEditTowage = (idx: number) => {
    const r = towageRates[idx];
    setTowageForm({
      grtMin: String(r.grtMin),
      grtMax: r.grtMax === -1 ? "" : String(r.grtMax),
      rate: String(r.rate),
    });
    setEditingTowageIdx(idx);
    setShowTowageModal(true);
  };

  const saveTowage = async () => {
    if (!towageForm.grtMin || !towageForm.rate) {
      Alert.alert("خطأ", "يرجى ملء الحد الأدنى للـ GRT والأجر");
      return;
    }
    const newEntry: TowageRate = {
      grtMin: parseFloat(towageForm.grtMin) || 0,
      grtMax: towageForm.grtMax ? parseFloat(towageForm.grtMax) : -1,
      rate: parseFloat(towageForm.rate) || 0,
    };
    const updated = [...towageRates];
    if (editingTowageIdx !== null) {
      updated[editingTowageIdx] = newEntry;
    } else {
      updated.push(newEntry);
    }
    await updatePricingTables({ towageRates: updated });
    setShowTowageModal(false);
    Alert.alert("نجاح", editingTowageIdx !== null ? "تم تحديث البند" : "تم إضافة البند الجديد");
  };

  const deleteTowage = (idx: number) => {
    Alert.alert("تأكيد الحذف", "هل تريد حذف هذا البند؟", [
      { text: "إلغاء", style: "cancel" },
      {
        text: "حذف", style: "destructive",
        onPress: async () => {
          const updated = towageRates.filter((_, i) => i !== idx);
          await updatePricingTables({ towageRates: updated });
        },
      },
    ]);
  };

  // ---- إدارة الرسوم ----
  const openAddFee = () => {
    const nextCode = `F${String(portFees.length + 1).padStart(3, "0")}`;
    setFeeForm({ code: nextCode, name: "", formula: "fixed", rate: "", unit: "", minimum: "" });
    setEditingFeeIdx(null);
    setShowFeeModal(true);
  };

  const openEditFee = (idx: number) => {
    const f = portFees[idx];
    setFeeForm({
      code: f.code,
      name: f.name,
      formula: f.formula,
      rate: String(f.rate),
      unit: f.unit,
      minimum: f.minimum ? String(f.minimum) : "",
    });
    setEditingFeeIdx(idx);
    setShowFeeModal(true);
  };

  const saveFee = async () => {
    if (!feeForm.code || !feeForm.name || !feeForm.rate) {
      Alert.alert("خطأ", "يرجى ملء الكود والاسم والسعر");
      return;
    }
    const newEntry: PortFee = {
      code: feeForm.code.trim(),
      name: feeForm.name.trim(),
      formula: feeForm.formula,
      rate: parseFloat(feeForm.rate) || 0,
      unit: feeForm.unit.trim() || "لكل رحلة",
      minimum: feeForm.minimum ? parseFloat(feeForm.minimum) : undefined,
    };
    const updated = [...portFees];
    if (editingFeeIdx !== null) {
      updated[editingFeeIdx] = newEntry;
    } else {
      updated.push(newEntry);
    }
    await updatePricingTables({ portFees: updated });
    setShowFeeModal(false);
    Alert.alert("نجاح", editingFeeIdx !== null ? "تم تحديث البند" : "تم إضافة البند الجديد");
  };

  const deleteFee = (idx: number) => {
    Alert.alert("تأكيد الحذف", `هل تريد حذف "${portFees[idx].name}"؟`, [
      { text: "إلغاء", style: "cancel" },
      {
        text: "حذف", style: "destructive",
        onPress: async () => {
          const updated = portFees.filter((_, i) => i !== idx);
          await updatePricingTables({ portFees: updated });
        },
      },
    ]);
  };

  const resetToDefaults = () => {
    Alert.alert("إعادة تعيين", "هل تريد استعادة جميع الأسعار الافتراضية؟ سيتم حذف جميع التعديلات.", [
      { text: "إلغاء", style: "cancel" },
      {
        text: "استعادة", style: "destructive",
        onPress: async () => {
          await updatePricingTables({
            pilotageRates: PILOTAGE_RATES_DEFAULT,
            towageRates: TOWAGE_RATES_DEFAULT,
            portFees: PORT_FEES_DEFAULT,
            exchangeRate: 250,
          });
          setExchangeRate("250");
          Alert.alert("نجاح", "تم استعادة الأسعار الافتراضية");
        },
      },
    ]);
  };

  return (
    <ScreenContainer containerClassName="bg-background">
      {/* Header */}
      <View style={{ backgroundColor: "#1E3A5F", paddingHorizontal: 20, paddingTop: 16, paddingBottom: 20 }}>
        <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" }}>
          <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10 }}>
            <View style={{ width: 42, height: 42, borderRadius: 12, backgroundColor: "rgba(255,255,255,0.15)", alignItems: "center", justifyContent: "center" }}>
              <MaterialIcons name="price-change" size={22} color="white" />
            </View>
            <View>
              <Text style={{ color: "white", fontSize: 18, fontWeight: "800" }}>جداول الأسعار والرسوم</Text>
              <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 12 }}>وفق لائحة الموانئ اليمنية</Text>
            </View>
          </View>
          <View style={{ flexDirection: "row-reverse", gap: 8 }}>
            {canEdit && (
              <TouchableOpacity onPress={resetToDefaults} style={{ width: 38, height: 38, borderRadius: 10, backgroundColor: "rgba(231,76,60,0.3)", alignItems: "center", justifyContent: "center" }}>
                <MaterialIcons name="restore" size={20} color="white" />
              </TouchableOpacity>
            )}
            <TouchableOpacity onPress={() => router.back()} style={{ width: 38, height: 38, borderRadius: 10, backgroundColor: "rgba(255,255,255,0.15)", alignItems: "center", justifyContent: "center" }}>
              <MaterialIcons name="arrow-forward" size={22} color="white" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Exchange Rate */}
        <View style={{ marginTop: 14, flexDirection: "row-reverse", alignItems: "center", gap: 8, backgroundColor: "rgba(255,255,255,0.1)", borderRadius: 12, padding: 10 }}>
          <MaterialIcons name="currency-exchange" size={18} color="rgba(255,255,255,0.8)" />
          <Text style={{ color: "rgba(255,255,255,0.8)", fontSize: 13 }}>سعر الصرف: 1$ =</Text>
          <TextInput
            value={exchangeRate}
            onChangeText={setExchangeRate}
            keyboardType="numeric"
            editable={canEdit}
            style={{ flex: 1, color: "white", fontSize: 14, fontWeight: "700", textAlign: "right", backgroundColor: "rgba(255,255,255,0.1)", borderRadius: 8, paddingHorizontal: 10, paddingVertical: 4 }}
          />
          <Text style={{ color: "rgba(255,255,255,0.8)", fontSize: 13 }}>ريال</Text>
          {canEdit && (
            <TouchableOpacity onPress={handleSaveExchangeRate} style={{ backgroundColor: "#27AE60", borderRadius: 8, paddingHorizontal: 12, paddingVertical: 6 }}>
              <Text style={{ color: "white", fontSize: 12, fontWeight: "700" }}>حفظ</Text>
            </TouchableOpacity>
          )}
        </View>
      </View>

      {/* Tabs */}
      <View style={{ flexDirection: "row-reverse", backgroundColor: "white", borderBottomWidth: 1, borderBottomColor: "#E5E7EB" }}>
        {([
          { key: "pilotage", label: "الإرشاد", icon: "navigation" },
          { key: "towage", label: "القطر", icon: "anchor" },
          { key: "fees", label: "الرسوم", icon: "receipt" },
          { key: "calculator", label: "الحاسبة", icon: "calculate" },
        ] as { key: TabType; label: string; icon: string }[]).map((tab) => (
          <TouchableOpacity
            key={tab.key}
            onPress={() => setActiveTab(tab.key)}
            style={{ flex: 1, paddingVertical: 12, alignItems: "center", borderBottomWidth: 2, borderBottomColor: activeTab === tab.key ? "#1E3A5F" : "transparent" }}
          >
            <MaterialIcons name={tab.icon as any} size={18} color={activeTab === tab.key ? "#1E3A5F" : "#9BA1A6"} />
            <Text style={{ fontSize: 11, color: activeTab === tab.key ? "#1E3A5F" : "#9BA1A6", fontWeight: activeTab === tab.key ? "700" : "400", marginTop: 2 }}>{tab.label}</Text>
          </TouchableOpacity>
        ))}
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16, paddingBottom: 40 }}>

        {/* ===== Pilotage Rates ===== */}
        {activeTab === "pilotage" && (
          <View>
            <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
              <Text style={{ fontSize: 16, fontWeight: "800", color: "#1A2332" }}>جدول أجر الإرشاد حسب GRT</Text>
              {canEdit && (
                <TouchableOpacity
                  onPress={openAddPilotage}
                  style={{ flexDirection: "row-reverse", alignItems: "center", gap: 6, backgroundColor: "#1E3A5F", borderRadius: 10, paddingHorizontal: 14, paddingVertical: 8 }}
                >
                  <MaterialIcons name="add" size={18} color="white" />
                  <Text style={{ color: "white", fontSize: 13, fontWeight: "700" }}>إضافة بند</Text>
                </TouchableOpacity>
              )}
            </View>

            <View style={{ backgroundColor: "white", borderRadius: 16, overflow: "hidden", shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
              {/* Header */}
              <View style={{ flexDirection: "row-reverse", backgroundColor: "#1E3A5F", padding: 10 }}>
                {canEdit && <View style={{ width: 70 }} />}
                {["الكود", "نطاق GRT", "$/ساعة", "$/ساعتين"].map((h, i) => (
                  <Text key={i} style={{ flex: 1, color: "white", fontSize: 11, fontWeight: "700", textAlign: "center" }}>{h}</Text>
                ))}
              </View>
              {pilotageRates.map((r, idx) => (
                <View key={idx} style={{ flexDirection: "row-reverse", padding: 10, borderBottomWidth: idx < pilotageRates.length - 1 ? 1 : 0, borderBottomColor: "#F0F4F8", backgroundColor: idx % 2 === 0 ? "white" : "#F8FAFC", alignItems: "center" }}>
                  {canEdit && (
                    <View style={{ width: 70, flexDirection: "row-reverse", gap: 4 }}>
                      <TouchableOpacity onPress={() => openEditPilotage(idx)} style={{ width: 30, height: 30, borderRadius: 8, backgroundColor: "#EBF4FF", alignItems: "center", justifyContent: "center" }}>
                        <MaterialIcons name="edit" size={15} color="#1E3A5F" />
                      </TouchableOpacity>
                      <TouchableOpacity onPress={() => deletePilotage(idx)} style={{ width: 30, height: 30, borderRadius: 8, backgroundColor: "#FEE2E2", alignItems: "center", justifyContent: "center" }}>
                        <MaterialIcons name="delete" size={15} color="#E74C3C" />
                      </TouchableOpacity>
                    </View>
                  )}
                  <Text style={{ flex: 1, textAlign: "center", fontSize: 11, fontWeight: "700", color: "#1E3A5F" }}>{r.code}</Text>
                  <Text style={{ flex: 1, textAlign: "center", fontSize: 11, color: "#1A2332" }}>
                    {r.grtMax === -1 ? `>${r.grtMin.toLocaleString()}` : `${r.grtMin.toLocaleString()}-${r.grtMax.toLocaleString()}`}
                  </Text>
                  <Text style={{ flex: 1, textAlign: "center", fontSize: 11, color: "#27AE60", fontWeight: "600" }}>{r.ratePerHour.toLocaleString()}</Text>
                  <Text style={{ flex: 1, textAlign: "center", fontSize: 11, color: "#E74C3C", fontWeight: "600" }}>{r.ratePerTwoHours.toLocaleString()}</Text>
                </View>
              ))}
            </View>
            <Text style={{ textAlign: "right", fontSize: 11, color: "#9BA1A6", marginTop: 8 }}>إجمالي البنود: {pilotageRates.length}</Text>
          </View>
        )}

        {/* ===== Towage Rates ===== */}
        {activeTab === "towage" && (
          <View>
            <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
              <Text style={{ fontSize: 16, fontWeight: "800", color: "#1A2332" }}>جدول أجر القطر حسب GRT</Text>
              {canEdit && (
                <TouchableOpacity
                  onPress={openAddTowage}
                  style={{ flexDirection: "row-reverse", alignItems: "center", gap: 6, backgroundColor: "#1E3A5F", borderRadius: 10, paddingHorizontal: 14, paddingVertical: 8 }}
                >
                  <MaterialIcons name="add" size={18} color="white" />
                  <Text style={{ color: "white", fontSize: 13, fontWeight: "700" }}>إضافة بند</Text>
                </TouchableOpacity>
              )}
            </View>

            <View style={{ backgroundColor: "white", borderRadius: 16, overflow: "hidden", shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
              <View style={{ flexDirection: "row-reverse", backgroundColor: "#1E3A5F", padding: 10 }}>
                {canEdit && <View style={{ width: 70 }} />}
                {["نطاق GRT", "الأجر ($)"].map((h, i) => (
                  <Text key={i} style={{ flex: 1, color: "white", fontSize: 12, fontWeight: "700", textAlign: "center" }}>{h}</Text>
                ))}
              </View>
              {towageRates.map((r, idx) => (
                <View key={idx} style={{ flexDirection: "row-reverse", padding: 12, borderBottomWidth: idx < towageRates.length - 1 ? 1 : 0, borderBottomColor: "#F0F4F8", backgroundColor: idx % 2 === 0 ? "white" : "#F8FAFC", alignItems: "center" }}>
                  {canEdit && (
                    <View style={{ width: 70, flexDirection: "row-reverse", gap: 4 }}>
                      <TouchableOpacity onPress={() => openEditTowage(idx)} style={{ width: 30, height: 30, borderRadius: 8, backgroundColor: "#EBF4FF", alignItems: "center", justifyContent: "center" }}>
                        <MaterialIcons name="edit" size={15} color="#1E3A5F" />
                      </TouchableOpacity>
                      <TouchableOpacity onPress={() => deleteTowage(idx)} style={{ width: 30, height: 30, borderRadius: 8, backgroundColor: "#FEE2E2", alignItems: "center", justifyContent: "center" }}>
                        <MaterialIcons name="delete" size={15} color="#E74C3C" />
                      </TouchableOpacity>
                    </View>
                  )}
                  <Text style={{ flex: 1, textAlign: "center", fontSize: 13, color: "#1A2332" }}>
                    {r.grtMax === -1 ? `>${r.grtMin.toLocaleString()}` : `${r.grtMin.toLocaleString()}-${r.grtMax.toLocaleString()}`}
                  </Text>
                  <Text style={{ flex: 1, textAlign: "center", fontSize: 13, color: "#27AE60", fontWeight: "700" }}>{r.rate.toLocaleString()}</Text>
                </View>
              ))}
            </View>
            <Text style={{ textAlign: "right", fontSize: 11, color: "#9BA1A6", marginTop: 8 }}>إجمالي البنود: {towageRates.length}</Text>
          </View>
        )}

        {/* ===== Port Fees ===== */}
        {activeTab === "fees" && (
          <View>
            <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 12 }}>
              <Text style={{ fontSize: 16, fontWeight: "800", color: "#1A2332" }}>جدول الرسوم والأجور</Text>
              {canEdit && (
                <TouchableOpacity
                  onPress={openAddFee}
                  style={{ flexDirection: "row-reverse", alignItems: "center", gap: 6, backgroundColor: "#1E3A5F", borderRadius: 10, paddingHorizontal: 14, paddingVertical: 8 }}
                >
                  <MaterialIcons name="add" size={18} color="white" />
                  <Text style={{ color: "white", fontSize: 13, fontWeight: "700" }}>إضافة بند</Text>
                </TouchableOpacity>
              )}
            </View>

            {portFees.map((fee, idx) => (
              <View key={idx} style={{ backgroundColor: "white", borderRadius: 14, padding: 14, marginBottom: 8, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.04, shadowRadius: 3, elevation: 1 }}>
                <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" }}>
                  <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 8, flex: 1 }}>
                    <View style={{ backgroundColor: "#EBF4FF", borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 }}>
                      <Text style={{ fontSize: 11, color: "#1E3A5F", fontWeight: "700" }}>{fee.code}</Text>
                    </View>
                    <Text style={{ fontSize: 14, fontWeight: "700", color: "#1A2332", flex: 1, textAlign: "right" }}>{fee.name}</Text>
                  </View>
                  <View style={{ alignItems: "flex-end", marginLeft: 8 }}>
                    <Text style={{ fontSize: 15, fontWeight: "800", color: "#27AE60" }}>${fee.rate.toLocaleString()}</Text>
                    <Text style={{ fontSize: 11, color: "#6B7C93" }}>{fee.unit}</Text>
                  </View>
                </View>
                {fee.minimum && fee.minimum !== fee.rate && (
                  <Text style={{ fontSize: 11, color: "#F39C12", textAlign: "right", marginTop: 4 }}>الحد الأدنى: ${fee.minimum}</Text>
                )}
                {canEdit && (
                  <View style={{ flexDirection: "row-reverse", gap: 8, marginTop: 10, borderTopWidth: 1, borderTopColor: "#F0F4F8", paddingTop: 10 }}>
                    <TouchableOpacity
                      onPress={() => openEditFee(idx)}
                      style={{ flex: 1, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 6, backgroundColor: "#EBF4FF", borderRadius: 10, paddingVertical: 8 }}
                    >
                      <MaterialIcons name="edit" size={16} color="#1E3A5F" />
                      <Text style={{ fontSize: 13, color: "#1E3A5F", fontWeight: "600" }}>تعديل</Text>
                    </TouchableOpacity>
                    <TouchableOpacity
                      onPress={() => deleteFee(idx)}
                      style={{ flex: 1, flexDirection: "row-reverse", alignItems: "center", justifyContent: "center", gap: 6, backgroundColor: "#FEE2E2", borderRadius: 10, paddingVertical: 8 }}
                    >
                      <MaterialIcons name="delete" size={16} color="#E74C3C" />
                      <Text style={{ fontSize: 13, color: "#E74C3C", fontWeight: "600" }}>حذف</Text>
                    </TouchableOpacity>
                  </View>
                )}
              </View>
            ))}
            <Text style={{ textAlign: "right", fontSize: 11, color: "#9BA1A6", marginTop: 4 }}>إجمالي البنود: {portFees.length}</Text>
          </View>
        )}

        {/* ===== Calculator ===== */}
        {activeTab === "calculator" && (
          <View>
            <Text style={{ fontSize: 16, fontWeight: "800", color: "#1A2332", textAlign: "right", marginBottom: 12 }}>حاسبة الرسوم التلقائية</Text>

            <View style={{ backgroundColor: "white", borderRadius: 16, padding: 16, marginBottom: 12, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
              <Text style={{ fontSize: 14, fontWeight: "700", color: "#6B7C93", textAlign: "right", marginBottom: 12 }}>بيانات السفينة</Text>
              {[
                { label: "الطنية الإجمالية GRT *", value: calcGrt, setter: setCalcGrt },
                { label: "الطنية الصافية NRT", value: calcNrt, setter: setCalcNrt },
                { label: "طول السفينة (متر)", value: calcLength, setter: setCalcLength },
                { label: "عدد الساعات", value: calcHours, setter: setCalcHours },
                { label: "عدد الأيام", value: calcDays, setter: setCalcDays },
              ].map((field, idx) => (
                <View key={idx} style={{ marginBottom: 10 }}>
                  <Text style={{ fontSize: 13, color: "#6B7C93", textAlign: "right", marginBottom: 4 }}>{field.label}</Text>
                  <TextInput
                    value={field.value}
                    onChangeText={field.setter}
                    keyboardType="numeric"
                    placeholder="0"
                    style={{ backgroundColor: "#F8FAFC", borderRadius: 10, padding: 12, fontSize: 14, textAlign: "right", borderWidth: 1, borderColor: "#E5E7EB" }}
                  />
                </View>
              ))}

              <TouchableOpacity
                onPress={calculateFees}
                style={{ backgroundColor: "#1E3A5F", borderRadius: 12, paddingVertical: 14, alignItems: "center", marginTop: 4 }}
              >
                <Text style={{ color: "white", fontSize: 15, fontWeight: "700" }}>احتساب الرسوم</Text>
              </TouchableOpacity>
            </View>

            {calcResult.length > 0 && (
              <View style={{ backgroundColor: "white", borderRadius: 16, overflow: "hidden", shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
                <View style={{ backgroundColor: "#1E3A5F", padding: 12, flexDirection: "row-reverse", justifyContent: "space-between" }}>
                  <Text style={{ color: "white", fontSize: 14, fontWeight: "700" }}>نتائج الاحتساب</Text>
                  <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 12 }}>{calcResult.length} بند</Text>
                </View>
                {calcResult.map((item, idx) => (
                  <View key={idx} style={{ flexDirection: "row-reverse", justifyContent: "space-between", padding: 12, borderBottomWidth: idx < calcResult.length - 1 ? 1 : 0, borderBottomColor: "#F0F4F8" }}>
                    <Text style={{ fontSize: 13, color: "#1A2332", flex: 1, textAlign: "right" }}>{item.name}</Text>
                    <View style={{ alignItems: "flex-end", minWidth: 120 }}>
                      <Text style={{ fontSize: 13, fontWeight: "700", color: "#27AE60" }}>${item.usd.toFixed(2)}</Text>
                      <Text style={{ fontSize: 11, color: "#6B7C93" }}>{item.yer.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",")} ريال</Text>
                    </View>
                  </View>
                ))}
                <View style={{ backgroundColor: "#1E3A5F", padding: 14, flexDirection: "row-reverse", justifyContent: "space-between" }}>
                  <Text style={{ color: "white", fontSize: 15, fontWeight: "800" }}>الإجمالي</Text>
                  <View style={{ alignItems: "flex-end" }}>
                    <Text style={{ color: "#4ADE80", fontSize: 16, fontWeight: "800" }}>${totalUSD.toFixed(2)}</Text>
                    <Text style={{ color: "rgba(255,255,255,0.8)", fontSize: 12 }}>{totalYER.toFixed(0).replace(/\B(?=(\d{3})+(?!\d))/g, ",")} ريال</Text>
                  </View>
                </View>
              </View>
            )}
          </View>
        )}
      </ScrollView>

      {/* ===== Modal: إضافة/تعديل بند الإرشاد ===== */}
      <Modal visible={showPilotageModal} transparent animationType="slide">
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}>
          <View style={{ backgroundColor: "white", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, maxHeight: "85%" }}>
            <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
              <Text style={{ fontSize: 18, fontWeight: "800", color: "#1A2332" }}>
                {editingPilotageIdx !== null ? "تعديل بند الإرشاد" : "إضافة بند إرشاد جديد"}
              </Text>
              <TouchableOpacity onPress={() => setShowPilotageModal(false)}>
                <MaterialIcons name="close" size={24} color="#6B7C93" />
              </TouchableOpacity>
            </View>
            <ScrollView showsVerticalScrollIndicator={false}>
              {[
                { label: "الكود *", key: "code" as keyof PilotageFormData, placeholder: "A001" },
                { label: "الحد الأدنى GRT *", key: "grtMin" as keyof PilotageFormData, placeholder: "0", numeric: true },
                { label: "الحد الأقصى GRT (اتركه فارغاً لـ ∞)", key: "grtMax" as keyof PilotageFormData, placeholder: "1000", numeric: true },
                { label: "الأجر لكل ساعة ($) *", key: "ratePerHour" as keyof PilotageFormData, placeholder: "325", numeric: true },
                { label: "الأجر لكل ساعتين ($)", key: "ratePerTwoHours" as keyof PilotageFormData, placeholder: "650", numeric: true },
              ].map((field) => (
                <View key={field.key} style={{ marginBottom: 14 }}>
                  <Text style={{ fontSize: 13, color: "#6B7C93", textAlign: "right", marginBottom: 6 }}>{field.label}</Text>
                  <TextInput
                    value={pilotageForm[field.key]}
                    onChangeText={(v) => setPilotageForm((prev) => ({ ...prev, [field.key]: v }))}
                    keyboardType={field.numeric ? "numeric" : "default"}
                    placeholder={field.placeholder}
                    style={{ backgroundColor: "#F8FAFC", borderRadius: 12, padding: 14, fontSize: 14, textAlign: "right", borderWidth: 1, borderColor: "#E5E7EB" }}
                  />
                </View>
              ))}
              <TouchableOpacity
                onPress={savePilotage}
                style={{ backgroundColor: "#1E3A5F", borderRadius: 14, paddingVertical: 16, alignItems: "center", marginTop: 8 }}
              >
                <Text style={{ color: "white", fontSize: 16, fontWeight: "700" }}>
                  {editingPilotageIdx !== null ? "حفظ التعديلات" : "إضافة البند"}
                </Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* ===== Modal: إضافة/تعديل بند القطر ===== */}
      <Modal visible={showTowageModal} transparent animationType="slide">
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}>
          <View style={{ backgroundColor: "white", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20 }}>
            <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
              <Text style={{ fontSize: 18, fontWeight: "800", color: "#1A2332" }}>
                {editingTowageIdx !== null ? "تعديل بند القطر" : "إضافة بند قطر جديد"}
              </Text>
              <TouchableOpacity onPress={() => setShowTowageModal(false)}>
                <MaterialIcons name="close" size={24} color="#6B7C93" />
              </TouchableOpacity>
            </View>
            {[
              { label: "الحد الأدنى GRT *", key: "grtMin" as keyof TowageFormData, placeholder: "0" },
              { label: "الحد الأقصى GRT (اتركه فارغاً لـ ∞)", key: "grtMax" as keyof TowageFormData, placeholder: "1000" },
              { label: "الأجر ($) *", key: "rate" as keyof TowageFormData, placeholder: "500" },
            ].map((field) => (
              <View key={field.key} style={{ marginBottom: 14 }}>
                <Text style={{ fontSize: 13, color: "#6B7C93", textAlign: "right", marginBottom: 6 }}>{field.label}</Text>
                <TextInput
                  value={towageForm[field.key]}
                  onChangeText={(v) => setTowageForm((prev) => ({ ...prev, [field.key]: v }))}
                  keyboardType="numeric"
                  placeholder={field.placeholder}
                  style={{ backgroundColor: "#F8FAFC", borderRadius: 12, padding: 14, fontSize: 14, textAlign: "right", borderWidth: 1, borderColor: "#E5E7EB" }}
                />
              </View>
            ))}
            <TouchableOpacity
              onPress={saveTowage}
              style={{ backgroundColor: "#1E3A5F", borderRadius: 14, paddingVertical: 16, alignItems: "center", marginTop: 8 }}
            >
              <Text style={{ color: "white", fontSize: 16, fontWeight: "700" }}>
                {editingTowageIdx !== null ? "حفظ التعديلات" : "إضافة البند"}
              </Text>
            </TouchableOpacity>
          </View>
        </View>
      </Modal>

      {/* ===== Modal: إضافة/تعديل بند الرسوم ===== */}
      <Modal visible={showFeeModal} transparent animationType="slide">
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}>
          <View style={{ backgroundColor: "white", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 20, maxHeight: "90%" }}>
            <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
              <Text style={{ fontSize: 18, fontWeight: "800", color: "#1A2332" }}>
                {editingFeeIdx !== null ? "تعديل بند الرسوم" : "إضافة بند رسوم جديد"}
              </Text>
              <TouchableOpacity onPress={() => setShowFeeModal(false)}>
                <MaterialIcons name="close" size={24} color="#6B7C93" />
              </TouchableOpacity>
            </View>
            <ScrollView showsVerticalScrollIndicator={false}>
              {[
                { label: "الكود *", key: "code" as keyof FeeFormData, placeholder: "F017", numeric: false },
                { label: "اسم البند *", key: "name" as keyof FeeFormData, placeholder: "رسم الخدمة", numeric: false },
                { label: "السعر ($) *", key: "rate" as keyof FeeFormData, placeholder: "100", numeric: true },
                { label: "الوحدة", key: "unit" as keyof FeeFormData, placeholder: "لكل رحلة", numeric: false },
                { label: "الحد الأدنى ($)", key: "minimum" as keyof FeeFormData, placeholder: "50", numeric: true },
              ].map((field) => (
                <View key={field.key} style={{ marginBottom: 14 }}>
                  <Text style={{ fontSize: 13, color: "#6B7C93", textAlign: "right", marginBottom: 6 }}>{field.label}</Text>
                  <TextInput
                    value={feeForm[field.key]}
                    onChangeText={(v) => setFeeForm((prev) => ({ ...prev, [field.key]: v }))}
                    keyboardType={field.numeric ? "numeric" : "default"}
                    placeholder={field.placeholder}
                    style={{ backgroundColor: "#F8FAFC", borderRadius: 12, padding: 14, fontSize: 14, textAlign: "right", borderWidth: 1, borderColor: "#E5E7EB" }}
                  />
                </View>
              ))}

              {/* Formula Selector */}
              <View style={{ marginBottom: 14 }}>
                <Text style={{ fontSize: 13, color: "#6B7C93", textAlign: "right", marginBottom: 8 }}>طريقة الاحتساب</Text>
                <View style={{ flexDirection: "row-reverse", flexWrap: "wrap", gap: 8 }}>
                  {FORMULA_OPTIONS.map((opt) => (
                    <TouchableOpacity
                      key={opt.value}
                      onPress={() => setFeeForm((prev) => ({ ...prev, formula: opt.value }))}
                      style={{
                        paddingHorizontal: 12, paddingVertical: 8, borderRadius: 10,
                        backgroundColor: feeForm.formula === opt.value ? "#1E3A5F" : "#F0F4F8",
                        borderWidth: 1, borderColor: feeForm.formula === opt.value ? "#1E3A5F" : "#E5E7EB",
                      }}
                    >
                      <Text style={{ fontSize: 12, color: feeForm.formula === opt.value ? "white" : "#6B7C93", fontWeight: feeForm.formula === opt.value ? "700" : "400" }}>
                        {opt.label}
                      </Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </View>

              <TouchableOpacity
                onPress={saveFee}
                style={{ backgroundColor: "#1E3A5F", borderRadius: 14, paddingVertical: 16, alignItems: "center", marginTop: 8, marginBottom: 20 }}
              >
                <Text style={{ color: "white", fontSize: 16, fontWeight: "700" }}>
                  {editingFeeIdx !== null ? "حفظ التعديلات" : "إضافة البند"}
                </Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}
