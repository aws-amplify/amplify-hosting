import { useState } from "react";
import { View, Text, ScrollView, TouchableOpacity, TextInput, Alert, Modal } from "react-native";
import { useLocalSearchParams, useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useApp } from "@/lib/app-context";
import type { Vessel } from "@/lib/storage";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

const STATUS_COLORS: Record<string, string> = {
  active: "#27AE60",
  inactive: "#6B7C93",
  maintenance: "#F39C12",
  docked: "#2E86AB",
};
const STATUS_LABELS: Record<string, string> = {
  active: "نشطة",
  inactive: "غير نشطة",
  maintenance: "صيانة",
  docked: "راسية",
};

export default function VesselDetailScreen() {
  const { id } = useLocalSearchParams<{ id: string }>();
  const router = useRouter();
  const { vessels, invoices, updateVessel, deleteVessel, currentUser } = useApp();

  const vessel = vessels.find((v) => v.id === Number(id));
  const vesselInvoices = invoices.filter((inv) => inv.vesselId === Number(id));
  const canEdit = currentUser?.role === "admin" || currentUser?.role === "accountant";

  const [editMode, setEditMode] = useState(false);
  const [editData, setEditData] = useState<Partial<Vessel>>(vessel || {});

  if (!vessel) {
    return (
      <ScreenContainer>
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center" }}>
          <Text style={{ color: "#6B7C93", fontSize: 16 }}>السفينة غير موجودة</Text>
          <TouchableOpacity onPress={() => router.back()} style={{ marginTop: 16, backgroundColor: "#1E3A5F", borderRadius: 10, paddingHorizontal: 20, paddingVertical: 10 }}>
            <Text style={{ color: "white", fontWeight: "700" }}>العودة</Text>
          </TouchableOpacity>
        </View>
      </ScreenContainer>
    );
  }

  const handleSave = async () => {
    await updateVessel(vessel.id, editData);
    setEditMode(false);
  };

  const handleDelete = () => {
    Alert.alert("حذف السفينة", `هل أنت متأكد من حذف "${vessel.name}"؟`, [
      { text: "إلغاء", style: "cancel" },
      { text: "حذف", style: "destructive", onPress: async () => { await deleteVessel(vessel.id); router.back(); } },
    ]);
  };

  const statusColor = STATUS_COLORS[vessel.status] || "#6B7C93";
  const totalRevenue = vesselInvoices.filter((i) => i.status === "paid").reduce((s, i) => s + i.amount, 0);

  const inputStyle = {
    backgroundColor: "#F0F4F8",
    borderRadius: 10,
    paddingHorizontal: 14,
    paddingVertical: 10,
    fontSize: 14,
    color: "#1A2332",
    textAlign: "right" as const,
    borderWidth: 1,
    borderColor: "#D1DCE8",
    flex: 1,
  };

  return (
    <ScreenContainer containerClassName="bg-background">
      {/* Header */}
      <View style={{ backgroundColor: "#1E3A5F", paddingHorizontal: 20, paddingTop: 16, paddingBottom: 24 }}>
        <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <TouchableOpacity onPress={() => router.back()} style={{ width: 38, height: 38, borderRadius: 10, backgroundColor: "rgba(255,255,255,0.15)", alignItems: "center", justifyContent: "center" }}>
            <MaterialIcons name="arrow-forward" size={22} color="white" />
          </TouchableOpacity>
          <View style={{ flexDirection: "row", gap: 8 }}>
            {canEdit && !editMode && (
              <TouchableOpacity onPress={() => setEditMode(true)} style={{ backgroundColor: "#F5A623", borderRadius: 10, paddingHorizontal: 14, paddingVertical: 8 }}>
                <Text style={{ color: "white", fontSize: 13, fontWeight: "700" }}>تعديل</Text>
              </TouchableOpacity>
            )}
            {canEdit && editMode && (
              <>
                <TouchableOpacity onPress={handleSave} style={{ backgroundColor: "#27AE60", borderRadius: 10, paddingHorizontal: 14, paddingVertical: 8 }}>
                  <Text style={{ color: "white", fontSize: 13, fontWeight: "700" }}>حفظ</Text>
                </TouchableOpacity>
                <TouchableOpacity onPress={() => { setEditMode(false); setEditData(vessel); }} style={{ backgroundColor: "rgba(255,255,255,0.2)", borderRadius: 10, paddingHorizontal: 14, paddingVertical: 8 }}>
                  <Text style={{ color: "white", fontSize: 13, fontWeight: "700" }}>إلغاء</Text>
                </TouchableOpacity>
              </>
            )}
            {canEdit && !editMode && (
              <TouchableOpacity onPress={handleDelete} style={{ backgroundColor: "#E74C3C", borderRadius: 10, paddingHorizontal: 14, paddingVertical: 8 }}>
                <Text style={{ color: "white", fontSize: 13, fontWeight: "700" }}>حذف</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>

        <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 14 }}>
          <View style={{ width: 56, height: 56, borderRadius: 16, backgroundColor: "rgba(255,255,255,0.2)", alignItems: "center", justifyContent: "center" }}>
            <MaterialIcons name="directions-boat" size={28} color="white" />
          </View>
          <View>
            <Text style={{ color: "white", fontSize: 22, fontWeight: "800" }}>{vessel.name}</Text>
            <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 14 }}>{vessel.type}</Text>
            <View style={{ backgroundColor: statusColor + "40", borderRadius: 8, paddingHorizontal: 10, paddingVertical: 3, marginTop: 4, alignSelf: "flex-start" }}>
              <Text style={{ color: "white", fontSize: 12, fontWeight: "700" }}>{STATUS_LABELS[vessel.status]}</Text>
            </View>
          </View>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false}>
        {/* Stats */}
        <View style={{ flexDirection: "row-reverse", padding: 16, gap: 10 }}>
          <View style={{ flex: 1, backgroundColor: "white", borderRadius: 14, padding: 14, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
            <MaterialIcons name="description" size={20} color="#F39C12" />
            <Text style={{ fontSize: 22, fontWeight: "800", color: "#1A2332", marginTop: 6 }}>{vesselInvoices.length}</Text>
            <Text style={{ fontSize: 12, color: "#6B7C93" }}>فاتورة</Text>
          </View>
          <View style={{ flex: 1, backgroundColor: "white", borderRadius: 14, padding: 14, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
            <MaterialIcons name="paid" size={20} color="#27AE60" />
            <Text style={{ fontSize: 22, fontWeight: "800", color: "#1A2332", marginTop: 6 }}>${totalRevenue.toLocaleString()}</Text>
            <Text style={{ fontSize: 12, color: "#6B7C93" }}>إيرادات</Text>
          </View>
        </View>

        {/* Details */}
        <View style={{ backgroundColor: "white", marginHorizontal: 16, borderRadius: 16, padding: 16, marginBottom: 16, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
          <Text style={{ fontSize: 16, fontWeight: "700", color: "#1A2332", textAlign: "right", marginBottom: 14 }}>البيانات الأساسية</Text>
          {[
            { label: "رقم IMO", field: "imoNumber" as keyof Vessel, value: vessel.imoNumber },
            { label: "علامة النداء", field: "callSign" as keyof Vessel, value: vessel.callSign },
            { label: "GRT", field: "grt" as keyof Vessel, value: vessel.grt?.toString() },
            { label: "NRT", field: "nrt" as keyof Vessel, value: vessel.nrt?.toString() },
            { label: "الطول (م)", field: "length" as keyof Vessel, value: vessel.length?.toString() },
            { label: "علم السفينة", field: "flag" as keyof Vessel, value: vessel.flag },
            { label: "المالك", field: "owner" as keyof Vessel, value: vessel.owner },
          ].map((item, i, arr) => (
            <View key={item.label} style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", paddingVertical: 10, borderBottomWidth: i < arr.length - 1 ? 1 : 0, borderBottomColor: "#F0F4F8" }}>
              <Text style={{ fontSize: 14, color: "#6B7C93", fontWeight: "500" }}>{item.label}</Text>
              {editMode ? (
                <TextInput
                  value={String(editData[item.field] || "")}
                  onChangeText={(text) => setEditData({ ...editData, [item.field]: text })}
                  style={inputStyle}
                  textAlign="right"
                />
              ) : (
                <Text style={{ fontSize: 14, color: "#1A2332", fontWeight: "600" }}>{item.value || "—"}</Text>
              )}
            </View>
          ))}

          {/* Status in edit mode */}
          {editMode && (
            <View style={{ marginTop: 12 }}>
              <Text style={{ fontSize: 14, color: "#6B7C93", fontWeight: "500", textAlign: "right", marginBottom: 8 }}>الحالة</Text>
              <View style={{ flexDirection: "row-reverse", gap: 8 }}>
                {(["active", "docked", "maintenance", "inactive"] as Vessel["status"][]).map((s) => (
                  <TouchableOpacity
                    key={s}
                    onPress={() => setEditData({ ...editData, status: s })}
                    style={{ flex: 1, backgroundColor: editData.status === s ? STATUS_COLORS[s] : "#F0F4F8", borderRadius: 8, paddingVertical: 8, alignItems: "center" }}
                  >
                    <Text style={{ color: editData.status === s ? "white" : "#6B7C93", fontSize: 11, fontWeight: "600" }}>{STATUS_LABELS[s]}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </View>
          )}
        </View>

        {/* Dates */}
        {(vessel.arrivalDate || vessel.departureDate) && (
          <View style={{ backgroundColor: "white", marginHorizontal: 16, borderRadius: 16, padding: 16, marginBottom: 16, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
            <Text style={{ fontSize: 16, fontWeight: "700", color: "#1A2332", textAlign: "right", marginBottom: 12 }}>التواريخ</Text>
            {vessel.arrivalDate && (
              <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", paddingVertical: 8 }}>
                <Text style={{ fontSize: 14, color: "#6B7C93" }}>تاريخ الوصول</Text>
                <Text style={{ fontSize: 14, color: "#27AE60", fontWeight: "600" }}>{new Date(vessel.arrivalDate).toLocaleDateString("ar-SA")}</Text>
              </View>
            )}
            {vessel.departureDate && (
              <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", paddingVertical: 8 }}>
                <Text style={{ fontSize: 14, color: "#6B7C93" }}>تاريخ المغادرة</Text>
                <Text style={{ fontSize: 14, color: "#E74C3C", fontWeight: "600" }}>{new Date(vessel.departureDate).toLocaleDateString("ar-SA")}</Text>
              </View>
            )}
          </View>
        )}

        {/* Related Invoices */}
        {vesselInvoices.length > 0 && (
          <View style={{ marginHorizontal: 16, marginBottom: 20 }}>
            <Text style={{ fontSize: 16, fontWeight: "700", color: "#1A2332", textAlign: "right", marginBottom: 12 }}>الفواتير المرتبطة</Text>
            {vesselInvoices.map((inv) => (
              <TouchableOpacity
                key={inv.id}
                onPress={() => router.push(`/invoice/${inv.id}` as any)}
                style={{ backgroundColor: "white", borderRadius: 12, padding: 14, marginBottom: 8, flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 4, elevation: 2 }}
              >
                <View>
                  <Text style={{ fontSize: 14, fontWeight: "700", color: "#1A2332" }}>{inv.invoiceNumber}</Text>
                  <Text style={{ fontSize: 12, color: "#6B7C93" }}>{new Date(inv.issuedDate).toLocaleDateString("ar-SA")}</Text>
                </View>
                <View style={{ alignItems: "flex-end" }}>
                  <Text style={{ fontSize: 15, fontWeight: "700", color: "#1E3A5F" }}>${inv.amount.toLocaleString()}</Text>
                  <View style={{ backgroundColor: (inv.status === "paid" ? "#27AE60" : inv.status === "overdue" ? "#E74C3C" : "#F39C12") + "20", borderRadius: 6, paddingHorizontal: 8, paddingVertical: 2, marginTop: 4 }}>
                    <Text style={{ fontSize: 11, fontWeight: "700", color: inv.status === "paid" ? "#27AE60" : inv.status === "overdue" ? "#E74C3C" : "#F39C12" }}>
                      {inv.status === "paid" ? "مدفوع" : inv.status === "overdue" ? "متأخر" : "معلق"}
                    </Text>
                  </View>
                </View>
              </TouchableOpacity>
            ))}
          </View>
        )}
      </ScrollView>
    </ScreenContainer>
  );
}
