/** @type {const} */
const themeColors = {
  primary: { light: '#1E3A5F', dark: '#2E86AB' },
  background: { light: '#F0F4F8', dark: '#0D1B2A' },
  surface: { light: '#FFFFFF', dark: '#1A2B3C' },
  foreground: { light: '#1A2332', dark: '#E8EDF2' },
  muted: { light: '#6B7C93', dark: '#8A9BB0' },
  border: { light: '#D1DCE8', dark: '#2A3F55' },
  success: { light: '#27AE60', dark: '#2ECC71' },
  warning: { light: '#F39C12', dark: '#F5A623' },
  error: { light: '#E74C3C', dark: '#FF6B6B' },
  accent: { light: '#F5A623', dark: '#F5A623' },
  tint: { light: '#1E3A5F', dark: '#2E86AB' },
};

module.exports = { themeColors };
