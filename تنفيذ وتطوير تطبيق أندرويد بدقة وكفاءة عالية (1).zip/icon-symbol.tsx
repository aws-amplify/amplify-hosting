import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { SymbolWeight } from "expo-symbols";
import { ComponentProps } from "react";
import { OpaqueColorValue, type StyleProp, type TextStyle } from "react-native";

type MaterialIconName = ComponentProps<typeof MaterialIcons>["name"];

// Custom icon mapping - maps our app icon names to Material Icons
const MAPPING: Record<string, MaterialIconName> = {
  // Navigation
  "house.fill": "home",
  "vessel.fill": "directions-boat",
  "invoice.fill": "receipt-long",
  "reports.fill": "bar-chart",
  "settings.fill": "settings",
  // Common
  "paperplane.fill": "send",
  "chevron.left.forwardslash.chevron.right": "code",
  "chevron.right": "chevron-right",
  "chevron.left": "chevron-left",
  "chevron.down": "keyboard-arrow-down",
  "chevron.up": "keyboard-arrow-up",
  // Actions
  "plus": "add",
  "plus.circle.fill": "add-circle",
  "pencil": "edit",
  "trash": "delete",
  "trash.fill": "delete",
  "magnifyingglass": "search",
  "bell.fill": "notifications",
  "bell": "notifications-none",
  "gear": "settings",
  "person.fill": "person",
  "person.circle": "account-circle",
  "lock.fill": "lock",
  "eye": "visibility",
  "eye.slash": "visibility-off",
  "checkmark": "check",
  "checkmark.circle.fill": "check-circle",
  "xmark": "close",
  "xmark.circle.fill": "cancel",
  // Files & Documents
  "doc.fill": "description",
  "doc.text": "article",
  "folder.fill": "folder",
  "paperclip": "attach-file",
  "arrow.up.doc": "upload-file",
  "arrow.down.doc": "download",
  "archivebox.fill": "archive",
  // Finance
  "dollarsign.circle.fill": "monetization-on",
  "creditcard.fill": "credit-card",
  "banknote": "payments",
  "chart.bar.fill": "bar-chart",
  "chart.pie.fill": "pie-chart",
  // Status
  "clock.fill": "schedule",
  "calendar": "calendar-today",
  "star.fill": "star",
  "flag.fill": "flag",
  "info.circle": "info",
  "exclamationmark.triangle.fill": "warning",
  "checkmark.seal.fill": "verified",
  // Misc
  "arrow.left": "arrow-back",
  "arrow.right": "arrow-forward",
  "arrow.clockwise": "refresh",
  "square.and.arrow.up": "share",
  "printer": "print",
  "qrcode": "qr-code",
  "wifi": "wifi",
  "moon.fill": "dark-mode",
  "sun.max.fill": "light-mode",
};

export type IconSymbolName = keyof typeof MAPPING;

export function IconSymbol({
  name,
  size = 24,
  color,
  style,
}: {
  name: IconSymbolName;
  size?: number;
  color: string | OpaqueColorValue;
  style?: StyleProp<TextStyle>;
  weight?: SymbolWeight;
}) {
  const iconName = MAPPING[name] || "help-outline";
  return <MaterialIcons color={color} size={size} name={iconName} style={style} />;
}
