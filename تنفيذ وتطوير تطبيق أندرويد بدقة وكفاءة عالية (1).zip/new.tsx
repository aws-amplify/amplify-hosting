import { useState } from "react";
import { View, Text, ScrollView, TouchableOpacity, TextInput, Alert } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useApp } from "@/lib/app-context";
import type { Vessel } from "@/lib/storage";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";

const VESSEL_TYPES = [
  "ناقلة نفط",
  "سفينة حاويات",
  "سفينة بضائع عامة",
  "ناقلة كيماويات",
  "سفينة رورو",
  "سفينة صب",
  "سفينة متعددة الأغراض",
  "سفينة شحن",
];

const FLAGS = [
  "اليمن", "السعودية", "الإمارات", "الكويت", "قطر", "البحرين",
  "عُمان", "مصر", "باناما", "اليونان", "قبرص", "مالطا",
];

const STATUS_OPTIONS: { key: Vessel["status"]; label: string; color: string }[] = [
  { key: "active", label: "نشطة", color: "#27AE60" },
  { key: "docked", label: "راسية", color: "#2E86AB" },
  { key: "maintenance", label: "صيانة", color: "#F39C12" },
  { key: "inactive", label: "غير نشطة", color: "#6B7C93" },
];

export default function NewVesselScreen() {
  const router = useRouter();
  const { addVessel } = useApp();

  const [name, setName] = useState("");
  const [type, setType] = useState(VESSEL_TYPES[0]);
  const [imoNumber, setImoNumber] = useState("");
  const [callSign, setCallSign] = useState("");
  const [grt, setGrt] = useState("");
  const [nrt, setNrt] = useState("");
  const [length, setLength] = useState("");
  const [flag, setFlag] = useState(FLAGS[0]);
  const [owner, setOwner] = useState("");
  const [arrivalDate, setArrivalDate] = useState("");
  const [status, setStatus] = useState<Vessel["status"]>("active");
  const [notes, setNotes] = useState("");
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmit = async () => {
    if (!name.trim()) {
      Alert.alert("خطأ", "يرجى إدخال اسم السفينة");
      return;
    }
    if (!imoNumber.trim()) {
      Alert.alert("خطأ", "يرجى إدخال رقم IMO");
      return;
    }

    setIsSubmitting(true);
    try {
      await addVessel({
        name: name.trim(),
        type,
        imoNumber: imoNumber.trim(),
        callSign: callSign.trim() || undefined,
        grt: grt ? parseFloat(grt) : undefined,
        nrt: nrt ? parseFloat(nrt) : undefined,
        length: length ? parseFloat(length) : undefined,
        flag,
        owner: owner.trim() || undefined,
        arrivalDate: arrivalDate ? new Date(arrivalDate).toISOString() : undefined,
        status,
        notes: notes.trim() || undefined,
      });
      Alert.alert("نجاح", "تم إضافة السفينة بنجاح", [
        { text: "حسناً", onPress: () => router.back() },
      ]);
    } finally {
      setIsSubmitting(false);
    }
  };

  const inputStyle = {
    backgroundColor: "#F0F4F8",
    borderRadius: 12,
    paddingHorizontal: 16,
    paddingVertical: 13,
    fontSize: 15,
    color: "#1A2332",
    textAlign: "right" as const,
    borderWidth: 1,
    borderColor: "#D1DCE8",
    marginBottom: 16,
  };

  const labelStyle = {
    fontSize: 13,
    fontWeight: "600" as const,
    color: "#6B7C93",
    textAlign: "right" as const,
    marginBottom: 8,
  };

  return (
    <ScreenContainer containerClassName="bg-background">
      {/* Header */}
      <View style={{ backgroundColor: "#1E3A5F", paddingHorizontal: 20, paddingTop: 16, paddingBottom: 20, flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" }}>
        <Text style={{ color: "white", fontSize: 20, fontWeight: "800" }}>إضافة سفينة جديدة</Text>
        <TouchableOpacity onPress={() => router.back()} style={{ width: 38, height: 38, borderRadius: 10, backgroundColor: "rgba(255,255,255,0.15)", alignItems: "center", justifyContent: "center" }}>
          <MaterialIcons name="arrow-forward" size={22} color="white" />
        </TouchableOpacity>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 20 }}>
        {/* Basic Info */}
        <View style={{ backgroundColor: "white", borderRadius: 16, padding: 16, marginBottom: 16, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
          <Text style={{ fontSize: 15, fontWeight: "700", color: "#1A2332", textAlign: "right", marginBottom: 16 }}>البيانات الأساسية</Text>
          
          <Text style={labelStyle}>اسم السفينة *</Text>
          <TextInput value={name} onChangeText={setName} placeholder="BREEZE STAR" placeholderTextColor="#9BA1A6" style={inputStyle} />
          
          <Text style={labelStyle}>رقم IMO *</Text>
          <TextInput value={imoNumber} onChangeText={setImoNumber} placeholder="IMO1234567" placeholderTextColor="#9BA1A6" style={inputStyle} />
          
          <Text style={labelStyle}>علامة النداء</Text>
          <TextInput value={callSign} onChangeText={setCallSign} placeholder="BRSZ" placeholderTextColor="#9BA1A6" style={inputStyle} />
          
          <Text style={labelStyle}>المالك</Text>
          <TextInput value={owner} onChangeText={setOwner} placeholder="شركة الخليج للملاحة" placeholderTextColor="#9BA1A6" style={inputStyle} />
        </View>

        {/* Type */}
        <View style={{ backgroundColor: "white", borderRadius: 16, padding: 16, marginBottom: 16, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
          <Text style={{ fontSize: 15, fontWeight: "700", color: "#1A2332", textAlign: "right", marginBottom: 12 }}>نوع السفينة</Text>
          <View style={{ flexDirection: "row-reverse", flexWrap: "wrap", gap: 8 }}>
            {VESSEL_TYPES.map((t) => (
              <TouchableOpacity
                key={t}
                onPress={() => setType(t)}
                style={{ backgroundColor: type === t ? "#1E3A5F" : "#F0F4F8", borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8 }}
              >
                <Text style={{ color: type === t ? "white" : "#6B7C93", fontSize: 12, fontWeight: "600" }}>{t}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Technical Specs */}
        <View style={{ backgroundColor: "white", borderRadius: 16, padding: 16, marginBottom: 16, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
          <Text style={{ fontSize: 15, fontWeight: "700", color: "#1A2332", textAlign: "right", marginBottom: 16 }}>المواصفات التقنية</Text>
          <View style={{ flexDirection: "row-reverse", gap: 12 }}>
            <View style={{ flex: 1 }}>
              <Text style={labelStyle}>GRT</Text>
              <TextInput value={grt} onChangeText={setGrt} placeholder="45000" placeholderTextColor="#9BA1A6" keyboardType="decimal-pad" style={inputStyle} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={labelStyle}>NRT</Text>
              <TextInput value={nrt} onChangeText={setNrt} placeholder="28000" placeholderTextColor="#9BA1A6" keyboardType="decimal-pad" style={inputStyle} />
            </View>
          </View>
          <Text style={labelStyle}>الطول (م)</Text>
          <TextInput value={length} onChangeText={setLength} placeholder="185.5" placeholderTextColor="#9BA1A6" keyboardType="decimal-pad" style={inputStyle} />
        </View>

        {/* Flag */}
        <View style={{ backgroundColor: "white", borderRadius: 16, padding: 16, marginBottom: 16, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
          <Text style={{ fontSize: 15, fontWeight: "700", color: "#1A2332", textAlign: "right", marginBottom: 12 }}>علم السفينة</Text>
          <View style={{ flexDirection: "row-reverse", flexWrap: "wrap", gap: 8 }}>
            {FLAGS.map((f) => (
              <TouchableOpacity
                key={f}
                onPress={() => setFlag(f)}
                style={{ backgroundColor: flag === f ? "#1E3A5F" : "#F0F4F8", borderRadius: 10, paddingHorizontal: 12, paddingVertical: 8 }}
              >
                <Text style={{ color: flag === f ? "white" : "#6B7C93", fontSize: 12, fontWeight: "600" }}>{f}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Status */}
        <View style={{ backgroundColor: "white", borderRadius: 16, padding: 16, marginBottom: 16, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
          <Text style={{ fontSize: 15, fontWeight: "700", color: "#1A2332", textAlign: "right", marginBottom: 12 }}>حالة السفينة</Text>
          <View style={{ flexDirection: "row-reverse", gap: 8 }}>
            {STATUS_OPTIONS.map((opt) => (
              <TouchableOpacity
                key={opt.key}
                onPress={() => setStatus(opt.key)}
                style={{ flex: 1, backgroundColor: status === opt.key ? opt.color : "white", borderRadius: 10, paddingVertical: 10, alignItems: "center", borderWidth: 1, borderColor: status === opt.key ? opt.color : "#D1DCE8" }}
              >
                <Text style={{ color: status === opt.key ? "white" : "#1A2332", fontSize: 12, fontWeight: "700" }}>{opt.label}</Text>
              </TouchableOpacity>
            ))}
          </View>
        </View>

        {/* Arrival Date */}
        <View style={{ backgroundColor: "white", borderRadius: 16, padding: 16, marginBottom: 16, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.06, shadowRadius: 4, elevation: 2 }}>
          <Text style={{ fontSize: 15, fontWeight: "700", color: "#1A2332", textAlign: "right", marginBottom: 16 }}>التواريخ</Text>
          <Text style={labelStyle}>تاريخ الوصول (YYYY-MM-DD)</Text>
          <TextInput value={arrivalDate} onChangeText={setArrivalDate} placeholder="2026-02-25" placeholderTextColor="#9BA1A6" style={inputStyle} />
          <Text style={labelStyle}>ملاحظات</Text>
          <TextInput value={notes} onChangeText={setNotes} placeholder="ملاحظات إضافية..." placeholderTextColor="#9BA1A6" multiline numberOfLines={3} style={{ ...inputStyle, height: 80, textAlignVertical: "top" }} />
        </View>

        {/* Submit */}
        <TouchableOpacity
          onPress={handleSubmit}
          disabled={isSubmitting}
          style={{
            backgroundColor: isSubmitting ? "#9BA1A6" : "#1E3A5F",
            borderRadius: 14,
            paddingVertical: 16,
            alignItems: "center",
            marginBottom: 40,
            flexDirection: "row-reverse",
            justifyContent: "center",
            gap: 8,
          }}
        >
          <MaterialIcons name="directions-boat" size={22} color="white" />
          <Text style={{ color: "white", fontSize: 17, fontWeight: "700" }}>
            {isSubmitting ? "جاري الإضافة..." : "إضافة السفينة"}
          </Text>
        </TouchableOpacity>
      </ScrollView>
    </ScreenContainer>
  );
}
