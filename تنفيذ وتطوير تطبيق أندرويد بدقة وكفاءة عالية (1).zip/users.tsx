import { View, Text, ScrollView, TouchableOpacity, TextInput, Alert, Modal, Switch } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useApp } from "@/lib/app-context";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useState } from "react";
import { SystemUser, PERMISSIONS, ROLE_PERMISSIONS, type Permission } from "@/lib/storage";

const ROLES = [
  { key: "admin", label: "مدير النظام", color: "#E74C3C", icon: "admin-panel-settings" },
  { key: "accountant", label: "محاسب", color: "#3498DB", icon: "calculate" },
  { key: "reviewer", label: "مراجع", color: "#9B59B6", icon: "rate-review" },
  { key: "user", label: "مستخدم", color: "#27AE60", icon: "person" },
  { key: "client", label: "عميل", color: "#F39C12", icon: "business" },
] as const;

const PERMISSION_GROUPS = [
  {
    group: "السفن",
    perms: [
      { key: PERMISSIONS.VESSEL_VIEW, label: "عرض السفن" },
      { key: PERMISSIONS.VESSEL_CREATE, label: "إضافة سفن" },
      { key: PERMISSIONS.VESSEL_EDIT, label: "تعديل السفن" },
      { key: PERMISSIONS.VESSEL_DELETE, label: "حذف السفن" },
    ],
  },
  {
    group: "الفواتير",
    perms: [
      { key: PERMISSIONS.INVOICE_VIEW, label: "عرض الفواتير" },
      { key: PERMISSIONS.INVOICE_CREATE, label: "إنشاء فواتير" },
      { key: PERMISSIONS.INVOICE_EDIT, label: "تعديل الفواتير" },
      { key: PERMISSIONS.INVOICE_APPROVE, label: "الموافقة على الفواتير" },
      { key: PERMISSIONS.INVOICE_REJECT, label: "رفض الفواتير" },
      { key: PERMISSIONS.INVOICE_DELETE, label: "حذف الفواتير" },
    ],
  },
  {
    group: "المذكرات",
    perms: [
      { key: PERMISSIONS.MEMO_VIEW, label: "عرض المذكرات" },
      { key: PERMISSIONS.MEMO_CREATE, label: "إنشاء مذكرات" },
      { key: PERMISSIONS.MEMO_EDIT, label: "تعديل المذكرات" },
      { key: PERMISSIONS.MEMO_SEND, label: "إرسال المذكرات" },
      { key: PERMISSIONS.MEMO_DELETE, label: "حذف المذكرات" },
    ],
  },
  {
    group: "الأرشيف والتقارير",
    perms: [
      { key: PERMISSIONS.ARCHIVE_VIEW, label: "عرض الأرشيف" },
      { key: PERMISSIONS.ARCHIVE_CREATE, label: "إضافة للأرشيف" },
      { key: PERMISSIONS.REPORT_VIEW, label: "عرض التقارير" },
      { key: PERMISSIONS.REPORT_EXPORT, label: "تصدير التقارير" },
    ],
  },
  {
    group: "الإدارة",
    perms: [
      { key: PERMISSIONS.PRICING_VIEW, label: "عرض الأسعار" },
      { key: PERMISSIONS.PRICING_EDIT, label: "تعديل الأسعار" },
      { key: PERMISSIONS.USER_VIEW, label: "عرض المستخدمين" },
      { key: PERMISSIONS.USER_CREATE, label: "إضافة مستخدمين" },
      { key: PERMISSIONS.USER_EDIT, label: "تعديل المستخدمين" },
      { key: PERMISSIONS.USER_DELETE, label: "حذف المستخدمين" },
      { key: PERMISSIONS.REVIEW_VIEW, label: "عرض المراجعات" },
      { key: PERMISSIONS.REVIEW_CREATE, label: "إنشاء مراجعات" },
    ],
  },
];

export default function UsersScreen() {
  const router = useRouter();
  const { currentUser, systemUsers, addSystemUser, updateSystemUser, deleteSystemUser } = useApp();
  const [showModal, setShowModal] = useState(false);
  const [editingUser, setEditingUser] = useState<SystemUser | null>(null);
  const [showPermModal, setShowPermModal] = useState(false);
  const [permUser, setPermUser] = useState<SystemUser | null>(null);

  // Form state
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [role, setRole] = useState<SystemUser["role"]>("user");
  const [isActive, setIsActive] = useState(true);

  const isAdmin = currentUser?.role === "admin";

  if (!isAdmin) {
    return (
      <ScreenContainer>
        <View style={{ flex: 1, alignItems: "center", justifyContent: "center", padding: 40 }}>
          <MaterialIcons name="lock" size={64} color="#E74C3C" />
          <Text style={{ fontSize: 18, fontWeight: "700", color: "#1A2332", marginTop: 16, textAlign: "center" }}>غير مصرح</Text>
          <Text style={{ fontSize: 14, color: "#6B7C93", marginTop: 8, textAlign: "center" }}>هذه الصفحة متاحة لمدير النظام فقط</Text>
          <TouchableOpacity onPress={() => router.back()} style={{ marginTop: 24, backgroundColor: "#1E3A5F", borderRadius: 12, paddingHorizontal: 24, paddingVertical: 12 }}>
            <Text style={{ color: "white", fontWeight: "700" }}>رجوع</Text>
          </TouchableOpacity>
        </View>
      </ScreenContainer>
    );
  }

  const openAdd = () => {
    setEditingUser(null);
    setName(""); setEmail(""); setPassword(""); setRole("user"); setIsActive(true);
    setShowModal(true);
  };

  const openEdit = (user: SystemUser) => {
    setEditingUser(user);
    setName(user.name); setEmail(user.email); setPassword(""); setRole(user.role); setIsActive(user.isActive);
    setShowModal(true);
  };

  const handleSave = async () => {
    if (!name.trim() || !email.trim()) {
      Alert.alert("خطأ", "يرجى إدخال الاسم والبريد الإلكتروني");
      return;
    }
    if (!editingUser && !password.trim()) {
      Alert.alert("خطأ", "يرجى إدخال كلمة المرور للمستخدم الجديد");
      return;
    }
    if (editingUser) {
      await updateSystemUser(editingUser.id, {
        name: name.trim(),
        email: email.trim(),
        role,
        isActive,
        ...(password.trim() ? { passwordHash: password.trim() } : {}),
      });
    } else {
      await addSystemUser({
        name: name.trim(),
        email: email.trim(),
        passwordHash: password.trim(),
        role,
        isActive,
        permissions: [],
      });
    }
    setShowModal(false);
    Alert.alert("نجاح", editingUser ? "تم تحديث المستخدم" : "تم إضافة المستخدم");
  };

  const handleDelete = (user: SystemUser) => {
    if (user.id === currentUser?.id) {
      Alert.alert("خطأ", "لا يمكن حذف حسابك الخاص");
      return;
    }
    Alert.alert("تأكيد الحذف", `هل تريد حذف المستخدم "${user.name}"؟`, [
      { text: "إلغاء", style: "cancel" },
      { text: "حذف", style: "destructive", onPress: () => deleteSystemUser(user.id) },
    ]);
  };

  const openPermissions = (user: SystemUser) => {
    setPermUser(user);
    setShowPermModal(true);
  };

  const togglePermission = async (user: SystemUser, perm: Permission) => {
    const current = user.permissions || [];
    const updated = current.includes(perm) ? current.filter((p) => p !== perm) : [...current, perm];
    await updateSystemUser(user.id, { permissions: updated });
    setPermUser({ ...user, permissions: updated });
  };

  const getRoleInfo = (roleKey: string) => ROLES.find((r) => r.key === roleKey) || ROLES[3];

  return (
    <ScreenContainer containerClassName="bg-background">
      {/* Header */}
      <View style={{ backgroundColor: "#1E3A5F", paddingHorizontal: 20, paddingTop: 16, paddingBottom: 20 }}>
        <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" }}>
          <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10 }}>
            <View style={{ width: 42, height: 42, borderRadius: 12, backgroundColor: "rgba(255,255,255,0.15)", alignItems: "center", justifyContent: "center" }}>
              <MaterialIcons name="group" size={22} color="white" />
            </View>
            <View>
              <Text style={{ color: "white", fontSize: 18, fontWeight: "800" }}>إدارة المستخدمين</Text>
              <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 12 }}>{systemUsers.length} مستخدم</Text>
            </View>
          </View>
          <View style={{ flexDirection: "row-reverse", gap: 8 }}>
            <TouchableOpacity onPress={openAdd} style={{ backgroundColor: "#27AE60", borderRadius: 10, paddingHorizontal: 14, paddingVertical: 8, flexDirection: "row-reverse", alignItems: "center", gap: 4 }}>
              <MaterialIcons name="person-add" size={16} color="white" />
              <Text style={{ color: "white", fontSize: 13, fontWeight: "700" }}>إضافة</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => router.back()} style={{ width: 38, height: 38, borderRadius: 10, backgroundColor: "rgba(255,255,255,0.15)", alignItems: "center", justifyContent: "center" }}>
              <MaterialIcons name="arrow-forward" size={22} color="white" />
            </TouchableOpacity>
          </View>
        </View>
      </View>

      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ padding: 16 }}>
        {systemUsers.map((user) => {
          const roleInfo = getRoleInfo(user.role);
          const rolePerms = ROLE_PERMISSIONS[user.role] || [];
          return (
            <View key={user.id} style={{ backgroundColor: "white", borderRadius: 16, padding: 16, marginBottom: 12, shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 6, elevation: 2 }}>
              <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "flex-start" }}>
                <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 12, flex: 1 }}>
                  <View style={{ width: 48, height: 48, borderRadius: 24, backgroundColor: roleInfo.color + "20", alignItems: "center", justifyContent: "center" }}>
                    <MaterialIcons name={roleInfo.icon as any} size={24} color={roleInfo.color} />
                  </View>
                  <View style={{ flex: 1 }}>
                    <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 8 }}>
                      <Text style={{ fontSize: 15, fontWeight: "700", color: "#1A2332" }}>{user.name}</Text>
                      {!user.isActive && (
                        <View style={{ backgroundColor: "#FEE2E2", borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 }}>
                          <Text style={{ fontSize: 10, color: "#E74C3C", fontWeight: "700" }}>معطل</Text>
                        </View>
                      )}
                    </View>
                    <Text style={{ fontSize: 12, color: "#6B7C93", marginTop: 2 }}>{user.email}</Text>
                    <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 6, marginTop: 6 }}>
                      <View style={{ backgroundColor: roleInfo.color + "15", borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 }}>
                        <Text style={{ fontSize: 11, color: roleInfo.color, fontWeight: "700" }}>{roleInfo.label}</Text>
                      </View>
                      <Text style={{ fontSize: 11, color: "#9BA1A6" }}>{rolePerms.length} صلاحية</Text>
                    </View>
                  </View>
                </View>
                <View style={{ gap: 6 }}>
                  <TouchableOpacity onPress={() => openEdit(user)} style={{ backgroundColor: "#EBF4FF", borderRadius: 8, padding: 8 }}>
                    <MaterialIcons name="edit" size={16} color="#1E3A5F" />
                  </TouchableOpacity>
                  <TouchableOpacity onPress={() => openPermissions(user)} style={{ backgroundColor: "#F0FFF4", borderRadius: 8, padding: 8 }}>
                    <MaterialIcons name="security" size={16} color="#27AE60" />
                  </TouchableOpacity>
                  {user.id !== currentUser?.id && (
                    <TouchableOpacity onPress={() => handleDelete(user)} style={{ backgroundColor: "#FEE2E2", borderRadius: 8, padding: 8 }}>
                      <MaterialIcons name="delete" size={16} color="#E74C3C" />
                    </TouchableOpacity>
                  )}
                </View>
              </View>
            </View>
          );
        })}
      </ScrollView>

      {/* Add/Edit Modal */}
      <Modal visible={showModal} transparent animationType="slide">
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}>
          <View style={{ backgroundColor: "white", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, maxHeight: "85%" }}>
            <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
              <Text style={{ fontSize: 18, fontWeight: "800", color: "#1A2332" }}>{editingUser ? "تعديل المستخدم" : "إضافة مستخدم جديد"}</Text>
              <TouchableOpacity onPress={() => setShowModal(false)}>
                <MaterialIcons name="close" size={24} color="#6B7C93" />
              </TouchableOpacity>
            </View>
            <ScrollView showsVerticalScrollIndicator={false}>
              {[
                { label: "الاسم الكامل *", value: name, setter: setName, placeholder: "أدخل الاسم" },
                { label: "البريد الإلكتروني *", value: email, setter: setEmail, placeholder: "example@habib.com" },
                { label: editingUser ? "كلمة المرور الجديدة (اتركها فارغة للإبقاء)" : "كلمة المرور *", value: password, setter: setPassword, placeholder: "••••••••", secure: true },
              ].map((field, idx) => (
                <View key={idx} style={{ marginBottom: 14 }}>
                  <Text style={{ fontSize: 13, color: "#6B7C93", textAlign: "right", marginBottom: 6 }}>{field.label}</Text>
                  <TextInput
                    value={field.value}
                    onChangeText={field.setter}
                    placeholder={field.placeholder}
                    secureTextEntry={field.secure}
                    style={{ backgroundColor: "#F8FAFC", borderRadius: 12, padding: 14, fontSize: 14, textAlign: "right", borderWidth: 1, borderColor: "#E5E7EB" }}
                  />
                </View>
              ))}

              <Text style={{ fontSize: 13, color: "#6B7C93", textAlign: "right", marginBottom: 8 }}>الدور</Text>
              <View style={{ flexDirection: "row-reverse", flexWrap: "wrap", gap: 8, marginBottom: 14 }}>
                {ROLES.map((r) => (
                  <TouchableOpacity
                    key={r.key}
                    onPress={() => setRole(r.key)}
                    style={{ paddingHorizontal: 14, paddingVertical: 8, borderRadius: 10, backgroundColor: role === r.key ? r.color : "#F0F4F8", borderWidth: 1, borderColor: role === r.key ? r.color : "#E5E7EB" }}
                  >
                    <Text style={{ fontSize: 13, color: role === r.key ? "white" : "#6B7C93", fontWeight: role === r.key ? "700" : "400" }}>{r.label}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
                <Text style={{ fontSize: 14, color: "#1A2332", fontWeight: "600" }}>الحساب نشط</Text>
                <Switch value={isActive} onValueChange={setIsActive} trackColor={{ true: "#27AE60" }} />
              </View>

              <TouchableOpacity onPress={handleSave} style={{ backgroundColor: "#1E3A5F", borderRadius: 14, paddingVertical: 16, alignItems: "center" }}>
                <Text style={{ color: "white", fontSize: 16, fontWeight: "700" }}>{editingUser ? "حفظ التعديلات" : "إضافة المستخدم"}</Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Permissions Modal */}
      <Modal visible={showPermModal} transparent animationType="slide">
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}>
          <View style={{ backgroundColor: "white", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, maxHeight: "90%" }}>
            <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 4 }}>
              <Text style={{ fontSize: 18, fontWeight: "800", color: "#1A2332" }}>صلاحيات: {permUser?.name}</Text>
              <TouchableOpacity onPress={() => setShowPermModal(false)}>
                <MaterialIcons name="close" size={24} color="#6B7C93" />
              </TouchableOpacity>
            </View>
            <Text style={{ fontSize: 12, color: "#9BA1A6", textAlign: "right", marginBottom: 16 }}>الصلاحيات الإضافية فوق صلاحيات الدور الافتراضي</Text>
            <ScrollView showsVerticalScrollIndicator={false}>
              {PERMISSION_GROUPS.map((group, gIdx) => (
                <View key={gIdx} style={{ marginBottom: 16 }}>
                  <Text style={{ fontSize: 14, fontWeight: "700", color: "#1E3A5F", textAlign: "right", marginBottom: 8 }}>{group.group}</Text>
                  {group.perms.map((perm, pIdx) => {
                    const isRolePerm = permUser ? (ROLE_PERMISSIONS[permUser.role] || []).includes(perm.key) : false;
                    const isExtraPerm = permUser ? (permUser.permissions || []).includes(perm.key) : false;
                    const isActive = isRolePerm || isExtraPerm;
                    return (
                      <View key={pIdx} style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", paddingVertical: 8, borderBottomWidth: pIdx < group.perms.length - 1 ? 1 : 0, borderBottomColor: "#F0F4F8" }}>
                        <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 8 }}>
                          <MaterialIcons name={isActive ? "check-circle" : "radio-button-unchecked"} size={18} color={isActive ? "#27AE60" : "#D1D5DB"} />
                          <Text style={{ fontSize: 13, color: isActive ? "#1A2332" : "#9BA1A6" }}>{perm.label}</Text>
                          {isRolePerm && <View style={{ backgroundColor: "#EBF4FF", borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 }}><Text style={{ fontSize: 10, color: "#1E3A5F" }}>من الدور</Text></View>}
                        </View>
                        {!isRolePerm && permUser && (
                          <Switch
                            value={isExtraPerm}
                            onValueChange={() => togglePermission(permUser, perm.key)}
                            trackColor={{ true: "#27AE60" }}
                          />
                        )}
                      </View>
                    );
                  })}
                </View>
              ))}
            </ScrollView>
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}
