import { useAuth } from "@/_core/hooks/useAuth";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { CreditCard, DollarSign, CheckCircle, AlertCircle, Clock, Download } from "lucide-react";
import { useState } from "react";

export default function PaymentManagement() {
  const { user } = useAuth();
  const [payments, setPayments] = useState([
    {
      id: 1,
      invoiceNumber: "#2024-001",
      amount: 50000,
      currency: "SAR",
      status: "مكتمل",
      method: "Stripe",
      date: "2026-02-20",
      reference: "STR-2024-001",
    },
    {
      id: 2,
      invoiceNumber: "#2024-045",
      amount: 75000,
      currency: "SAR",
      status: "معلق",
      method: "PayPal",
      date: "2026-02-21",
      reference: "PP-2024-045",
    },
    {
      id: 3,
      invoiceNumber: "#2024-089",
      amount: 120000,
      currency: "USD",
      status: "فاشل",
      method: "بنك محلي",
      date: "2026-02-22",
      reference: "BANK-2024-089",
    },
    {
      id: 4,
      invoiceNumber: "#2024-102",
      amount: 45000,
      currency: "SAR",
      status: "مكتمل",
      method: "Apple Pay",
      date: "2026-02-19",
      reference: "AP-2024-102",
    },
  ]);

  const getStatusColor = (status: string) => {
    switch (status) {
      case "مكتمل":
        return "bg-green-100 text-green-800 border-green-300";
      case "معلق":
        return "bg-yellow-100 text-yellow-800 border-yellow-300";
      case "فاشل":
        return "bg-red-100 text-red-800 border-red-300";
      default:
        return "bg-gray-100 text-gray-800 border-gray-300";
    }
  };

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "مكتمل":
        return <CheckCircle className="w-5 h-5 text-green-600" />;
      case "معلق":
        return <Clock className="w-5 h-5 text-yellow-600" />;
      case "فاشل":
        return <AlertCircle className="w-5 h-5 text-red-600" />;
      default:
        return <CreditCard className="w-5 h-5 text-gray-600" />;
    }
  };

  const totalReceived = payments.filter(p => p.status === "مكتمل").reduce((sum, p) => sum + p.amount, 0);
  const totalPending = payments.filter(p => p.status === "معلق").reduce((sum, p) => sum + p.amount, 0);
  const totalFailed = payments.filter(p => p.status === "فاشل").reduce((sum, p) => sum + p.amount, 0);

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-slate-100 p-8">
      <div className="max-w-7xl mx-auto">
        {/* رأس الصفحة */}
        <div className="mb-8">
          <h1 className="text-4xl font-bold text-slate-900 mb-2">إدارة الدفع والتحصيل</h1>
          <p className="text-slate-600">تتبع وإدارة جميع عمليات الدفع والتحصيل</p>
        </div>

        {/* الإحصائيات */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-8">
          <Card className="bg-gradient-to-br from-green-500 to-green-600 text-white p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-green-100 text-sm">المبالغ المستقبلة</p>
                <p className="text-3xl font-bold mt-2">{totalReceived.toLocaleString()}</p>
                <p className="text-green-100 text-xs mt-2">4 دفعات مكتملة</p>
              </div>
              <CheckCircle className="w-12 h-12 opacity-50" />
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-yellow-500 to-yellow-600 text-white p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-yellow-100 text-sm">المبالغ المعلقة</p>
                <p className="text-3xl font-bold mt-2">{totalPending.toLocaleString()}</p>
                <p className="text-yellow-100 text-xs mt-2">1 دفعة معلقة</p>
              </div>
              <Clock className="w-12 h-12 opacity-50" />
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-red-500 to-red-600 text-white p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-red-100 text-sm">المبالغ الفاشلة</p>
                <p className="text-3xl font-bold mt-2">{totalFailed.toLocaleString()}</p>
                <p className="text-red-100 text-xs mt-2">1 دفعة فاشلة</p>
              </div>
              <AlertCircle className="w-12 h-12 opacity-50" />
            </div>
          </Card>

          <Card className="bg-gradient-to-br from-blue-500 to-blue-600 text-white p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-blue-100 text-sm">إجمالي الفواتير</p>
                <p className="text-3xl font-bold mt-2">{(totalReceived + totalPending + totalFailed).toLocaleString()}</p>
                <p className="text-blue-100 text-xs mt-2">6 فواتير</p>
              </div>
              <DollarSign className="w-12 h-12 opacity-50" />
            </div>
          </Card>
        </div>

        {/* جدول الدفعات */}
        <Card className="bg-white border-slate-200 p-6 mb-8">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold text-slate-900">سجل الدفعات</h2>
            <Button className="bg-blue-600 hover:bg-blue-700 text-white">
              <Download className="w-4 h-4 mr-2" />
              تحميل التقرير
            </Button>
          </div>

          <div className="overflow-x-auto">
            <table className="w-full">
              <thead>
                <tr className="border-b-2 border-slate-200">
                  <th className="text-right py-3 px-4 font-semibold text-slate-700">رقم الفاتورة</th>
                  <th className="text-right py-3 px-4 font-semibold text-slate-700">المبلغ</th>
                  <th className="text-right py-3 px-4 font-semibold text-slate-700">طريقة الدفع</th>
                  <th className="text-right py-3 px-4 font-semibold text-slate-700">الحالة</th>
                  <th className="text-right py-3 px-4 font-semibold text-slate-700">رقم المرجع</th>
                  <th className="text-right py-3 px-4 font-semibold text-slate-700">التاريخ</th>
                  <th className="text-right py-3 px-4 font-semibold text-slate-700">الإجراءات</th>
                </tr>
              </thead>
              <tbody>
                {payments.map((payment) => (
                  <tr key={payment.id} className="border-b border-slate-100 hover:bg-slate-50">
                    <td className="py-4 px-4 text-slate-900 font-medium">{payment.invoiceNumber}</td>
                    <td className="py-4 px-4 text-slate-900">{payment.amount.toLocaleString()} {payment.currency}</td>
                    <td className="py-4 px-4 text-slate-600">{payment.method}</td>
                    <td className="py-4 px-4">
                      <div className="flex items-center gap-2">
                        {getStatusIcon(payment.status)}
                        <span className={`px-3 py-1 rounded-full text-xs font-semibold border ${getStatusColor(payment.status)}`}>
                          {payment.status}
                        </span>
                      </div>
                    </td>
                    <td className="py-4 px-4 text-slate-600 text-sm">{payment.reference}</td>
                    <td className="py-4 px-4 text-slate-600">{payment.date}</td>
                    <td className="py-4 px-4">
                      <div className="flex gap-2">
                        <Button size="sm" variant="outline" className="text-xs">
                          عرض
                        </Button>
                        {payment.status === "فاشل" && (
                          <Button size="sm" className="bg-orange-600 hover:bg-orange-700 text-white text-xs">
                            إعادة محاولة
                          </Button>
                        )}
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </Card>

        {/* طرق الدفع المتاحة */}
        <Card className="bg-white border-slate-200 p-6">
          <h2 className="text-xl font-bold text-slate-900 mb-6">طرق الدفع المتاحة</h2>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="border-2 border-slate-200 rounded-lg p-4 hover:border-blue-500 cursor-pointer transition">
              <div className="flex items-center gap-3 mb-2">
                <CreditCard className="w-6 h-6 text-blue-600" />
                <h3 className="font-semibold text-slate-900">Stripe</h3>
              </div>
              <p className="text-sm text-slate-600">بطاقات ائتمان وتحويلات بنكية</p>
              <Button className="w-full mt-3 bg-blue-600 hover:bg-blue-700 text-white text-sm">تفعيل</Button>
            </div>

            <div className="border-2 border-slate-200 rounded-lg p-4 hover:border-blue-500 cursor-pointer transition">
              <div className="flex items-center gap-3 mb-2">
                <CreditCard className="w-6 h-6 text-blue-600" />
                <h3 className="font-semibold text-slate-900">PayPal</h3>
              </div>
              <p className="text-sm text-slate-600">محفظة رقمية وتحويلات دولية</p>
              <Button className="w-full mt-3 bg-blue-600 hover:bg-blue-700 text-white text-sm">تفعيل</Button>
            </div>

            <div className="border-2 border-slate-200 rounded-lg p-4 hover:border-blue-500 cursor-pointer transition">
              <div className="flex items-center gap-3 mb-2">
                <CreditCard className="w-6 h-6 text-blue-600" />
                <h3 className="font-semibold text-slate-900">التحويل البنكي</h3>
              </div>
              <p className="text-sm text-slate-600">تحويلات بنكية محلية ودولية</p>
              <Button className="w-full mt-3 bg-blue-600 hover:bg-blue-700 text-white text-sm">تفعيل</Button>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}
