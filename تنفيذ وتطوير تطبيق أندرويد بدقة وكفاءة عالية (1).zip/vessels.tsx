            }}
          >
            <Text style={{ color: "white", fontSize: 17, fontWeight: "700" }}>إضافة السفينة</Text>
          </TouchableOpacity>
        </ScrollView>
      </View>
    </Modal>
  );
}

export default function VesselsScreen() {
  const { vessels, deleteVessel, addVessel, currentUser } = useApp();
  const router = useRouter();
  const [search, setSearch] = useState("");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [showAddModal, setShowAddModal] = useState(false);

  const canEdit = currentUser?.role === "admin" || currentUser?.role === "accountant";

  const filtered = vessels.filter((v) => {
    const matchSearch = v.name.toLowerCase().includes(search.toLowerCase()) ||
      v.type.toLowerCase().includes(search.toLowerCase()) ||
      (v.owner || "").toLowerCase().includes(search.toLowerCase());
    const matchStatus = filterStatus === "all" || v.status === filterStatus;
    return matchSearch && matchStatus;
  });

  const handleDelete = (vessel: Vessel) => {
    Alert.alert(
      "حذف السفينة",
      `هل أنت متأكد من حذف السفينة "${vessel.name}"؟`,
      [
        { text: "إلغاء", style: "cancel" },
        { text: "حذف", style: "destructive", onPress: () => deleteVessel(vessel.id) },
      ]
    );
  };

  return (
    <ScreenContainer containerClassName="bg-background">
      {/* Header */}
      <View style={{
        backgroundColor: "#1E3A5F",
        paddingHorizontal: 20,
        paddingTop: 16,
        paddingBottom: 20,
      }}>
        <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
          <Text style={{ color: "white", fontSize: 22, fontWeight: "800" }}>إدارة السفن</Text>
          <View style={{ flexDirection: "row", gap: 8 }}>
            {canEdit && (
              <TouchableOpacity
                onPress={() => setShowAddModal(true)}
                style={{
                  backgroundColor: "#F5A623",
                  borderRadius: 10,
                  paddingHorizontal: 14,
                  paddingVertical: 8,
                  flexDirection: "row-reverse",
                  alignItems: "center",
                  gap: 4,
                }}
              >
                <MaterialIcons name="add" size={18} color="white" />
                <Text style={{ color: "white", fontSize: 13, fontWeight: "700" }}>إضافة</Text>
              </TouchableOpacity>
            )}
          </View>
        </View>

        {/* Search */}
        <View style={{
          backgroundColor: "rgba(255,255,255,0.15)",
          borderRadius: 12,
          flexDirection: "row-reverse",
          alignItems: "center",
          paddingHorizontal: 14,
          paddingVertical: 10,
          gap: 8,
        }}>
          <MaterialIcons name="search" size={20} color="rgba(255,255,255,0.7)" />
          <TextInput
            value={search}
            onChangeText={setSearch}
            placeholder="بحث عن سفينة..."
            placeholderTextColor="rgba(255,255,255,0.5)"
            style={{ flex: 1, color: "white", fontSize: 15, textAlign: "right" }}
          />
        </View>
      </View>

      {/* Filter Tabs */}
      <ScrollView
        horizontal
        showsHorizontalScrollIndicator={false}
        style={{ backgroundColor: "white", maxHeight: 52 }}
        contentContainerStyle={{ paddingHorizontal: 16, paddingVertical: 10, gap: 8, flexDirection: "row-reverse" }}
      >
        {[
          { key: "all", label: `الكل (${vessels.length})` },