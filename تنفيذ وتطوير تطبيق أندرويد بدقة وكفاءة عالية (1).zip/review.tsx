import { View, Text, ScrollView, TouchableOpacity, TextInput, Alert, Modal, FlatList } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useApp } from "@/lib/app-context";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useState, useMemo } from "react";
import { InvoiceReview, InvoiceReviewItem } from "@/lib/storage";

const STATUS_CONFIG = {
  pending: { label: "قيد المراجعة", color: "#F39C12", bg: "#FEF3C7" },
  completed: { label: "مكتملة", color: "#27AE60", bg: "#D1FAE5" },
  disputed: { label: "متنازع عليها", color: "#E74C3C", bg: "#FEE2E2" },
};

export default function ReviewScreen() {
  const router = useRouter();
  const { invoiceReviews, addInvoiceReview, updateInvoiceReview, deleteInvoiceReview, vessels, invoices, addArchive, currentUser, pricingTables } = useApp();
  const [showModal, setShowModal] = useState(false);
  const [editingReview, setEditingReview] = useState<InvoiceReview | null>(null);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedReview, setSelectedReview] = useState<InvoiceReview | null>(null);
  const [filterStatus, setFilterStatus] = useState<string>("all");

  // Form
  const [vesselId, setVesselId] = useState<number | null>(null);
  const [invoiceId, setInvoiceId] = useState<number | null>(null);
  const [externalRef, setExternalRef] = useState("");
  const [externalAmount, setExternalAmount] = useState("");
  const [calculatedAmount, setCalculatedAmount] = useState("");
  const [findings, setFindings] = useState("");
  const [recommendations, setRecommendations] = useState("");
  const [reviewItems, setReviewItems] = useState<InvoiceReviewItem[]>([]);
  const [showItemModal, setShowItemModal] = useState(false);
  const [itemName, setItemName] = useState("");
  const [itemExternal, setItemExternal] = useState("");
  const [itemCalculated, setItemCalculated] = useState("");
  const [itemNotes, setItemNotes] = useState("");

  const exchangeRate = pricingTables?.exchangeRate || 250;

  const filteredReviews = useMemo(() => {
    if (filterStatus === "all") return invoiceReviews;
    return invoiceReviews.filter((r) => r.status === filterStatus);
  }, [invoiceReviews, filterStatus]);

  const openAdd = () => {
    setEditingReview(null);
    setVesselId(null); setInvoiceId(null); setExternalRef(""); setExternalAmount(""); setCalculatedAmount(""); setFindings(""); setRecommendations(""); setReviewItems([]);
    setShowModal(true);
  };

  const openDetail = (review: InvoiceReview) => {
    setSelectedReview(review);
    setShowDetailModal(true);
  };

  const addReviewItem = () => {
    if (!itemName.trim() || !itemExternal || !itemCalculated) {
      Alert.alert("خطأ", "يرجى إدخال اسم البند والقيم");
      return;
    }
    const ext = parseFloat(itemExternal) || 0;
    const calc = parseFloat(itemCalculated) || 0;
    const newItem: InvoiceReviewItem = {
      itemName: itemName.trim(),
      externalValue: ext,
      calculatedValue: calc,
      difference: ext - calc,
      notes: itemNotes.trim() || undefined,
    };
    setReviewItems([...reviewItems, newItem]);
    setItemName(""); setItemExternal(""); setItemCalculated(""); setItemNotes("");
    setShowItemModal(false);
  };

  const removeReviewItem = (idx: number) => {
    setReviewItems(reviewItems.filter((_, i) => i !== idx));
  };

  const handleSave = async () => {
    if (!vesselId) {
      Alert.alert("خطأ", "يرجى اختيار السفينة");
      return;
    }
    const ext = parseFloat(externalAmount) || 0;
    const calc = parseFloat(calculatedAmount) || 0;
    const diff = ext - calc;
    const diffPct = calc > 0 ? (diff / calc) * 100 : 0;
    const vessel = vessels.find((v) => v.id === vesselId);

    const reviewNumber = `REV-${Date.now().toString().slice(-6)}`;
    await addInvoiceReview({
      reviewNumber,
      vesselId,
      vesselName: vessel?.name,
      invoiceId: invoiceId || undefined,
      externalInvoiceRef: externalRef.trim() || undefined,
      externalAmount: ext,
      calculatedAmount: calc,
      difference: diff,
      differencePercent: diffPct,
      status: "pending",
      reviewDate: new Date().toISOString(),
      reviewedBy: currentUser?.name,
      findings: findings.trim() || undefined,
      recommendations: recommendations.trim() || undefined,
      items: reviewItems,
    });

    // Auto-archive
    await addArchive({
      referenceType: "review",
      title: `مراجعة فاتورة: ${reviewNumber} - ${vessel?.name}`,
      description: `فرق: ${diff.toLocaleString("ar-SA")} USD (${diffPct.toFixed(1)}%)`,
      category: "مراجعات",
      vesselId,
      vesselName: vessel?.name,
      archivedBy: currentUser?.name || "النظام",
      tags: "مراجعة فاتورة",
    });

    setShowModal(false);
    Alert.alert("نجاح", "تم إنشاء تقرير المراجعة وأرشفته");
  };

  const handleDelete = (review: InvoiceReview) => {
    Alert.alert("تأكيد", `حذف المراجعة "${review.reviewNumber}"؟`, [
      { text: "إلغاء", style: "cancel" },
      { text: "حذف", style: "destructive", onPress: () => deleteInvoiceReview(review.id) },
    ]);
  };

  const handleStatusChange = async (review: InvoiceReview, status: InvoiceReview["status"]) => {
    await updateInvoiceReview(review.id, { status });
    if (selectedReview?.id === review.id) setSelectedReview({ ...review, status });
  };

  return (
    <ScreenContainer containerClassName="bg-background">
      {/* Header */}
      <View style={{ backgroundColor: "#1E3A5F", paddingHorizontal: 20, paddingTop: 16, paddingBottom: 20 }}>
        <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
          <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10 }}>
            <View style={{ width: 42, height: 42, borderRadius: 12, backgroundColor: "rgba(255,255,255,0.15)", alignItems: "center", justifyContent: "center" }}>
              <MaterialIcons name="rate-review" size={22} color="white" />
            </View>
            <View>
              <Text style={{ color: "white", fontSize: 18, fontWeight: "800" }}>مراجعة الفواتير الخارجية</Text>
              <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 12 }}>{invoiceReviews.length} مراجعة</Text>
            </View>
          </View>
          <View style={{ flexDirection: "row-reverse", gap: 8 }}>
            <TouchableOpacity onPress={openAdd} style={{ backgroundColor: "#27AE60", borderRadius: 10, paddingHorizontal: 14, paddingVertical: 8, flexDirection: "row-reverse", alignItems: "center", gap: 4 }}>
              <MaterialIcons name="add" size={16} color="white" />
              <Text style={{ color: "white", fontSize: 13, fontWeight: "700" }}>مراجعة جديدة</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => router.back()} style={{ width: 38, height: 38, borderRadius: 10, backgroundColor: "rgba(255,255,255,0.15)", alignItems: "center", justifyContent: "center" }}>
              <MaterialIcons name="arrow-forward" size={22} color="white" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Stats */}
        <View style={{ flexDirection: "row-reverse", gap: 10 }}>
          {[
            { label: "الكل", count: invoiceReviews.length, status: "all", color: "rgba(255,255,255,0.2)" },
            { label: "قيد المراجعة", count: invoiceReviews.filter((r) => r.status === "pending").length, status: "pending", color: "#F39C12" },
            { label: "مكتملة", count: invoiceReviews.filter((r) => r.status === "completed").length, status: "completed", color: "#27AE60" },
            { label: "متنازع", count: invoiceReviews.filter((r) => r.status === "disputed").length, status: "disputed", color: "#E74C3C" },
          ].map((stat) => (
            <TouchableOpacity
              key={stat.status}
              onPress={() => setFilterStatus(stat.status)}
              style={{ flex: 1, backgroundColor: filterStatus === stat.status ? stat.color : "rgba(255,255,255,0.1)", borderRadius: 10, padding: 8, alignItems: "center" }}
            >
              <Text style={{ color: "white", fontSize: 16, fontWeight: "800" }}>{stat.count}</Text>
              <Text style={{ color: "rgba(255,255,255,0.8)", fontSize: 10 }}>{stat.label}</Text>
            </TouchableOpacity>
          ))}
        </View>
      </View>

      <FlatList
        data={filteredReviews}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={{ padding: 16 }}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={{ alignItems: "center", paddingVertical: 60 }}>
            <MaterialIcons name="rate-review" size={64} color="#D1D5DB" />
            <Text style={{ fontSize: 16, color: "#9BA1A6", marginTop: 12 }}>لا توجد مراجعات بعد</Text>
          </View>
        }
        renderItem={({ item }) => {
          const statusCfg = STATUS_CONFIG[item.status];
          const diffColor = item.difference > 0 ? "#E74C3C" : item.difference < 0 ? "#27AE60" : "#6B7C93";
          return (
            <TouchableOpacity
              onPress={() => openDetail(item)}
              style={{ backgroundColor: "white", borderRadius: 16, padding: 16, marginBottom: 12, shadowColor: "#000", shadowOffset: { width: 0, height: 2 }, shadowOpacity: 0.06, shadowRadius: 6, elevation: 2 }}
            >
              <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "flex-start" }}>
                <View style={{ flex: 1 }}>
                  <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 8 }}>
                    <Text style={{ fontSize: 15, fontWeight: "800", color: "#1A2332" }}>{item.reviewNumber}</Text>
                    <View style={{ backgroundColor: statusCfg.bg, borderRadius: 8, paddingHorizontal: 8, paddingVertical: 3 }}>
                      <Text style={{ fontSize: 11, color: statusCfg.color, fontWeight: "700" }}>{statusCfg.label}</Text>
                    </View>
                  </View>
                  <Text style={{ fontSize: 13, color: "#6B7C93", marginTop: 4 }}>{item.vesselName}</Text>
                  {item.externalInvoiceRef && <Text style={{ fontSize: 12, color: "#9BA1A6" }}>مرجع: {item.externalInvoiceRef}</Text>}

                  <View style={{ flexDirection: "row-reverse", gap: 16, marginTop: 10 }}>
                    <View>
                      <Text style={{ fontSize: 10, color: "#9BA1A6" }}>الفاتورة الخارجية</Text>
                      <Text style={{ fontSize: 13, fontWeight: "700", color: "#1A2332" }}>{item.externalAmount.toLocaleString("ar-SA")} $</Text>
                    </View>
                    <View>
                      <Text style={{ fontSize: 10, color: "#9BA1A6" }}>المحسوب</Text>
                      <Text style={{ fontSize: 13, fontWeight: "700", color: "#1A2332" }}>{item.calculatedAmount.toLocaleString("ar-SA")} $</Text>
                    </View>
                    <View>
                      <Text style={{ fontSize: 10, color: "#9BA1A6" }}>الفرق</Text>
                      <Text style={{ fontSize: 13, fontWeight: "800", color: diffColor }}>
                        {item.difference > 0 ? "+" : ""}{item.difference.toLocaleString("ar-SA")} $
                      </Text>
                    </View>
                    {item.differencePercent !== undefined && (
                      <View>
                        <Text style={{ fontSize: 10, color: "#9BA1A6" }}>النسبة</Text>
                        <Text style={{ fontSize: 13, fontWeight: "700", color: diffColor }}>{item.differencePercent.toFixed(1)}%</Text>
                      </View>
                    )}
                  </View>
                </View>
                <TouchableOpacity onPress={() => handleDelete(item)} style={{ backgroundColor: "#FEE2E2", borderRadius: 8, padding: 8 }}>
                  <MaterialIcons name="delete-outline" size={16} color="#E74C3C" />
                </TouchableOpacity>
              </View>
              <View style={{ flexDirection: "row-reverse", gap: 8, marginTop: 12 }}>
                {(["pending", "completed", "disputed"] as const).map((s) => (
                  <TouchableOpacity
                    key={s}
                    onPress={() => handleStatusChange(item, s)}
                    style={{ flex: 1, paddingVertical: 6, borderRadius: 8, backgroundColor: item.status === s ? STATUS_CONFIG[s].color : "#F0F4F8", alignItems: "center" }}
                  >
                    <Text style={{ fontSize: 11, color: item.status === s ? "white" : "#6B7C93", fontWeight: item.status === s ? "700" : "400" }}>{STATUS_CONFIG[s].label}</Text>
                  </TouchableOpacity>
                ))}
              </View>
            </TouchableOpacity>
          );
        }}
      />

      {/* New Review Modal */}
      <Modal visible={showModal} transparent animationType="slide">
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}>
          <View style={{ backgroundColor: "white", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, maxHeight: "92%" }}>
            <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <Text style={{ fontSize: 18, fontWeight: "800", color: "#1A2332" }}>مراجعة فاتورة خارجية</Text>
              <TouchableOpacity onPress={() => setShowModal(false)}>
                <MaterialIcons name="close" size={24} color="#6B7C93" />
              </TouchableOpacity>
            </View>
            <ScrollView showsVerticalScrollIndicator={false}>
              {/* Vessel */}
              <Text style={{ fontSize: 13, color: "#6B7C93", textAlign: "right", marginBottom: 8 }}>السفينة *</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 14 }}>
                <View style={{ flexDirection: "row-reverse", gap: 8 }}>
                  {vessels.map((v) => (
                    <TouchableOpacity key={v.id} onPress={() => setVesselId(v.id)} style={{ paddingHorizontal: 12, paddingVertical: 8, borderRadius: 10, backgroundColor: vesselId === v.id ? "#1E3A5F" : "#F0F4F8" }}>
                      <Text style={{ fontSize: 12, color: vesselId === v.id ? "white" : "#6B7C93" }}>{v.name}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </ScrollView>

              {[
                { label: "رقم الفاتورة الخارجية", value: externalRef, setter: setExternalRef, placeholder: "INV-2026-001" },
                { label: "مبلغ الفاتورة الخارجية (USD)", value: externalAmount, setter: setExternalAmount, placeholder: "0.00", numeric: true },
                { label: "المبلغ المحسوب (USD)", value: calculatedAmount, setter: setCalculatedAmount, placeholder: "0.00", numeric: true },
              ].map((field, idx) => (
                <View key={idx} style={{ marginBottom: 12 }}>
                  <Text style={{ fontSize: 13, color: "#6B7C93", textAlign: "right", marginBottom: 6 }}>{field.label}</Text>
                  <TextInput
                    value={field.value}
                    onChangeText={field.setter}
                    placeholder={field.placeholder}
                    keyboardType={field.numeric ? "numeric" : "default"}
                    style={{ backgroundColor: "#F8FAFC", borderRadius: 10, padding: 12, fontSize: 14, textAlign: "right", borderWidth: 1, borderColor: "#E5E7EB" }}
                  />
                </View>
              ))}

              {/* Difference Preview */}
              {externalAmount && calculatedAmount && (
                <View style={{ backgroundColor: "#F8FAFC", borderRadius: 12, padding: 14, marginBottom: 14 }}>
                  <Text style={{ fontSize: 13, fontWeight: "700", color: "#1A2332", textAlign: "right", marginBottom: 8 }}>ملخص الفروقات</Text>
                  {[
                    { label: "الفاتورة الخارجية", value: parseFloat(externalAmount) || 0, color: "#1A2332" },
                    { label: "المبلغ المحسوب", value: parseFloat(calculatedAmount) || 0, color: "#1A2332" },
                    { label: "الفرق", value: (parseFloat(externalAmount) || 0) - (parseFloat(calculatedAmount) || 0), color: (parseFloat(externalAmount) || 0) > (parseFloat(calculatedAmount) || 0) ? "#E74C3C" : "#27AE60" },
                  ].map((row, idx) => (
                    <View key={idx} style={{ flexDirection: "row-reverse", justifyContent: "space-between", paddingVertical: 4 }}>
                      <Text style={{ fontSize: 13, color: "#6B7C93" }}>{row.label}</Text>
                      <Text style={{ fontSize: 13, fontWeight: "700", color: row.color }}>{row.value.toLocaleString("ar-SA")} $</Text>
                    </View>
                  ))}
                  <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", paddingVertical: 4 }}>
                    <Text style={{ fontSize: 13, color: "#6B7C93" }}>بالريال اليمني</Text>
                    <Text style={{ fontSize: 13, fontWeight: "700", color: "#1A2332" }}>
                      {(((parseFloat(externalAmount) || 0) - (parseFloat(calculatedAmount) || 0)) * exchangeRate).toLocaleString("ar-SA")} ر.ي
                    </Text>
                  </View>
                </View>
              )}

              {/* Review Items */}
              <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 8 }}>
                <Text style={{ fontSize: 13, color: "#6B7C93" }}>بنود المراجعة التفصيلية</Text>
                <TouchableOpacity onPress={() => setShowItemModal(true)} style={{ backgroundColor: "#EBF4FF", borderRadius: 8, paddingHorizontal: 10, paddingVertical: 6, flexDirection: "row-reverse", alignItems: "center", gap: 4 }}>
                  <MaterialIcons name="add" size={14} color="#1E3A5F" />
                  <Text style={{ fontSize: 12, color: "#1E3A5F", fontWeight: "700" }}>إضافة بند</Text>
                </TouchableOpacity>
              </View>
              {reviewItems.map((item, idx) => (
                <View key={idx} style={{ backgroundColor: "#F8FAFC", borderRadius: 10, padding: 10, marginBottom: 6, flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center" }}>
                  <View style={{ flex: 1 }}>
                    <Text style={{ fontSize: 13, fontWeight: "600", color: "#1A2332", textAlign: "right" }}>{item.itemName}</Text>
                    <View style={{ flexDirection: "row-reverse", gap: 12, marginTop: 4 }}>
                      <Text style={{ fontSize: 11, color: "#9BA1A6" }}>خارجي: {item.externalValue}</Text>
                      <Text style={{ fontSize: 11, color: "#9BA1A6" }}>محسوب: {item.calculatedValue}</Text>
                      <Text style={{ fontSize: 11, color: item.difference !== 0 ? "#E74C3C" : "#27AE60", fontWeight: "700" }}>فرق: {item.difference}</Text>
                    </View>
                  </View>
                  <TouchableOpacity onPress={() => removeReviewItem(idx)} style={{ backgroundColor: "#FEE2E2", borderRadius: 6, padding: 6 }}>
                    <MaterialIcons name="close" size={14} color="#E74C3C" />
                  </TouchableOpacity>
                </View>
              ))}

              {/* Findings */}
              {[
                { label: "الملاحظات والنتائج", value: findings, setter: setFindings, placeholder: "اكتب ملاحظات المراجعة..." },
                { label: "التوصيات", value: recommendations, setter: setRecommendations, placeholder: "اكتب التوصيات..." },
              ].map((field, idx) => (
                <View key={idx} style={{ marginBottom: 12 }}>
                  <Text style={{ fontSize: 13, color: "#6B7C93", textAlign: "right", marginBottom: 6 }}>{field.label}</Text>
                  <TextInput
                    value={field.value}
                    onChangeText={field.setter}
                    placeholder={field.placeholder}
                    multiline
                    numberOfLines={3}
                    textAlignVertical="top"
                    style={{ backgroundColor: "#F8FAFC", borderRadius: 10, padding: 12, fontSize: 13, textAlign: "right", borderWidth: 1, borderColor: "#E5E7EB", minHeight: 80 }}
                  />
                </View>
              ))}

              <TouchableOpacity onPress={handleSave} style={{ backgroundColor: "#1E3A5F", borderRadius: 14, paddingVertical: 16, alignItems: "center", marginTop: 8 }}>
                <Text style={{ color: "white", fontSize: 15, fontWeight: "700" }}>إنشاء تقرير المراجعة</Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Add Item Modal */}
      <Modal visible={showItemModal} transparent animationType="fade">
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "center", padding: 20 }}>
          <View style={{ backgroundColor: "white", borderRadius: 20, padding: 20 }}>
            <Text style={{ fontSize: 16, fontWeight: "800", color: "#1A2332", textAlign: "right", marginBottom: 14 }}>إضافة بند مراجعة</Text>
            {[
              { label: "اسم البند", value: itemName, setter: setItemName, placeholder: "رسوم الإرشاد" },
              { label: "القيمة الخارجية", value: itemExternal, setter: setItemExternal, placeholder: "0.00", numeric: true },
              { label: "القيمة المحسوبة", value: itemCalculated, setter: setItemCalculated, placeholder: "0.00", numeric: true },
              { label: "ملاحظات", value: itemNotes, setter: setItemNotes, placeholder: "اختياري" },
            ].map((field, idx) => (
              <View key={idx} style={{ marginBottom: 10 }}>
                <Text style={{ fontSize: 12, color: "#6B7C93", textAlign: "right", marginBottom: 4 }}>{field.label}</Text>
                <TextInput
                  value={field.value}
                  onChangeText={field.setter}
                  placeholder={field.placeholder}
                  keyboardType={field.numeric ? "numeric" : "default"}
                  style={{ backgroundColor: "#F8FAFC", borderRadius: 10, padding: 10, fontSize: 13, textAlign: "right", borderWidth: 1, borderColor: "#E5E7EB" }}
                />
              </View>
            ))}
            <View style={{ flexDirection: "row-reverse", gap: 10, marginTop: 8 }}>
              <TouchableOpacity onPress={addReviewItem} style={{ flex: 1, backgroundColor: "#1E3A5F", borderRadius: 12, paddingVertical: 12, alignItems: "center" }}>
                <Text style={{ color: "white", fontWeight: "700" }}>إضافة</Text>
              </TouchableOpacity>
              <TouchableOpacity onPress={() => setShowItemModal(false)} style={{ flex: 1, backgroundColor: "#F0F4F8", borderRadius: 12, paddingVertical: 12, alignItems: "center" }}>
                <Text style={{ color: "#6B7C93" }}>إلغاء</Text>
              </TouchableOpacity>
            </View>
          </View>
        </View>
      </Modal>

      {/* Detail Modal */}
      <Modal visible={showDetailModal} transparent animationType="slide">
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}>
          <View style={{ backgroundColor: "white", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, maxHeight: "85%" }}>
            <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 16 }}>
              <Text style={{ fontSize: 16, fontWeight: "800", color: "#1A2332" }}>{selectedReview?.reviewNumber}</Text>
              <TouchableOpacity onPress={() => setShowDetailModal(false)}>
                <MaterialIcons name="close" size={24} color="#6B7C93" />
              </TouchableOpacity>
            </View>
            {selectedReview && (
              <ScrollView showsVerticalScrollIndicator={false}>
                {[
                  { label: "السفينة", value: selectedReview.vesselName || "-" },
                  { label: "المرجع الخارجي", value: selectedReview.externalInvoiceRef || "-" },
                  { label: "الفاتورة الخارجية", value: `${selectedReview.externalAmount.toLocaleString("ar-SA")} USD` },
                  { label: "المبلغ المحسوب", value: `${selectedReview.calculatedAmount.toLocaleString("ar-SA")} USD` },
                  { label: "الفرق", value: `${selectedReview.difference > 0 ? "+" : ""}${selectedReview.difference.toLocaleString("ar-SA")} USD` },
                  { label: "نسبة الفرق", value: `${selectedReview.differencePercent?.toFixed(2) || 0}%` },
                  { label: "بالريال اليمني", value: `${(selectedReview.difference * exchangeRate).toLocaleString("ar-SA")} ر.ي` },
                  { label: "المراجع", value: selectedReview.reviewedBy || "-" },
                  { label: "تاريخ المراجعة", value: new Date(selectedReview.reviewDate).toLocaleDateString("ar-SA") },
                  { label: "الملاحظات", value: selectedReview.findings || "-" },
                  { label: "التوصيات", value: selectedReview.recommendations || "-" },
                ].map((row, idx) => (
                  <View key={idx} style={{ flexDirection: "row-reverse", justifyContent: "space-between", paddingVertical: 8, borderBottomWidth: 1, borderBottomColor: "#F0F4F8" }}>
                    <Text style={{ fontSize: 13, color: "#6B7C93" }}>{row.label}</Text>
                    <Text style={{ fontSize: 13, color: "#1A2332", fontWeight: "600", flex: 1, textAlign: "right", marginRight: 12 }}>{row.value}</Text>
                  </View>
                ))}

                {selectedReview.items.length > 0 && (
                  <View style={{ marginTop: 16 }}>
                    <Text style={{ fontSize: 14, fontWeight: "700", color: "#1A2332", textAlign: "right", marginBottom: 8 }}>بنود المراجعة التفصيلية</Text>
                    {selectedReview.items.map((item, idx) => (
                      <View key={idx} style={{ backgroundColor: "#F8FAFC", borderRadius: 10, padding: 10, marginBottom: 6 }}>
                        <Text style={{ fontSize: 13, fontWeight: "600", color: "#1A2332", textAlign: "right" }}>{item.itemName}</Text>
                        <View style={{ flexDirection: "row-reverse", gap: 16, marginTop: 4 }}>
                          <Text style={{ fontSize: 12, color: "#6B7C93" }}>خارجي: {item.externalValue}</Text>
                          <Text style={{ fontSize: 12, color: "#6B7C93" }}>محسوب: {item.calculatedValue}</Text>
                          <Text style={{ fontSize: 12, fontWeight: "700", color: item.difference !== 0 ? "#E74C3C" : "#27AE60" }}>فرق: {item.difference}</Text>
                        </View>
                      </View>
                    ))}
                  </View>
                )}
              </ScrollView>
            )}
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}
