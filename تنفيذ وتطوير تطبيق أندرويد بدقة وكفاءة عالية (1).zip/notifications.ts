import * as Notifications from "expo-notifications";
import { Platform } from "react-native";
import type { Invoice } from "./storage";

// ─── إعداد معالج الإشعارات ────────────────────────────────────────────────────
Notifications.setNotificationHandler({
  handleNotification: async () => ({
    shouldShowAlert: true,
    shouldPlaySound: true,
    shouldSetBadge: true,
    shouldShowBanner: true,
    shouldShowList: true,
  }),
});

// ─── طلب صلاحيات الإشعارات ────────────────────────────────────────────────────
export async function requestNotificationPermissions(): Promise<boolean> {
  try {
    if (Platform.OS === "android") {
      await Notifications.setNotificationChannelAsync("habib-invoices", {
        name: "فواتير نظام حبيب",
        importance: Notifications.AndroidImportance.HIGH,
        vibrationPattern: [0, 250, 250, 250],
        lightColor: "#1E3A5F",
        description: "إشعارات الفواتير المتأخرة والمستحقة",
      });
      await Notifications.setNotificationChannelAsync("habib-reminders", {
        name: "تذكيرات نظام حبيب",
        importance: Notifications.AndroidImportance.DEFAULT,
        description: "تذكيرات عامة للنظام",
      });
    }

    const { status: existingStatus } = await Notifications.getPermissionsAsync();
    let finalStatus = existingStatus;

    if (existingStatus !== "granted") {
      const { status } = await Notifications.requestPermissionsAsync();
      finalStatus = status;
    }

    return finalStatus === "granted";
  } catch (error) {
    console.error("خطأ في طلب صلاحيات الإشعارات:", error);
    return false;
  }
}

// ─── جدولة إشعار فاتورة متأخرة ───────────────────────────────────────────────
export async function scheduleOverdueInvoiceNotification(invoice: Invoice): Promise<string | null> {
  try {
    const id = await Notifications.scheduleNotificationAsync({
      content: {
        title: "⚠️ فاتورة متأخرة - نظام حبيب",
        body: `الفاتورة ${invoice.invoiceNumber} للسفينة ${invoice.vesselName || "غير محدد"} متأخرة بمبلغ $${invoice.amount.toLocaleString()}`,
        data: { invoiceId: invoice.id, type: "overdue" },
        sound: true,
        badge: 1,
        categoryIdentifier: "habib-invoices",
      },
      trigger: null, // فوري
    });
    return id;
  } catch (error) {
    console.error("خطأ في جدولة إشعار الفاتورة المتأخرة:", error);
    return null;
  }
}

// ─── جدولة إشعار قبل الاستحقاق ───────────────────────────────────────────────
export async function scheduleDueSoonNotification(
  invoice: Invoice,
  daysBeforeDue: number = 3
): Promise<string | null> {
  try {
    if (!invoice.dueDate) return null;

    const dueDate = new Date(invoice.dueDate);
    const notifyDate = new Date(dueDate);
    notifyDate.setDate(notifyDate.getDate() - daysBeforeDue);
    notifyDate.setHours(9, 0, 0, 0); // الساعة 9 صباحاً

    // إذا كان الوقت قد مضى، لا نجدول
    if (notifyDate <= new Date()) return null;

    const id = await Notifications.scheduleNotificationAsync({
      content: {
        title: `🔔 فاتورة تستحق خلال ${daysBeforeDue} أيام`,
        body: `الفاتورة ${invoice.invoiceNumber} للسفينة ${invoice.vesselName || "غير محدد"} تستحق في ${dueDate.toLocaleDateString("ar-YE")} بمبلغ $${invoice.amount.toLocaleString()}`,
        data: { invoiceId: invoice.id, type: "due_soon" },
        sound: true,
        categoryIdentifier: "habib-invoices",
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.DATE,
        date: notifyDate,
      },
    });
    return id;
  } catch (error) {
    console.error("خطأ في جدولة إشعار الاستحقاق القريب:", error);
    return null;
  }
}

// ─── إشعار عند الموافقة على الفاتورة ─────────────────────────────────────────
export async function notifyInvoiceApproved(invoice: Invoice): Promise<void> {
  try {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: "✅ تمت الموافقة على الفاتورة",
        body: `تمت الموافقة على الفاتورة ${invoice.invoiceNumber} بمبلغ $${invoice.amount.toLocaleString()}`,
        data: { invoiceId: invoice.id, type: "approved" },
        sound: true,
        categoryIdentifier: "habib-invoices",
      },
      trigger: null,
    });
  } catch (error) {
    console.error("خطأ في إشعار الموافقة:", error);
  }
}

// ─── إشعار عند رفض الفاتورة ──────────────────────────────────────────────────
export async function notifyInvoiceRejected(invoice: Invoice, reason?: string): Promise<void> {
  try {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: "❌ تم رفض الفاتورة",
        body: `تم رفض الفاتورة ${invoice.invoiceNumber}${reason ? `: ${reason}` : ""}`,
        data: { invoiceId: invoice.id, type: "rejected" },
        sound: true,
        categoryIdentifier: "habib-invoices",
      },
      trigger: null,
    });
  } catch (error) {
    console.error("خطأ في إشعار الرفض:", error);
  }
}

// ─── إشعار عند الدفع ─────────────────────────────────────────────────────────
export async function notifyInvoicePaid(invoice: Invoice): Promise<void> {
  try {
    await Notifications.scheduleNotificationAsync({
      content: {
        title: "💰 تم استلام الدفع",
        body: `تم دفع الفاتورة ${invoice.invoiceNumber} بمبلغ $${invoice.amount.toLocaleString()} بنجاح`,
        data: { invoiceId: invoice.id, type: "paid" },
        sound: true,
        categoryIdentifier: "habib-invoices",
      },
      trigger: null,
    });
  } catch (error) {
    console.error("خطأ في إشعار الدفع:", error);
  }
}

// ─── فحص الفواتير المتأخرة وإرسال إشعارات ────────────────────────────────────
export async function checkAndNotifyOverdueInvoices(invoices: Invoice[]): Promise<number> {
  let count = 0;
  const now = new Date();
  now.setHours(0, 0, 0, 0);

  for (const invoice of invoices) {
    if (invoice.status === "overdue" || 
        (invoice.status === "pending" && invoice.dueDate && new Date(invoice.dueDate) < now)) {
      await scheduleOverdueInvoiceNotification(invoice);
      count++;
    }
  }

  return count;
}

// ─── جدولة فحص يومي للفواتير ─────────────────────────────────────────────────
export async function scheduleDailyInvoiceCheck(): Promise<string | null> {
  try {
    // إلغاء الجدولة السابقة
    await Notifications.cancelAllScheduledNotificationsAsync();

    const id = await Notifications.scheduleNotificationAsync({
      content: {
        title: "📊 تذكير يومي - نظام حبيب",
        body: "افتح التطبيق للاطلاع على حالة الفواتير والمستحقات",
        data: { type: "daily_reminder" },
        sound: false,
        categoryIdentifier: "habib-reminders",
      },
      trigger: {
        type: Notifications.SchedulableTriggerInputTypes.DAILY,
        hour: 8,
        minute: 0,
      },
    });
    return id;
  } catch (error) {
    console.error("خطأ في جدولة الفحص اليومي:", error);
    return null;
  }
}

// ─── إلغاء جميع الإشعارات المجدولة ──────────────────────────────────────────
export async function cancelAllNotifications(): Promise<void> {
  await Notifications.cancelAllScheduledNotificationsAsync();
}

// ─── الحصول على عدد الإشعارات المجدولة ──────────────────────────────────────
export async function getScheduledNotificationsCount(): Promise<number> {
  const scheduled = await Notifications.getAllScheduledNotificationsAsync();
  return scheduled.length;
}

// ─── إعداد مستمع الإشعارات ───────────────────────────────────────────────────
export function setupNotificationListeners(
  onNotificationReceived: (notification: Notifications.Notification) => void,
  onNotificationResponse: (response: Notifications.NotificationResponse) => void
) {
  const receivedSub = Notifications.addNotificationReceivedListener(onNotificationReceived);
  const responseSub = Notifications.addNotificationResponseReceivedListener(onNotificationResponse);

  return () => {
    receivedSub.remove();
    responseSub.remove();
  };
}
