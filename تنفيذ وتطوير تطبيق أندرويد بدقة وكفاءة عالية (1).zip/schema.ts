import { decimal, int, mysqlEnum, mysqlTable, text, timestamp, varchar, boolean, longtext, index } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extended with role-based access control for vessel management system.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["admin", "accountant", "reviewer", "user"]).default("user").notNull(),
  accessStatus: mysqlEnum("accessStatus", ["pending", "approved", "rejected"]).default("pending").notNull(),
  isActive: boolean("isActive").default(true).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
}, (table) => ({
  emailIdx: index("email_idx").on(table.email),
  roleIdx: index("role_idx").on(table.role),
}));

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

// Vessels table
export const vessels = mysqlTable("vessels", {
  id: int("id").autoincrement().primaryKey(),
  name: varchar("name", { length: 255 }).notNull(),
  type: varchar("type", { length: 100 }).notNull(),
  imoNumber: varchar("imoNumber", { length: 50 }).unique(),
  callSign: varchar("callSign", { length: 50 }),
  capacity: decimal("capacity", { precision: 12, scale: 2 }),
  flag: varchar("flag", { length: 100 }),
  owner: varchar("owner", { length: 255 }),
  arrivalDate: timestamp("arrivalDate"),
  departureDate: timestamp("departureDate"),
  status: mysqlEnum("status", ["active", "inactive", "maintenance", "docked"]).default("active").notNull(),
  notes: longtext("notes"),
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  statusIdx: index("status_idx").on(table.status),
  createdByIdx: index("createdBy_idx").on(table.createdBy),
}));

export type Vessel = typeof vessels.$inferSelect;
export type InsertVessel = typeof vessels.$inferInsert;

// Invoices table
export const invoices = mysqlTable("invoices", {
  id: int("id").autoincrement().primaryKey(),
  invoiceNumber: varchar("invoiceNumber", { length: 100 }).notNull().unique(),
  vesselId: int("vesselId").notNull(),
  amount: decimal("amount", { precision: 15, scale: 2 }).notNull(),
  currency: varchar("currency", { length: 3 }).default("USD").notNull(),
  description: longtext("description"),
  calculationBasis: longtext("calculationBasis"),
  status: mysqlEnum("status", ["draft", "pending", "approved", "rejected", "paid"]).default("draft").notNull(),
  issuedDate: timestamp("issuedDate").defaultNow().notNull(),
  dueDate: timestamp("dueDate"),
  paidDate: timestamp("paidDate"),
  createdBy: int("createdBy").notNull(),
  approvedBy: int("approvedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  vesselIdx: index("vesselId_idx").on(table.vesselId),
  statusIdx: index("status_idx").on(table.status),
  invoiceNumberIdx: index("invoiceNumber_idx").on(table.invoiceNumber),
}));

export type Invoice = typeof invoices.$inferSelect;
export type InsertInvoice = typeof invoices.$inferInsert;

// Invoice attachments
export const invoiceAttachments = mysqlTable("invoiceAttachments", {
  id: int("id").autoincrement().primaryKey(),
  invoiceId: int("invoiceId").notNull(),
  fileName: varchar("fileName", { length: 255 }).notNull(),
  fileKey: varchar("fileKey", { length: 500 }).notNull(),
  fileUrl: varchar("fileUrl", { length: 1000 }).notNull(),
  fileType: varchar("fileType", { length: 50 }),
  fileSize: int("fileSize"),
  uploadedBy: int("uploadedBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  invoiceIdx: index("invoiceId_idx").on(table.invoiceId),
}));

export type InvoiceAttachment = typeof invoiceAttachments.$inferSelect;
export type InsertInvoiceAttachment = typeof invoiceAttachments.$inferInsert;

// Memos table
export const memos = mysqlTable("memos", {
  id: int("id").autoincrement().primaryKey(),
  vesselId: int("vesselId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  content: longtext("content").notNull(),
  recipientEntity: varchar("recipientEntity", { length: 255 }),
  memoType: mysqlEnum("memoType", ["communication", "complaint", "inquiry", "notification"]).default("communication").notNull(),
  status: mysqlEnum("status", ["draft", "sent", "archived"]).default("draft").notNull(),
  sentDate: timestamp("sentDate"),
  createdBy: int("createdBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
}, (table) => ({
  vesselIdx: index("vesselId_idx").on(table.vesselId),
  statusIdx: index("status_idx").on(table.status),
}));

export type Memo = typeof memos.$inferSelect;
export type InsertMemo = typeof memos.$inferInsert;

// Archive table
export const archives = mysqlTable("archives", {
  id: int("id").autoincrement().primaryKey(),
  referenceType: mysqlEnum("referenceType", ["invoice", "memo", "vessel", "document"]).notNull(),
  referenceId: int("referenceId").notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  description: longtext("description"),
  fileKey: varchar("fileKey", { length: 500 }),
  fileUrl: varchar("fileUrl", { length: 1000 }),
  tags: varchar("tags", { length: 500 }),
  archivedBy: int("archivedBy").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  referenceIdx: index("reference_idx").on(table.referenceType, table.referenceId),
  tagsIdx: index("tags_idx").on(table.tags),
}));

export type Archive = typeof archives.$inferSelect;
export type InsertArchive = typeof archives.$inferInsert;

// Audit log table
export const auditLogs = mysqlTable("auditLogs", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  action: varchar("action", { length: 100 }).notNull(),
  entityType: varchar("entityType", { length: 50 }).notNull(),
  entityId: int("entityId"),
  changes: longtext("changes"),
  ipAddress: varchar("ipAddress", { length: 50 }),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userIdx: index("userId_idx").on(table.userId),
  entityIdx: index("entity_idx").on(table.entityType, table.entityId),
  createdAtIdx: index("createdAt_idx").on(table.createdAt),
}));

export type AuditLog = typeof auditLogs.$inferSelect;
export type InsertAuditLog = typeof auditLogs.$inferInsert;

// Access requests table
export const accessRequests = mysqlTable("accessRequests", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull(),
  requestedRole: mysqlEnum("requestedRole", ["admin", "accountant", "reviewer", "user"]).notNull(),
  reason: longtext("reason"),
  status: mysqlEnum("status", ["pending", "approved", "rejected"]).default("pending").notNull(),
  reviewedBy: int("reviewedBy"),
  reviewDate: timestamp("reviewDate"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
}, (table) => ({
  userIdx: index("userId_idx").on(table.userId),
  statusIdx: index("status_idx").on(table.status),
}));

export type AccessRequest = typeof accessRequests.$inferSelect;
export type InsertAccessRequest = typeof accessRequests.$inferInsert;