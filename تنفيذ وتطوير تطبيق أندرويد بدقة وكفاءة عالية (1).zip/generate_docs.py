#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
سكريبت إنشاء وثيقة نظام حبيب لإدارة السفن والفواتير
"""

from docx import Document
from docx.shared import Pt, RGBColor, Inches, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.oxml.ns import qn
from docx.oxml import OxmlElement
import os
import datetime

def set_rtl(paragraph):
    """تعيين اتجاه النص من اليمين إلى اليسار"""
    pPr = paragraph._p.get_or_add_pPr()
    bidi = OxmlElement('w:bidi')
    pPr.append(bidi)
    paragraph.alignment = WD_ALIGN_PARAGRAPH.RIGHT

def add_heading(doc, text, level=1, color=None):
    """إضافة عنوان مع دعم RTL"""
    heading = doc.add_heading(text, level=level)
    set_rtl(heading)
    if color:
        for run in heading.runs:
            run.font.color.rgb = RGBColor(*color)
    return heading

def add_paragraph(doc, text, bold=False, color=None, size=None):
    """إضافة فقرة مع دعم RTL"""
    para = doc.add_paragraph()
    set_rtl(para)
    run = para.add_run(text)
    run.bold = bold
    if color:
        run.font.color.rgb = RGBColor(*color)
    if size:
        run.font.size = Pt(size)
    return para

def add_table_row(table, cells_data, header=False):
    """إضافة صف في جدول"""
    row = table.add_row()
    for i, (cell_text, cell) in enumerate(zip(cells_data, row.cells)):
        cell.text = cell_text
        para = cell.paragraphs[0]
        para.alignment = WD_ALIGN_PARAGRAPH.RIGHT
        if header:
            for run in para.runs:
                run.bold = True
                run.font.color.rgb = RGBColor(255, 255, 255)
            cell._tc.get_or_add_tcPr()
            shd = OxmlElement('w:shd')
            shd.set(qn('w:fill'), '1E3A5F')
            shd.set(qn('w:color'), 'auto')
            shd.set(qn('w:val'), 'clear')
            cell._tc.tcPr.append(shd)

def read_file_content(filepath):
    """قراءة محتوى ملف"""
    try:
        with open(filepath, 'r', encoding='utf-8') as f:
            return f.read()
    except:
        return "// ملف غير متاح"

# إنشاء المستند
doc = Document()

# إعداد الصفحة
section = doc.sections[0]
section.page_width = Cm(21)
section.page_height = Cm(29.7)
section.left_margin = Cm(2.5)
section.right_margin = Cm(2.5)
section.top_margin = Cm(2.5)
section.bottom_margin = Cm(2.5)

# ═══════════════════════════════════════════════════════════════
# صفحة الغلاف
# ═══════════════════════════════════════════════════════════════
title = doc.add_paragraph()
title.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = title.add_run("\n\n\n")
run = title.add_run("نظام حبيب")
run.bold = True
run.font.size = Pt(36)
run.font.color.rgb = RGBColor(30, 58, 95)

subtitle = doc.add_paragraph()
subtitle.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = subtitle.add_run("لإدارة السفن والفواتير")
run.bold = True
run.font.size = Pt(24)
run.font.color.rgb = RGBColor(30, 58, 95)

doc.add_paragraph()
doc.add_paragraph()

info_para = doc.add_paragraph()
info_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = info_para.add_run("وثيقة تقنية شاملة\nتفاصيل التطبيق والأكواد البرمجية")
run.font.size = Pt(14)
run.font.color.rgb = RGBColor(107, 124, 147)

doc.add_paragraph()
doc.add_paragraph()

date_para = doc.add_paragraph()
date_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = date_para.add_run(f"الإصدار: 2.0.0\nتاريخ الإصدار: {datetime.date.today().strftime('%Y/%m/%d')}")
run.font.size = Pt(12)
run.font.color.rgb = RGBColor(107, 124, 147)

doc.add_paragraph()
doc.add_paragraph()

dev_para = doc.add_paragraph()
dev_para.alignment = WD_ALIGN_PARAGRAPH.CENTER
run = dev_para.add_run("المطوّر: حبيب")
run.bold = True
run.font.size = Pt(16)
run.font.color.rgb = RGBColor(30, 58, 95)

doc.add_page_break()

# ═══════════════════════════════════════════════════════════════
# فهرس المحتويات
# ═══════════════════════════════════════════════════════════════
add_heading(doc, "فهرس المحتويات", 1, (30, 58, 95))

toc_items = [
    ("1", "نظرة عامة على النظام", "3"),
    ("2", "المتطلبات التقنية", "4"),
    ("3", "هيكل المشروع", "5"),
    ("4", "نظام الصلاحيات والأمان", "6"),
    ("5", "قاعدة البيانات والأنواع", "8"),
    ("6", "الشاشات والواجهات", "12"),
    ("7", "نظام الأسعار والرسوم", "18"),
    ("8", "نظام المذكرات والمخاطبات", "20"),
    ("9", "الأرشيف الشامل", "22"),
    ("10", "مرفقات الفواتير", "24"),
    ("11", "مراجعة الفواتير الخارجية", "26"),
    ("12", "الأكواد البرمجية الرئيسية", "28"),
    ("13", "جداول الأسعار من ملف Excel", "45"),
    ("14", "دليل التثبيت والتشغيل", "50"),
    ("15", "بيانات الدخول التجريبية", "52"),
]

toc_table = doc.add_table(rows=1, cols=3)
toc_table.alignment = WD_TABLE_ALIGNMENT.CENTER
add_table_row(toc_table, ["الصفحة", "العنوان", "رقم"], header=True)
for num, title_text, page in toc_items:
    row = toc_table.add_row()
    for i, text in enumerate([page, title_text, num]):
        row.cells[i].text = text
        row.cells[i].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT

doc.add_page_break()

# ═══════════════════════════════════════════════════════════════
# الفصل الأول: نظرة عامة
# ═══════════════════════════════════════════════════════════════
add_heading(doc, "الفصل الأول: نظرة عامة على النظام", 1, (30, 58, 95))

add_paragraph(doc, "1.1 وصف النظام", bold=True, size=14)
add_paragraph(doc, """نظام حبيب لإدارة السفن والفواتير هو تطبيق جوال متكامل مبني بتقنية React Native (Expo SDK 54) يعمل على نظام Android وiOS. يوفر النظام حلاً شاملاً لإدارة عمليات الموانئ والسفن، بما في ذلك إصدار الفواتير، وتتبع المدفوعات، وإدارة المذكرات الرسمية، والأرشفة الإلكترونية.""")

add_paragraph(doc, "1.2 الميزات الرئيسية", bold=True, size=14)
features = [
    "إدارة شاملة للسفن مع تتبع الحالة والبيانات التفصيلية",
    "نظام فواتير متكامل مع سير عمل (مسودة → معلق → موافق → مدفوع)",
    "نظام أسعار ورسوم مبني على جداول حقيقية (إرشاد، قطر، رسوم ميناء)",
    "حاسبة رسوم تلقائية بناءً على GRT/NRT والساعات والأيام",
    "نظام مذكرات ومخاطبات رسمية مع الأرشفة التلقائية",
    "أرشيف شامل مع إمكانية رفع ملفات خارجية (PDF, Word, Excel, صور)",
    "مرفقات الفواتير مع تفاصيل الاحتساب والأساس القانوني",
    "مراجعة الفواتير الخارجية وإعداد تقارير الفروقات",
    "نظام صلاحيات دقيق (مدير، محاسب، مراجع، مستخدم، عميل)",
    "حماية البيانات بالتشفير والتحقق من الهوية",
    "إشعارات ذكية مع عداد غير المقروء",
    "تقارير مالية تفصيلية مع رسوم بيانية",
    "دعم كامل للغة العربية (RTL)",
    "وضع ليلي/نهاري",
    "تخزين محلي آمن (AsyncStorage مع تشفير)",
]
for feature in features:
    para = doc.add_paragraph(style='List Bullet')
    set_rtl(para)
    para.add_run(feature)

add_paragraph(doc, "1.3 التقنيات المستخدمة", bold=True, size=14)

tech_table = doc.add_table(rows=1, cols=3)
tech_table.alignment = WD_TABLE_ALIGNMENT.CENTER
add_table_row(tech_table, ["الوصف", "الإصدار", "التقنية"], header=True)
tech_data = [
    ("إطار عمل التطبيق", "SDK 54", "Expo"),
    ("لغة البرمجة", "5.9", "TypeScript"),
    ("مكتبة الواجهة", "0.81.5", "React Native"),
    ("التوجيه والملاحة", "6.x", "Expo Router"),
    ("التصميم والأنماط", "4.x", "NativeWind (Tailwind CSS)"),
    ("إدارة الحالة", "Context API", "React Context + useReducer"),
    ("التخزين المحلي", "2.x", "AsyncStorage"),
    ("الأيقونات", "15.x", "Material Icons + SF Symbols"),
    ("الرسوم المتحركة", "4.x", "React Native Reanimated"),
    ("قاعدة البيانات", "0.44", "Drizzle ORM + PostgreSQL"),
    ("خادم API", "4.x", "Express + tRPC"),
    ("إدارة الطلبات", "5.x", "TanStack Query"),
]
for desc, version, tech in tech_data:
    row = tech_table.add_row()
    for i, text in enumerate([desc, version, tech]):
        row.cells[i].text = text
        row.cells[i].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT

doc.add_page_break()

# ═══════════════════════════════════════════════════════════════
# الفصل الثاني: المتطلبات التقنية
# ═══════════════════════════════════════════════════════════════
add_heading(doc, "الفصل الثاني: المتطلبات التقنية", 1, (30, 58, 95))

add_paragraph(doc, "2.1 متطلبات التشغيل", bold=True, size=14)
req_table = doc.add_table(rows=1, cols=2)
req_table.alignment = WD_TABLE_ALIGNMENT.CENTER
add_table_row(req_table, ["المتطلب", "المواصفة"], header=True)
reqs = [
    ("نظام Android", "Android 8.0+ (API Level 26+)"),
    ("نظام iOS", "iOS 15.0+"),
    ("ذاكرة RAM", "2GB كحد أدنى"),
    ("مساحة التخزين", "100MB للتثبيت"),
    ("Node.js", "v18+ للتطوير"),
    ("pnpm", "9.12.0 للتطوير"),
    ("Expo CLI", "أحدث إصدار"),
    ("Android Studio", "للبناء والاختبار"),
]
for req, spec in reqs:
    row = req_table.add_row()
    row.cells[0].text = req
    row.cells[1].text = spec
    for cell in row.cells:
        cell.paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT

add_paragraph(doc, "2.2 الاعتماديات الرئيسية (package.json)", bold=True, size=14)
deps_table = doc.add_table(rows=1, cols=3)
add_table_row(deps_table, ["الوصف", "الإصدار", "الحزمة"], header=True)
deps = [
    ("expo", "~54.0.29", "إطار عمل Expo"),
    ("react-native", "0.81.5", "React Native"),
    ("expo-router", "~6.0.19", "نظام التوجيه"),
    ("nativewind", "^4.2.1", "Tailwind CSS لـ React Native"),
    ("@react-native-async-storage/async-storage", "^2.2.0", "التخزين المحلي"),
    ("expo-document-picker", "^13.x", "اختيار الملفات"),
    ("expo-haptics", "~15.0.8", "الاهتزاز"),
    ("expo-notifications", "~0.32.15", "الإشعارات"),
    ("react-native-reanimated", "~4.1.6", "الرسوم المتحركة"),
    ("@tanstack/react-query", "^5.90.12", "إدارة الطلبات"),
    ("@trpc/client", "11.7.2", "API Client"),
    ("drizzle-orm", "^0.44.7", "ORM قاعدة البيانات"),
    ("zod", "^4.2.1", "التحقق من البيانات"),
]
for pkg, ver, desc in deps:
    row = deps_table.add_row()
    for i, text in enumerate([desc, ver, pkg]):
        row.cells[i].text = text
        row.cells[i].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT

doc.add_page_break()

# ═══════════════════════════════════════════════════════════════
# الفصل الثالث: هيكل المشروع
# ═══════════════════════════════════════════════════════════════
add_heading(doc, "الفصل الثالث: هيكل المشروع", 1, (30, 58, 95))

add_paragraph(doc, "3.1 هيكل الملفات والمجلدات", bold=True, size=14)

structure_text = """
habib-vessel-app/
├── app/                          # شاشات التطبيق (Expo Router)
│   ├── _layout.tsx               # التخطيط الجذري مع المسارات
│   ├── login.tsx                 # شاشة تسجيل الدخول
│   ├── pricing.tsx               # نظام الأسعار والرسوم
│   ├── archive.tsx               # الأرشيف الشامل
│   ├── review.tsx                # مراجعة الفواتير الخارجية
│   ├── users.tsx                 # إدارة المستخدمين والصلاحيات
│   ├── (tabs)/                   # التبويبات الرئيسية
│   │   ├── _layout.tsx           # شريط التنقل السفلي
│   │   ├── index.tsx             # لوحة التحكم الرئيسية
│   │   ├── vessels.tsx           # إدارة السفن
│   │   ├── invoices.tsx          # إدارة الفواتير
│   │   ├── reports.tsx           # التقارير والمذكرات والأرشيف
│   │   └── settings.tsx          # الإعدادات والإشعارات
│   ├── vessel/
│   │   ├── [id].tsx              # تفاصيل السفينة
│   │   └── new.tsx               # إضافة سفينة جديدة
│   ├── invoice/
│   │   ├── [id].tsx              # تفاصيل الفاتورة
│   │   ├── new.tsx               # إنشاء فاتورة جديدة
│   │   └── attachment.tsx        # مرفقات الفاتورة
│   └── memo/
│       ├── [id].tsx              # تفاصيل المذكرة
│       └── new.tsx               # إنشاء مذكرة جديدة
├── components/
│   ├── screen-container.tsx      # حاوية الشاشة مع SafeArea
│   ├── haptic-tab.tsx            # تبويب مع اهتزاز
│   └── ui/
│       └── icon-symbol.tsx       # تعيين الأيقونات
├── lib/
│   ├── app-context.tsx           # Context الرئيسي للتطبيق
│   ├── storage.ts                # أنواع البيانات ووظائف التخزين
│   ├── seed-data.ts              # البيانات الافتراضية
│   ├── theme-provider.tsx        # مزود الثيم
│   └── utils.ts                  # دوال مساعدة
├── hooks/
│   ├── use-colors.ts             # ألوان الثيم
│   └── use-color-scheme.ts       # الوضع الليلي/النهاري
├── assets/images/                # الشعارات والصور
├── server/                       # خادم Express + tRPC
├── theme.config.js               # إعدادات الألوان
├── tailwind.config.js            # إعدادات Tailwind
└── app.config.ts                 # إعدادات Expo
"""

para = doc.add_paragraph()
set_rtl(para)
run = para.add_run(structure_text)
run.font.name = "Courier New"
run.font.size = Pt(9)

doc.add_page_break()

# ═══════════════════════════════════════════════════════════════
# الفصل الرابع: نظام الصلاحيات والأمان
# ═══════════════════════════════════════════════════════════════
add_heading(doc, "الفصل الرابع: نظام الصلاحيات والأمان", 1, (30, 58, 95))

add_paragraph(doc, "4.1 أدوار المستخدمين", bold=True, size=14)

roles_table = doc.add_table(rows=1, cols=4)
add_table_row(roles_table, ["الوصف", "الصلاحيات", "الدور", "الكود"], header=True)
roles = [
    ("admin", "مدير النظام", "جميع الصلاحيات بلا قيود", "إدارة كاملة للنظام، المستخدمين، الفواتير، السفن، التقارير، الأرشيف"),
    ("accountant", "محاسب", "إدارة الفواتير والمدفوعات", "إنشاء/تعديل الفواتير، تسجيل المدفوعات، التقارير المالية"),
    ("reviewer", "مراجع", "مراجعة وموافقة", "مراجعة الفواتير، الموافقة/الرفض، عرض التقارير"),
    ("user", "مستخدم عادي", "عرض محدود", "عرض السفن والفواتير فقط، لا يمكن التعديل"),
    ("client", "عميل", "بوابة العملاء", "عرض فواتيره الخاصة فقط، لا يمكن الوصول لبيانات الآخرين"),
]
for code, role, perms, desc in roles:
    row = roles_table.add_row()
    for i, text in enumerate([desc, perms, role, code]):
        row.cells[i].text = text
        row.cells[i].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT

add_paragraph(doc, "4.2 مصفوفة الصلاحيات التفصيلية", bold=True, size=14)

perm_table = doc.add_table(rows=1, cols=6)
add_table_row(perm_table, ["عميل", "مستخدم", "مراجع", "محاسب", "مدير", "الوظيفة"], header=True)
perms_matrix = [
    ("عرض السفن", "✓", "✓", "✓", "✓", "✓"),
    ("إضافة/تعديل سفينة", "✗", "✗", "✗", "✓", "✓"),
    ("حذف سفينة", "✗", "✗", "✗", "✗", "✓"),
    ("عرض الفواتير", "فواتيره فقط", "✓", "✓", "✓", "✓"),
    ("إنشاء فاتورة", "✗", "✗", "✗", "✓", "✓"),
    ("تعديل فاتورة", "✗", "✗", "✗", "✓", "✓"),
    ("موافقة/رفض فاتورة", "✗", "✗", "✓", "✗", "✓"),
    ("تسجيل دفعة", "✗", "✗", "✗", "✓", "✓"),
    ("إنشاء مذكرة", "✗", "✗", "✓", "✓", "✓"),
    ("الأرشيف", "✗", "عرض فقط", "✓", "✓", "✓"),
    ("إدارة المستخدمين", "✗", "✗", "✗", "✗", "✓"),
    ("التقارير المالية", "✗", "✗", "✓", "✓", "✓"),
    ("نظام الأسعار", "✗", "✓", "✓", "✓", "✓"),
    ("مراجعة فواتير خارجية", "✗", "✗", "✓", "✓", "✓"),
]
for func, admin, acc, rev, user, client in perms_matrix:
    row = perm_table.add_row()
    for i, text in enumerate([client, user, rev, acc, admin, func]):
        row.cells[i].text = text
        row.cells[i].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

add_paragraph(doc, "4.3 آليات حماية البيانات", bold=True, size=14)
security_items = [
    "تشفير كلمات المرور: استخدام SHA-256 مع salt عشوائي",
    "التحقق من الجلسة: رمز جلسة فريد لكل تسجيل دخول",
    "فلترة البيانات: كل مستخدم يرى فقط ما يُسمح له",
    "سجل العمليات: تسجيل كل عملية مع الوقت والمستخدم",
    "انتهاء الجلسة: تسجيل خروج تلقائي بعد فترة عدم نشاط",
    "التحقق من الصلاحية: فحص الدور قبل كل عملية حساسة",
    "حماية المسارات: إعادة توجيه غير المصرح لهم لصفحة الدخول",
    "تشفير التخزين المحلي: البيانات الحساسة مشفرة في AsyncStorage",
]
for item in security_items:
    para = doc.add_paragraph(style='List Bullet')
    set_rtl(para)
    para.add_run(item)

doc.add_page_break()

# ═══════════════════════════════════════════════════════════════
# الفصل الخامس: قاعدة البيانات والأنواع
# ═══════════════════════════════════════════════════════════════
add_heading(doc, "الفصل الخامس: قاعدة البيانات والأنواع", 1, (30, 58, 95))

add_paragraph(doc, "5.1 نوع بيانات السفينة (Vessel)", bold=True, size=14)
vessel_code = """export interface Vessel {
  id: number;
  name: string;           // اسم السفينة
  imoNumber: string;      // رقم IMO الدولي
  flag: string;           // جنسية السفينة
  vesselType: string;     // نوع السفينة
  grt: number;            // الطنية الإجمالية
  nrt: number;            // الطنية الصافية
  length: number;         // طول السفينة (متر)
  beam: number;           // عرض السفينة (متر)
  draft: number;          // غاطس السفينة (متر)
  owner: string;          // مالك السفينة
  agent: string;          // الوكيل البحري
  status: "active" | "docked" | "maintenance" | "inactive";
  lastPort?: string;      // آخر ميناء
  nextPort?: string;      // الميناء القادم
  arrivalDate?: string;   // تاريخ الوصول
  departureDate?: string; // تاريخ المغادرة
  notes?: string;         // ملاحظات
  createdAt: string;
  updatedAt: string;
}"""
para = doc.add_paragraph()
set_rtl(para)
run = para.add_run(vessel_code)
run.font.name = "Courier New"
run.font.size = Pt(9)

add_paragraph(doc, "5.2 نوع بيانات الفاتورة (Invoice)", bold=True, size=14)
invoice_code = """export interface Invoice {
  id: number;
  invoiceNumber: string;  // رقم الفاتورة
  vesselId: number;       // معرف السفينة
  vesselName: string;     // اسم السفينة
  clientName: string;     // اسم العميل
  amount: number;         // المبلغ بالدولار
  amountYER?: number;     // المبلغ بالريال اليمني
  currency: string;       // العملة
  exchangeRate?: number;  // سعر الصرف
  status: "draft" | "pending" | "approved" | "paid" | "overdue" | "rejected";
  issueDate: string;      // تاريخ الإصدار
  dueDate: string;        // تاريخ الاستحقاق
  paidDate?: string;      // تاريخ الدفع
  items: InvoiceItem[];   // بنود الفاتورة
  notes?: string;         // ملاحظات
  attachments?: string[]; // مرفقات
  externalInvoiceAmount?: number;  // مبلغ الفاتورة الخارجية
  discrepancy?: number;   // الفرق/الخلاف
  reviewNotes?: string;   // ملاحظات المراجعة
  approvedBy?: string;    // المعتمد من
  createdBy: string;      // أنشئ بواسطة
  createdAt: string;
  updatedAt: string;
}

export interface InvoiceItem {
  id: number;
  description: string;   // وصف البند
  quantity: number;      // الكمية
  unitPrice: number;     // سعر الوحدة
  total: number;         // الإجمالي
  unit?: string;         // الوحدة (ساعة، يوم، رحلة...)
  category?: string;     // الفئة (إرشاد، قطر، رسوم...)
}"""
para = doc.add_paragraph()
set_rtl(para)
run = para.add_run(invoice_code)
run.font.name = "Courier New"
run.font.size = Pt(9)

add_paragraph(doc, "5.3 نوع بيانات المذكرة (Memo)", bold=True, size=14)
memo_code = """export interface Memo {
  id: number;
  vesselId?: number;       // السفينة المرتبطة
  vesselName?: string;     // اسم السفينة
  title: string;           // عنوان المذكرة
  content: string;         // محتوى المذكرة
  recipientEntity?: string; // الجهة المستلمة
  memoType: "communication" | "complaint" | "inquiry" | "notification";
  status: "draft" | "sent" | "archived";
  attachments?: string[];  // مرفقات
  createdAt: string;
  updatedAt: string;
}"""
para = doc.add_paragraph()
set_rtl(para)
run = para.add_run(memo_code)
run.font.name = "Courier New"
run.font.size = Pt(9)

add_paragraph(doc, "5.4 نوع بيانات الأرشيف (Archive)", bold=True, size=14)
archive_code = """export interface Archive {
  id: number;
  title: string;           // عنوان الملف
  description?: string;    // وصف الملف
  category: "invoice" | "memo" | "vessel" | "payment" | "report" | "other";
  fileType?: string;       // نوع الملف (PDF, Word, Excel, صورة)
  fileSize?: number;       // حجم الملف (بايت)
  fileUri?: string;        // مسار الملف المحلي
  fileName?: string;       // اسم الملف الأصلي
  relatedId?: number;      // معرف العنصر المرتبط
  relatedType?: string;    // نوع العنصر المرتبط
  tags?: string;           // وسوم للبحث
  isExternal: boolean;     // ملف خارجي مرفوع
  createdAt: string;
}"""
para = doc.add_paragraph()
set_rtl(para)
run = para.add_run(archive_code)
run.font.name = "Courier New"
run.font.size = Pt(9)

add_paragraph(doc, "5.5 نوع بيانات المستخدم (User)", bold=True, size=14)
user_code = """export interface User {
  id: number;
  name: string;            // الاسم الكامل
  email: string;           // البريد الإلكتروني
  password: string;        // كلمة المرور (مشفرة)
  role: "admin" | "accountant" | "reviewer" | "user" | "client";
  isActive: boolean;       // حالة الحساب
  lastLogin?: string;      // آخر تسجيل دخول
  createdAt: string;
}"""
para = doc.add_paragraph()
set_rtl(para)
run = para.add_run(user_code)
run.font.name = "Courier New"
run.font.size = Pt(9)

doc.add_page_break()

# ═══════════════════════════════════════════════════════════════
# الفصل السادس: الشاشات والواجهات
# ═══════════════════════════════════════════════════════════════
add_heading(doc, "الفصل السادس: الشاشات والواجهات", 1, (30, 58, 95))

screens = [
    ("6.1 شاشة تسجيل الدخول (login.tsx)", """
- حقل البريد الإلكتروني مع التحقق
- حقل كلمة المرور مع إظهار/إخفاء
- زر تسجيل الدخول مع مؤشر التحميل
- التحقق من الدور وتوجيه المستخدم المناسب
- حماية ضد محاولات الدخول المتكررة
- بيانات تجريبية للاختبار
"""),
    ("6.2 لوحة التحكم الرئيسية (index.tsx)", """
- ترحيب شخصي مع اسم المستخدم ودوره
- بطاقة إجمالي الإيرادات المحصلة
- 4 بطاقات إحصائية (سفن نشطة، فواتير معلقة، مذكرات، أرشيف)
- 9 أزرار إجراءات سريعة للشاشات الرئيسية
- قائمة آخر 3 فواتير مع حالتها
- زر الإشعارات مع عداد غير المقروء
"""),
    ("6.3 شاشة إدارة السفن (vessels.tsx)", """
- قائمة السفن مع بحث وتصفية حسب الحالة
- بطاقة لكل سفينة مع: الاسم، رقم IMO، GRT، الحالة
- فلتر بالحالة (نشطة، راسية، صيانة، غير نشطة)
- زر إضافة سفينة جديدة (للمدير والمحاسب)
- الانتقال لتفاصيل السفينة بالضغط
"""),
    ("6.4 شاشة تفاصيل السفينة (vessel/[id].tsx)", """
- جميع بيانات السفينة التفصيلية
- قسم المعلومات الفنية (GRT, NRT, الأبعاد)
- قسم معلومات التشغيل (المالك، الوكيل، الموانئ)
- قائمة الفواتير المرتبطة بالسفينة
- إمكانية التعديل والحذف حسب الصلاحية
"""),
    ("6.5 شاشة الفواتير (invoices.tsx)", """
- قائمة الفواتير مع بحث وفلترة بالحالة
- بطاقة لكل فاتورة مع: الرقم، السفينة، المبلغ، الحالة
- فلتر بالحالة (كل، مسودة، معلق، موافق، مدفوع، متأخر)
- زر إنشاء فاتورة جديدة
- الانتقال لتفاصيل الفاتورة
"""),
    ("6.6 شاشة تفاصيل الفاتورة (invoice/[id].tsx)", """
- جميع بيانات الفاتورة التفصيلية
- جدول بنود الفاتورة مع الكميات والأسعار
- سير العمل: مسودة → معلق → موافق → مدفوع
- أزرار تغيير الحالة حسب الصلاحية
- رابط للمرفقات وتفاصيل الاحتساب
- معلومات الفاتورة الخارجية والفروقات
"""),
    ("6.7 شاشة إنشاء فاتورة (invoice/new.tsx)", """
- اختيار السفينة من القائمة
- بيانات العميل والتواريخ
- إضافة بنود الفاتورة ديناميكياً
- احتساب الإجمالي تلقائياً
- حقل الفاتورة الخارجية والفروقات
- حفظ كمسودة أو إرسال مباشرة
"""),
    ("6.8 شاشة مرفقات الفاتورة (invoice/attachment.tsx)", """
- بيانات السفينة والفاتورة
- جدول تفصيلي لأساس الاحتساب
- حاسبة الرسوم التلقائية
- ملاحظات المراجعة والتصحيح
- رفع ملفات مرفقة (PDF, صور)
- تصدير التفاصيل
"""),
    ("6.9 شاشة نظام الأسعار (pricing.tsx)", """
- 4 تبويبات: إرشاد، قطر، رسوم، حاسبة
- جدول أجر الإرشاد حسب GRT (14 نطاق)
- جدول أجر القطر حسب GRT (12 نطاق)
- جدول الرسوم والأجور (15 بند)
- حاسبة تلقائية: أدخل GRT/NRT/الساعات/الأيام
- نتائج الاحتساب بالدولار والريال اليمني
"""),
    ("6.10 شاشة المذكرات (memo/new.tsx)", """
- اختيار السفينة المرتبطة
- عنوان ومحتوى المذكرة
- نوع المذكرة (تواصل، شكوى، استفسار، إشعار)
- الجهة المستلمة
- حالة المذكرة (مسودة، مُرسلة، مؤرشفة)
- إرسال للأرشيف تلقائياً
"""),
    ("6.11 شاشة الأرشيف (archive.tsx)", """
- قائمة جميع الملفات المؤرشفة
- فلترة حسب الفئة (فواتير، مذكرات، سفن...)
- بحث نصي في العنوان والوصف
- رفع ملفات خارجية (PDF, Word, Excel, صور)
- عرض تفاصيل الملف (النوع، الحجم، التاريخ)
- وسوم للتصنيف والبحث
"""),
    ("6.12 شاشة مراجعة الفواتير الخارجية (review.tsx)", """
- رفع فاتورة خارجية للمراجعة
- مقارنة مع فاتورة النظام
- احتساب الفروقات تلقائياً
- إضافة ملاحظات المراجعة
- إنشاء تقرير المراجعة
- حفظ في الأرشيف
"""),
    ("6.13 شاشة إدارة المستخدمين (users.tsx)", """
- قائمة جميع المستخدمين (للمدير فقط)
- بطاقة لكل مستخدم مع: الاسم، الدور، الحالة
- تغيير دور المستخدم
- تفعيل/تعطيل الحساب
- إضافة مستخدم جديد
- سجل العمليات
"""),
]

for title_text, desc in screens:
    add_paragraph(doc, title_text, bold=True, size=13)
    para = doc.add_paragraph()
    set_rtl(para)
    para.add_run(desc.strip())

doc.add_page_break()

# ═══════════════════════════════════════════════════════════════
# الفصل السابع: نظام الأسعار
# ═══════════════════════════════════════════════════════════════
add_heading(doc, "الفصل السابع: نظام الأسعار والرسوم", 1, (30, 58, 95))

add_paragraph(doc, "7.1 جدول أجر الإرشاد حسب GRT", bold=True, size=14)
pilotage_table = doc.add_table(rows=1, cols=4)
add_table_row(pilotage_table, ["أجر/ساعتين ($)", "أجر/ساعة ($)", "نطاق GRT", "الكود"], header=True)
pilotage_rates = [
    ("P1", "0 - 1,000", "80", "160"),
    ("P2", "1,001 - 2,000", "100", "200"),
    ("P3", "2,001 - 3,000", "120", "240"),
    ("P4", "3,001 - 5,000", "150", "300"),
    ("P5", "5,001 - 8,000", "180", "360"),
    ("P6", "8,001 - 12,000", "220", "440"),
    ("P7", "12,001 - 18,000", "270", "540"),
    ("P8", "18,001 - 25,000", "320", "640"),
    ("P9", "25,001 - 35,000", "380", "760"),
    ("P10", "35,001 - 50,000", "450", "900"),
    ("P11", "50,001 - 70,000", "530", "1,060"),
    ("P12", "70,001 - 100,000", "620", "1,240"),
    ("P13", "100,001 - 150,000", "720", "1,440"),
    ("P14", "> 150,000", "850", "1,700"),
]
for code, grt_range, per_hour, per_two in pilotage_rates:
    row = pilotage_table.add_row()
    for i, text in enumerate([per_two, per_hour, grt_range, code]):
        row.cells[i].text = text
        row.cells[i].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

add_paragraph(doc, "7.2 جدول أجر القطر حسب GRT", bold=True, size=14)
towage_table = doc.add_table(rows=1, cols=2)
add_table_row(towage_table, ["الأجر ($)", "نطاق GRT"], header=True)
towage_rates = [
    ("0 - 1,000", "500"),
    ("1,001 - 2,000", "700"),
    ("2,001 - 3,000", "900"),
    ("3,001 - 5,000", "1,200"),
    ("5,001 - 8,000", "1,600"),
    ("8,001 - 12,000", "2,100"),
    ("12,001 - 18,000", "2,700"),
    ("18,001 - 25,000", "3,400"),
    ("25,001 - 35,000", "4,200"),
    ("35,001 - 50,000", "5,200"),
    ("50,001 - 70,000", "6,400"),
    ("> 70,000", "8,000"),
]
for grt_range, rate in towage_rates:
    row = towage_table.add_row()
    for i, text in enumerate([rate, grt_range]):
        row.cells[i].text = text
        row.cells[i].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

add_paragraph(doc, "7.3 جدول الرسوم والأجور", bold=True, size=14)
fees_table = doc.add_table(rows=1, cols=4)
add_table_row(fees_table, ["الحد الأدنى ($)", "الوحدة", "السعر ($)", "البند"], header=True)
port_fees = [
    ("رسوم الرسو", "لكل 24 ساعة/GRT", "0.08", "20"),
    ("رسوم الصحة", "لكل رحلة", "150", "150"),
    ("رسوم الجمارك", "لكل رحلة", "200", "200"),
    ("رسوم الحراسة", "لكل 24 ساعة", "100", "100"),
    ("رسوم الصرف الصحي", "لكل رحلة", "80", "80"),
    ("رسوم المياه", "لكل طن", "5", "50"),
    ("رسوم الوقود", "لكل طن", "15", "-"),
    ("رسوم الشحن/التفريغ", "لكل طن", "8", "200"),
    ("رسوم الحاويات", "لكل حاوية", "50", "50"),
    ("رسوم الركاب", "لكل راكب", "10", "100"),
    ("رسوم الطاقم", "لكل فرد", "20", "100"),
    ("رسوم الوكالة", "لكل رحلة", "300", "300"),
    ("رسوم الاتصالات", "لكل يوم", "30", "30"),
    ("رسوم الطوارئ", "حسب الحالة", "500", "500"),
    ("رسوم التفتيش", "لكل رحلة", "250", "250"),
]
for name, unit, rate, minimum in port_fees:
    row = fees_table.add_row()
    for i, text in enumerate([minimum, unit, rate, name]):
        row.cells[i].text = text
        row.cells[i].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.CENTER

doc.add_page_break()

# ═══════════════════════════════════════════════════════════════
# الفصل الثامن: الأكواد البرمجية الرئيسية
# ═══════════════════════════════════════════════════════════════
add_heading(doc, "الفصل الثامن: الأكواد البرمجية الرئيسية", 1, (30, 58, 95))

# قراءة الملفات الرئيسية
files_to_include = [
    ("/home/ubuntu/habib-vessel-app/lib/storage.ts", "8.1 ملف أنواع البيانات والتخزين (lib/storage.ts)"),
    ("/home/ubuntu/habib-vessel-app/lib/app-context.tsx", "8.2 ملف Context الرئيسي (lib/app-context.tsx)"),
    ("/home/ubuntu/habib-vessel-app/app/_layout.tsx", "8.3 ملف التخطيط الجذري (app/_layout.tsx)"),
    ("/home/ubuntu/habib-vessel-app/app/login.tsx", "8.4 شاشة تسجيل الدخول (app/login.tsx)"),
    ("/home/ubuntu/habib-vessel-app/app/(tabs)/index.tsx", "8.5 لوحة التحكم الرئيسية (app/(tabs)/index.tsx)"),
    ("/home/ubuntu/habib-vessel-app/app/(tabs)/vessels.tsx", "8.6 شاشة السفن (app/(tabs)/vessels.tsx)"),
    ("/home/ubuntu/habib-vessel-app/app/(tabs)/invoices.tsx", "8.7 شاشة الفواتير (app/(tabs)/invoices.tsx)"),
    ("/home/ubuntu/habib-vessel-app/app/pricing.tsx", "8.8 نظام الأسعار (app/pricing.tsx)"),
    ("/home/ubuntu/habib-vessel-app/app/archive.tsx", "8.9 الأرشيف الشامل (app/archive.tsx)"),
    ("/home/ubuntu/habib-vessel-app/app/review.tsx", "8.10 مراجعة الفواتير (app/review.tsx)"),
    ("/home/ubuntu/habib-vessel-app/app/users.tsx", "8.11 إدارة المستخدمين (app/users.tsx)"),
    ("/home/ubuntu/habib-vessel-app/app/memo/new.tsx", "8.12 إنشاء مذكرة (app/memo/new.tsx)"),
    ("/home/ubuntu/habib-vessel-app/app/invoice/attachment.tsx", "8.13 مرفقات الفاتورة (app/invoice/attachment.tsx)"),
    ("/home/ubuntu/habib-vessel-app/lib/seed-data.ts", "8.14 البيانات الافتراضية (lib/seed-data.ts)"),
]

for filepath, section_title in files_to_include:
    add_paragraph(doc, section_title, bold=True, size=13)
    content = read_file_content(filepath)
    # تقسيم المحتوى إذا كان طويلاً جداً
    max_chars = 8000
    if len(content) > max_chars:
        content = content[:max_chars] + "\n\n... [تم اختصار الكود - راجع الملف الأصلي للكود الكامل] ..."
    para = doc.add_paragraph()
    set_rtl(para)
    run = para.add_run(content)
    run.font.name = "Courier New"
    run.font.size = Pt(8)

doc.add_page_break()

# ═══════════════════════════════════════════════════════════════
# الفصل التاسع: دليل التثبيت والتشغيل
# ═══════════════════════════════════════════════════════════════
add_heading(doc, "الفصل التاسع: دليل التثبيت والتشغيل", 1, (30, 58, 95))

add_paragraph(doc, "9.1 متطلبات التطوير", bold=True, size=14)
dev_reqs = [
    "Node.js v18 أو أحدث",
    "pnpm v9.12.0 (مدير الحزم)",
    "Expo CLI: npm install -g expo-cli",
    "Android Studio (لبناء APK)",
    "JDK 17 (لبناء Android)",
]
for req in dev_reqs:
    para = doc.add_paragraph(style='List Bullet')
    set_rtl(para)
    para.add_run(req)

add_paragraph(doc, "9.2 خطوات التثبيت", bold=True, size=14)
install_steps = """# 1. استنساخ المشروع
git clone <repository-url>
cd habib-vessel-app

# 2. تثبيت الاعتماديات
pnpm install

# 3. تشغيل التطبيق في وضع التطوير
pnpm dev

# 4. تشغيل على Android مباشرة
pnpm android

# 5. بناء APK للإنتاج
npx expo build:android --type apk

# أو باستخدام EAS Build
npx eas build --platform android --profile production"""

para = doc.add_paragraph()
set_rtl(para)
run = para.add_run(install_steps)
run.font.name = "Courier New"
run.font.size = Pt(10)

add_paragraph(doc, "9.3 إعداد قاعدة البيانات (اختياري)", bold=True, size=14)
db_setup = """# إعداد متغيرات البيئة
cp .env.example .env
# تعديل DATABASE_URL في ملف .env

# تطبيق مخطط قاعدة البيانات
pnpm db:push

# تشغيل الخادم
pnpm dev:server"""

para = doc.add_paragraph()
set_rtl(para)
run = para.add_run(db_setup)
run.font.name = "Courier New"
run.font.size = Pt(10)

add_paragraph(doc, "9.4 بناء APK للإنتاج", bold=True, size=14)
build_steps = """# الطريقة 1: EAS Build (موصى به)
# 1. تسجيل الدخول في Expo
npx expo login

# 2. إعداد EAS
npx eas build:configure

# 3. بناء APK
npx eas build --platform android --profile preview

# الطريقة 2: Local Build
# 1. توليد مشروع Android
npx expo prebuild --platform android

# 2. بناء APK
cd android && ./gradlew assembleRelease

# الملف الناتج: android/app/build/outputs/apk/release/app-release.apk"""

para = doc.add_paragraph()
set_rtl(para)
run = para.add_run(build_steps)
run.font.name = "Courier New"
run.font.size = Pt(10)

doc.add_page_break()

# ═══════════════════════════════════════════════════════════════
# الفصل العاشر: بيانات الدخول
# ═══════════════════════════════════════════════════════════════
add_heading(doc, "الفصل العاشر: بيانات الدخول التجريبية", 1, (30, 58, 95))

add_paragraph(doc, "10.1 حسابات الاختبار", bold=True, size=14)

login_table = doc.add_table(rows=1, cols=4)
add_table_row(login_table, ["الصلاحيات", "كلمة المرور", "البريد الإلكتروني", "الدور"], header=True)
logins = [
    ("مدير النظام", "admin@habib.com", "admin123", "جميع الصلاحيات"),
    ("محاسب", "accountant@habib.com", "acc123", "الفواتير والمدفوعات"),
    ("مراجع", "reviewer@habib.com", "rev123", "المراجعة والموافقة"),
    ("مستخدم", "user@habib.com", "user123", "عرض محدود"),
    ("عميل", "client@habib.com", "client123", "فواتيره فقط"),
]
for role, email, password, perms in logins:
    row = login_table.add_row()
    for i, text in enumerate([perms, password, email, role]):
        row.cells[i].text = text
        row.cells[i].paragraphs[0].alignment = WD_ALIGN_PARAGRAPH.RIGHT

add_paragraph(doc, "10.2 ملاحظات الأمان", bold=True, size=14)
security_notes = [
    "يجب تغيير كلمات المرور الافتراضية قبل الاستخدام الإنتاجي",
    "يُنصح بتفعيل المصادقة الثنائية للحسابات الحساسة",
    "يتم تشفير كلمات المرور باستخدام SHA-256 مع salt",
    "يتم تسجيل جميع عمليات الدخول في سجل العمليات",
    "يتم قفل الحساب بعد 5 محاولات فاشلة متتالية",
]
for note in security_notes:
    para = doc.add_paragraph(style='List Bullet')
    set_rtl(para)
    para.add_run(note)

doc.add_page_break()

# ═══════════════════════════════════════════════════════════════
# الخاتمة
# ═══════════════════════════════════════════════════════════════
add_heading(doc, "الخاتمة", 1, (30, 58, 95))
add_paragraph(doc, """نظام حبيب لإدارة السفن والفواتير هو نظام متكامل ومتطور يوفر جميع الأدوات اللازمة لإدارة عمليات الموانئ والسفن بكفاءة عالية. يتميز النظام بواجهة مستخدم عربية سهلة الاستخدام، ونظام صلاحيات دقيق يضمن أمان البيانات، وجداول أسعار حقيقية مستخرجة من ملفات العمل الفعلية.

تم تطوير هذا النظام بالكامل بواسطة حبيب، ويمكن تخصيصه وتطويره بشكل مستمر حسب الاحتياجات المتغيرة.""")

add_paragraph(doc, "للتواصل والدعم الفني:", bold=True)
add_paragraph(doc, "المطوّر: حبيب\nالنظام: نظام حبيب لإدارة السفن والفواتير\nالإصدار: 2.0.0")

# حفظ المستند
output_path = "/home/ubuntu/نظام_حبيب_وثيقة_شاملة.docx"
doc.save(output_path)
print(f"تم إنشاء الملف بنجاح: {output_path}")
print(f"حجم الملف: {os.path.getsize(output_path) / 1024:.1f} KB")
