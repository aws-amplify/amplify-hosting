import { View, Text, ScrollView, TouchableOpacity, TextInput, Alert, Modal, FlatList } from "react-native";
import { useRouter } from "expo-router";
import { ScreenContainer } from "@/components/screen-container";
import { useApp } from "@/lib/app-context";
import MaterialIcons from "@expo/vector-icons/MaterialIcons";
import { useState, useMemo } from "react";
import * as DocumentPicker from "expo-document-picker";
import { Archive } from "@/lib/storage";

const CATEGORIES = [
  { key: "all", label: "الكل", icon: "folder", color: "#1E3A5F" },
  { key: "فواتير", label: "فواتير", icon: "receipt", color: "#27AE60" },
  { key: "مذكرات", label: "مذكرات", icon: "description", color: "#3498DB" },
  { key: "سفن", label: "سفن", icon: "directions-boat", color: "#F39C12" },
  { key: "مراجعات", label: "مراجعات", icon: "rate-review", color: "#9B59B6" },
  { key: "ملفات خارجية", label: "ملفات خارجية", icon: "upload-file", color: "#E74C3C" },
  { key: "عقود", label: "عقود", icon: "gavel", color: "#16A085" },
  { key: "تقارير", label: "تقارير", icon: "bar-chart", color: "#D35400" },
];

const FILE_TYPE_ICONS: Record<string, string> = {
  pdf: "picture-as-pdf",
  doc: "description",
  docx: "description",
  xls: "table-chart",
  xlsx: "table-chart",
  jpg: "image",
  jpeg: "image",
  png: "image",
  txt: "text-snippet",
  zip: "folder-zip",
};

export default function ArchiveScreen() {
  const router = useRouter();
  const { archives, addArchive, deleteArchive, vessels, currentUser } = useApp();
  const [selectedCategory, setSelectedCategory] = useState("all");
  const [searchQuery, setSearchQuery] = useState("");
  const [showAddModal, setShowAddModal] = useState(false);
  const [showDetailModal, setShowDetailModal] = useState(false);
  const [selectedItem, setSelectedItem] = useState<Archive | null>(null);

  // Form state
  const [title, setTitle] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState("ملفات خارجية");
  const [selectedVesselId, setSelectedVesselId] = useState<number | null>(null);
  const [tags, setTags] = useState("");
  const [pickedFile, setPickedFile] = useState<{ name: string; uri: string; size?: number; mimeType?: string } | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const filteredArchives = useMemo(() => {
    return archives.filter((a) => {
      const matchCategory = selectedCategory === "all" || a.category === selectedCategory;
      const matchSearch = !searchQuery ||
        a.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
        (a.description || "").toLowerCase().includes(searchQuery.toLowerCase()) ||
        (a.vesselName || "").toLowerCase().includes(searchQuery.toLowerCase());
      return matchCategory && matchSearch;
    });
  }, [archives, selectedCategory, searchQuery]);

  const pickDocument = async () => {
    try {
      const result = await DocumentPicker.getDocumentAsync({
        type: "*/*",
        copyToCacheDirectory: true,
      });
      if (!result.canceled && result.assets && result.assets.length > 0) {
        const asset = result.assets[0];
        setPickedFile({ name: asset.name, uri: asset.uri, size: asset.size, mimeType: asset.mimeType || undefined });
        if (!title) setTitle(asset.name.replace(/\.[^/.]+$/, ""));
      }
    } catch {
      Alert.alert("خطأ", "تعذر اختيار الملف");
    }
  };

  const handleSave = async () => {
    if (!title.trim()) {
      Alert.alert("خطأ", "يرجى إدخال عنوان الملف");
      return;
    }
    setIsSaving(true);
    try {
      const vessel = vessels.find((v) => v.id === selectedVesselId);
      await addArchive({
        referenceType: pickedFile ? "file" : "document",
        title: title.trim(),
        description: description.trim() || undefined,
        category,
        vesselId: selectedVesselId || undefined,
        vesselName: vessel?.name,
        tags: tags.trim() || undefined,
        fileUri: pickedFile?.uri,
        fileName: pickedFile?.name,
        fileType: pickedFile?.mimeType,
        fileSize: pickedFile?.size,
        archivedBy: currentUser?.name || "النظام",
      });
      setShowAddModal(false);
      setTitle(""); setDescription(""); setTags(""); setPickedFile(null); setSelectedVesselId(null);
      Alert.alert("نجاح", "تم حفظ الملف في الأرشيف");
    } finally {
      setIsSaving(false);
    }
  };

  const handleDelete = (item: Archive) => {
    Alert.alert("تأكيد الحذف", `هل تريد حذف "${item.title}" من الأرشيف؟`, [
      { text: "إلغاء", style: "cancel" },
      { text: "حذف", style: "destructive", onPress: () => deleteArchive(item.id) },
    ]);
  };

  const getFileIcon = (fileName?: string, fileType?: string): string => {
    if (!fileName && !fileType) return "insert-drive-file";
    const ext = fileName?.split(".").pop()?.toLowerCase() || "";
    return FILE_TYPE_ICONS[ext] || "insert-drive-file";
  };

  const formatFileSize = (bytes?: number): string => {
    if (!bytes) return "";
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(1)} MB`;
  };

  const getRefTypeColor = (type: string): string => {
    const map: Record<string, string> = {
      invoice: "#27AE60", memo: "#3498DB", vessel: "#F39C12",
      document: "#9B59B6", review: "#E74C3C", file: "#1E3A5F",
    };
    return map[type] || "#6B7C93";
  };

  const getRefTypeLabel = (type: string): string => {
    const map: Record<string, string> = {
      invoice: "فاتورة", memo: "مذكرة", vessel: "سفينة",
      document: "وثيقة", review: "مراجعة", file: "ملف",
    };
    return map[type] || type;
  };

  return (
    <ScreenContainer containerClassName="bg-background">
      {/* Header */}
      <View style={{ backgroundColor: "#1E3A5F", paddingHorizontal: 20, paddingTop: 16, paddingBottom: 20 }}>
        <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 14 }}>
          <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 10 }}>
            <View style={{ width: 42, height: 42, borderRadius: 12, backgroundColor: "rgba(255,255,255,0.15)", alignItems: "center", justifyContent: "center" }}>
              <MaterialIcons name="archive" size={22} color="white" />
            </View>
            <View>
              <Text style={{ color: "white", fontSize: 18, fontWeight: "800" }}>الأرشيف الشامل</Text>
              <Text style={{ color: "rgba(255,255,255,0.7)", fontSize: 12 }}>{archives.length} ملف محفوظ</Text>
            </View>
          </View>
          <View style={{ flexDirection: "row-reverse", gap: 8 }}>
            <TouchableOpacity
              onPress={() => setShowAddModal(true)}
              style={{ backgroundColor: "#27AE60", borderRadius: 10, paddingHorizontal: 14, paddingVertical: 8, flexDirection: "row-reverse", alignItems: "center", gap: 4 }}
            >
              <MaterialIcons name="add" size={16} color="white" />
              <Text style={{ color: "white", fontSize: 13, fontWeight: "700" }}>إضافة</Text>
            </TouchableOpacity>
            <TouchableOpacity onPress={() => router.back()} style={{ width: 38, height: 38, borderRadius: 10, backgroundColor: "rgba(255,255,255,0.15)", alignItems: "center", justifyContent: "center" }}>
              <MaterialIcons name="arrow-forward" size={22} color="white" />
            </TouchableOpacity>
          </View>
        </View>

        {/* Search */}
        <View style={{ flexDirection: "row-reverse", alignItems: "center", backgroundColor: "rgba(255,255,255,0.15)", borderRadius: 12, paddingHorizontal: 12, paddingVertical: 8, gap: 8 }}>
          <MaterialIcons name="search" size={18} color="rgba(255,255,255,0.7)" />
          <TextInput
            value={searchQuery}
            onChangeText={setSearchQuery}
            placeholder="بحث في الأرشيف..."
            placeholderTextColor="rgba(255,255,255,0.5)"
            style={{ flex: 1, color: "white", fontSize: 14, textAlign: "right" }}
          />
        </View>
      </View>

      {/* Categories */}
      <View style={{ backgroundColor: "white", borderBottomWidth: 1, borderBottomColor: "#E5E7EB" }}>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={{ paddingHorizontal: 12, paddingVertical: 10, flexDirection: "row-reverse", gap: 8 }}>
          {CATEGORIES.map((cat) => (
            <TouchableOpacity
              key={cat.key}
              onPress={() => setSelectedCategory(cat.key)}
              style={{ paddingHorizontal: 12, paddingVertical: 6, borderRadius: 20, backgroundColor: selectedCategory === cat.key ? cat.color : "#F0F4F8", flexDirection: "row-reverse", alignItems: "center", gap: 4 }}
            >
              <MaterialIcons name={cat.icon as any} size={14} color={selectedCategory === cat.key ? "white" : "#6B7C93"} />
              <Text style={{ fontSize: 12, color: selectedCategory === cat.key ? "white" : "#6B7C93", fontWeight: selectedCategory === cat.key ? "700" : "400" }}>{cat.label}</Text>
            </TouchableOpacity>
          ))}
        </ScrollView>
      </View>

      {/* Archive List */}
      <FlatList
        data={filteredArchives}
        keyExtractor={(item) => String(item.id)}
        contentContainerStyle={{ padding: 16 }}
        showsVerticalScrollIndicator={false}
        ListEmptyComponent={
          <View style={{ alignItems: "center", paddingVertical: 60 }}>
            <MaterialIcons name="folder-open" size={64} color="#D1D5DB" />
            <Text style={{ fontSize: 16, color: "#9BA1A6", marginTop: 12 }}>لا توجد ملفات في هذه الفئة</Text>
          </View>
        }
        renderItem={({ item }) => (
          <TouchableOpacity
            onPress={() => { setSelectedItem(item); setShowDetailModal(true); }}
            style={{ backgroundColor: "white", borderRadius: 14, padding: 14, marginBottom: 10, flexDirection: "row-reverse", alignItems: "center", gap: 12, shadowColor: "#000", shadowOffset: { width: 0, height: 1 }, shadowOpacity: 0.05, shadowRadius: 3, elevation: 1 }}
          >
            <View style={{ width: 48, height: 48, borderRadius: 12, backgroundColor: getRefTypeColor(item.referenceType) + "15", alignItems: "center", justifyContent: "center" }}>
              <MaterialIcons name={getFileIcon(item.fileName, item.fileType) as any} size={24} color={getRefTypeColor(item.referenceType)} />
            </View>
            <View style={{ flex: 1 }}>
              <Text style={{ fontSize: 14, fontWeight: "700", color: "#1A2332" }} numberOfLines={1}>{item.title}</Text>
              {item.description && <Text style={{ fontSize: 12, color: "#6B7C93", marginTop: 2 }} numberOfLines={1}>{item.description}</Text>}
              <View style={{ flexDirection: "row-reverse", alignItems: "center", gap: 8, marginTop: 6 }}>
                <View style={{ backgroundColor: getRefTypeColor(item.referenceType) + "15", borderRadius: 6, paddingHorizontal: 6, paddingVertical: 2 }}>
                  <Text style={{ fontSize: 10, color: getRefTypeColor(item.referenceType), fontWeight: "700" }}>{getRefTypeLabel(item.referenceType)}</Text>
                </View>
                {item.category && <Text style={{ fontSize: 11, color: "#9BA1A6" }}>{item.category}</Text>}
                {item.vesselName && <Text style={{ fontSize: 11, color: "#9BA1A6" }}>• {item.vesselName}</Text>}
                {item.fileSize && <Text style={{ fontSize: 10, color: "#9BA1A6" }}>{formatFileSize(item.fileSize)}</Text>}
              </View>
            </View>
            <View style={{ alignItems: "center", gap: 6 }}>
              <Text style={{ fontSize: 10, color: "#9BA1A6" }}>{new Date(item.createdAt).toLocaleDateString("ar-SA")}</Text>
              <TouchableOpacity onPress={() => handleDelete(item)} style={{ backgroundColor: "#FEE2E2", borderRadius: 8, padding: 6 }}>
                <MaterialIcons name="delete-outline" size={16} color="#E74C3C" />
              </TouchableOpacity>
            </View>
          </TouchableOpacity>
        )}
      />

      {/* Add Modal */}
      <Modal visible={showAddModal} transparent animationType="slide">
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}>
          <View style={{ backgroundColor: "white", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, maxHeight: "90%" }}>
            <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
              <Text style={{ fontSize: 18, fontWeight: "800", color: "#1A2332" }}>إضافة ملف للأرشيف</Text>
              <TouchableOpacity onPress={() => setShowAddModal(false)}>
                <MaterialIcons name="close" size={24} color="#6B7C93" />
              </TouchableOpacity>
            </View>
            <ScrollView showsVerticalScrollIndicator={false}>
              {/* File Picker */}
              <TouchableOpacity
                onPress={pickDocument}
                style={{ backgroundColor: "#F0F4F8", borderRadius: 14, padding: 16, alignItems: "center", marginBottom: 16, borderWidth: 2, borderColor: pickedFile ? "#27AE60" : "#E5E7EB", borderStyle: "dashed" }}
              >
                <MaterialIcons name={pickedFile ? "check-circle" : "upload-file"} size={36} color={pickedFile ? "#27AE60" : "#9BA1A6"} />
                <Text style={{ fontSize: 14, color: pickedFile ? "#27AE60" : "#6B7C93", marginTop: 8, fontWeight: pickedFile ? "700" : "400" }}>
                  {pickedFile ? pickedFile.name : "اضغط لاختيار ملف"}
                </Text>
                {pickedFile?.size && <Text style={{ fontSize: 11, color: "#9BA1A6", marginTop: 4 }}>{formatFileSize(pickedFile.size)}</Text>}
              </TouchableOpacity>

              {/* Category */}
              <Text style={{ fontSize: 13, color: "#6B7C93", textAlign: "right", marginBottom: 8 }}>الفئة</Text>
              <View style={{ flexDirection: "row-reverse", flexWrap: "wrap", gap: 8, marginBottom: 14 }}>
                {CATEGORIES.filter((c) => c.key !== "all").map((cat) => (
                  <TouchableOpacity
                    key={cat.key}
                    onPress={() => setCategory(cat.key)}
                    style={{ paddingHorizontal: 10, paddingVertical: 6, borderRadius: 8, backgroundColor: category === cat.key ? cat.color : "#F0F4F8" }}
                  >
                    <Text style={{ fontSize: 11, color: category === cat.key ? "white" : "#6B7C93" }}>{cat.label}</Text>
                  </TouchableOpacity>
                ))}
              </View>

              {/* Title */}
              <Text style={{ fontSize: 13, color: "#6B7C93", textAlign: "right", marginBottom: 6 }}>العنوان *</Text>
              <TextInput
                value={title}
                onChangeText={setTitle}
                placeholder="عنوان الملف"
                style={{ backgroundColor: "#F8FAFC", borderRadius: 10, padding: 12, fontSize: 14, textAlign: "right", borderWidth: 1, borderColor: "#E5E7EB", marginBottom: 12 }}
              />

              {/* Description */}
              <Text style={{ fontSize: 13, color: "#6B7C93", textAlign: "right", marginBottom: 6 }}>الوصف</Text>
              <TextInput
                value={description}
                onChangeText={setDescription}
                placeholder="وصف مختصر"
                multiline
                numberOfLines={3}
                textAlignVertical="top"
                style={{ backgroundColor: "#F8FAFC", borderRadius: 10, padding: 12, fontSize: 13, textAlign: "right", borderWidth: 1, borderColor: "#E5E7EB", marginBottom: 12, minHeight: 80 }}
              />

              {/* Vessel */}
              <Text style={{ fontSize: 13, color: "#6B7C93", textAlign: "right", marginBottom: 8 }}>السفينة المرتبطة</Text>
              <ScrollView horizontal showsHorizontalScrollIndicator={false} style={{ marginBottom: 14 }}>
                <View style={{ flexDirection: "row-reverse", gap: 8 }}>
                  <TouchableOpacity onPress={() => setSelectedVesselId(null)} style={{ paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8, backgroundColor: !selectedVesselId ? "#1E3A5F" : "#F0F4F8" }}>
                    <Text style={{ fontSize: 12, color: !selectedVesselId ? "white" : "#6B7C93" }}>بدون سفينة</Text>
                  </TouchableOpacity>
                  {vessels.map((v) => (
                    <TouchableOpacity key={v.id} onPress={() => setSelectedVesselId(v.id)} style={{ paddingHorizontal: 12, paddingVertical: 6, borderRadius: 8, backgroundColor: selectedVesselId === v.id ? "#1E3A5F" : "#F0F4F8" }}>
                      <Text style={{ fontSize: 12, color: selectedVesselId === v.id ? "white" : "#6B7C93" }}>{v.name}</Text>
                    </TouchableOpacity>
                  ))}
                </View>
              </ScrollView>

              {/* Tags */}
              <Text style={{ fontSize: 13, color: "#6B7C93", textAlign: "right", marginBottom: 6 }}>الوسوم (مفصولة بفاصلة)</Text>
              <TextInput
                value={tags}
                onChangeText={setTags}
                placeholder="مثال: عقد، 2026، مهم"
                style={{ backgroundColor: "#F8FAFC", borderRadius: 10, padding: 12, fontSize: 13, textAlign: "right", borderWidth: 1, borderColor: "#E5E7EB", marginBottom: 20 }}
              />

              <TouchableOpacity
                onPress={handleSave}
                disabled={isSaving}
                style={{ backgroundColor: "#1E3A5F", borderRadius: 14, paddingVertical: 16, alignItems: "center" }}
              >
                <Text style={{ color: "white", fontSize: 15, fontWeight: "700" }}>حفظ في الأرشيف</Text>
              </TouchableOpacity>
            </ScrollView>
          </View>
        </View>
      </Modal>

      {/* Detail Modal */}
      <Modal visible={showDetailModal} transparent animationType="slide">
        <View style={{ flex: 1, backgroundColor: "rgba(0,0,0,0.5)", justifyContent: "flex-end" }}>
          <View style={{ backgroundColor: "white", borderTopLeftRadius: 24, borderTopRightRadius: 24, padding: 24, maxHeight: "70%" }}>
            <View style={{ flexDirection: "row-reverse", justifyContent: "space-between", alignItems: "center", marginBottom: 20 }}>
              <Text style={{ fontSize: 16, fontWeight: "800", color: "#1A2332" }} numberOfLines={1}>{selectedItem?.title}</Text>
              <TouchableOpacity onPress={() => setShowDetailModal(false)}>
                <MaterialIcons name="close" size={24} color="#6B7C93" />
              </TouchableOpacity>
            </View>
            {selectedItem && (
              <ScrollView showsVerticalScrollIndicator={false}>
                {[
                  { label: "النوع", value: getRefTypeLabel(selectedItem.referenceType) },
                  { label: "الفئة", value: selectedItem.category || "-" },
                  { label: "السفينة", value: selectedItem.vesselName || "-" },
                  { label: "الوصف", value: selectedItem.description || "-" },
                  { label: "الوسوم", value: selectedItem.tags || "-" },
                  { label: "اسم الملف", value: selectedItem.fileName || "-" },
                  { label: "حجم الملف", value: formatFileSize(selectedItem.fileSize) || "-" },
                  { label: "أرشف بواسطة", value: selectedItem.archivedBy },
                  { label: "تاريخ الأرشفة", value: new Date(selectedItem.createdAt).toLocaleDateString("ar-SA") },
                ].map((row, idx) => (
                  <View key={idx} style={{ flexDirection: "row-reverse", justifyContent: "space-between", paddingVertical: 10, borderBottomWidth: 1, borderBottomColor: "#F0F4F8" }}>
                    <Text style={{ fontSize: 13, color: "#6B7C93" }}>{row.label}</Text>
                    <Text style={{ fontSize: 13, color: "#1A2332", fontWeight: "600", flex: 1, textAlign: "right", marginRight: 12 }}>{row.value}</Text>
                  </View>
                ))}
              </ScrollView>
            )}
          </View>
        </View>
      </Modal>
    </ScreenContainer>
  );
}
