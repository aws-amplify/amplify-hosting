# Database Schema Reference

## Overview

This document describes the complete database schema for the Vessel Management System. All tables use MySQL 8.0+ with InnoDB engine for ACID compliance and foreign key support.

## Core Tables

### users

Stores user account information and authentication data.

```sql
CREATE TABLE users (
  id INT PRIMARY KEY AUTO_INCREMENT,
  openId VARCHAR(64) NOT NULL UNIQUE,
  email VARCHAR(320) UNIQUE,
  name TEXT,
  role ENUM('admin', 'accountant', 'reviewer', 'user') DEFAULT 'user' NOT NULL,
  loginMethod VARCHAR(64),
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  lastSignedIn TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  isActive BOOLEAN DEFAULT TRUE,
  INDEX idx_openId (openId),
  INDEX idx_email (email),
  INDEX idx_role (role)
);
```

**Fields**:
- `id`: Unique user identifier
- `openId`: OAuth identifier from Manus
- `email`: User email address
- `name`: User full name
- `role`: User role (admin, accountant, reviewer, user)
- `loginMethod`: Authentication method (manus, oauth, etc.)
- `createdAt`: Account creation timestamp
- `updatedAt`: Last profile update
- `lastSignedIn`: Last login timestamp
- `isActive`: Account status

### vessels

Stores vessel information and metadata.

```sql
CREATE TABLE vessels (
  id INT PRIMARY KEY AUTO_INCREMENT,
  name VARCHAR(255) NOT NULL UNIQUE,
  type VARCHAR(100),
  grt INT,
  nrt INT,
  length DECIMAL(10,2),
  status ENUM('active', 'inactive', 'maintenance') DEFAULT 'active',
  createdBy INT NOT NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  FOREIGN KEY (createdBy) REFERENCES users(id),
  INDEX idx_name (name),
  INDEX idx_status (status),
  INDEX idx_createdAt (createdAt)
);
```

**Fields**:
- `id`: Unique vessel identifier
- `name`: Vessel name (unique)
- `type`: Vessel type (Tanker, Container, General Cargo, etc.)
- `grt`: Gross Registered Tonnage
- `nrt`: Net Registered Tonnage
- `length`: Vessel length in meters
- `status`: Operational status
- `createdBy`: User who created the record
- `createdAt`: Record creation timestamp
- `updatedAt`: Last modification timestamp

### invoices

Stores invoice records linked to vessels.

```sql
CREATE TABLE invoices (
  id INT PRIMARY KEY AUTO_INCREMENT,
  invoiceNum INT NOT NULL UNIQUE,
  vesselId INT NOT NULL,
  amountUsd DECIMAL(12,2) NOT NULL,
  feesUsd DECIMAL(10,2),
  feesLocal DECIMAL(12,2),
  status ENUM('paid', 'pending', 'overdue') DEFAULT 'pending',
  discrepancy DECIMAL(12,2),
  invoiceDate DATE NOT NULL,
  dueDate DATE,
  paidDate DATE,
  notes TEXT,
  createdBy INT NOT NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  FOREIGN KEY (vesselId) REFERENCES vessels(id),
  FOREIGN KEY (createdBy) REFERENCES users(id),
  INDEX idx_invoiceNum (invoiceNum),
  INDEX idx_vesselId (vesselId),
  INDEX idx_status (status),
  INDEX idx_invoiceDate (invoiceDate),
  INDEX idx_createdAt (createdAt)
);
```

**Fields**:
- `id`: Unique invoice identifier
- `invoiceNum`: Invoice number (unique)
- `vesselId`: Reference to vessel
- `amountUsd`: Invoice amount in USD
- `feesUsd`: Fees in USD
- `feesLocal`: Fees in local currency
- `status`: Invoice status (paid, pending, overdue)
- `discrepancy`: Calculated difference from external invoice
- `invoiceDate`: Invoice creation date
- `dueDate`: Payment due date
- `paidDate`: Payment received date
- `notes`: Additional notes
- `createdBy`: User who created invoice
- `createdAt`: Record creation timestamp
- `updatedAt`: Last modification timestamp

### memos

Stores internal memos and communications.

```sql
CREATE TABLE memos (
  id INT PRIMARY KEY AUTO_INCREMENT,
  vesselId INT NOT NULL,
  title VARCHAR(255) NOT NULL,
  content LONGTEXT NOT NULL,
  recipient VARCHAR(255),
  status ENUM('draft', 'sent', 'archived') DEFAULT 'draft',
  sentDate DATETIME,
  archivedDate DATETIME,
  createdBy INT NOT NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  updatedAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP NOT NULL,
  FOREIGN KEY (vesselId) REFERENCES vessels(id),
  FOREIGN KEY (createdBy) REFERENCES users(id),
  INDEX idx_vesselId (vesselId),
  INDEX idx_status (status),
  INDEX idx_createdAt (createdAt)
);
```

**Fields**:
- `id`: Unique memo identifier
- `vesselId`: Reference to vessel
- `title`: Memo title
- `content`: Memo content (supports long text)
- `recipient`: External recipient name
- `status`: Memo status (draft, sent, archived)
- `sentDate`: When memo was sent
- `archivedDate`: When memo was archived
- `createdBy`: User who created memo
- `createdAt`: Record creation timestamp
- `updatedAt`: Last modification timestamp

### archives

Stores archived documents and files.

```sql
CREATE TABLE archives (
  id INT PRIMARY KEY AUTO_INCREMENT,
  vesselId INT,
  invoiceId INT,
  memoId INT,
  fileName VARCHAR(255) NOT NULL,
  fileKey VARCHAR(500),
  fileUrl VARCHAR(1000),
  fileType VARCHAR(50),
  fileSize INT,
  documentType ENUM('invoice', 'memo', 'report', 'external', 'other') DEFAULT 'other',
  description TEXT,
  uploadedBy INT NOT NULL,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  FOREIGN KEY (vesselId) REFERENCES vessels(id),
  FOREIGN KEY (invoiceId) REFERENCES invoices(id),
  FOREIGN KEY (memoId) REFERENCES memos(id),
  FOREIGN KEY (uploadedBy) REFERENCES users(id),
  INDEX idx_vesselId (vesselId),
  INDEX idx_documentType (documentType),
  INDEX idx_createdAt (createdAt)
);
```

**Fields**:
- `id`: Unique archive entry identifier
- `vesselId`: Reference to vessel (optional)
- `invoiceId`: Reference to invoice (optional)
- `memoId`: Reference to memo (optional)
- `fileName`: Original file name
- `fileKey`: S3 storage key
- `fileUrl`: Public URL to file
- `fileType`: File MIME type
- `fileSize`: File size in bytes
- `documentType`: Type of document
- `description`: Document description
- `uploadedBy`: User who uploaded file
- `createdAt`: Upload timestamp

### audit_logs

Tracks all system operations for security and compliance.

```sql
CREATE TABLE audit_logs (
  id INT PRIMARY KEY AUTO_INCREMENT,
  userId INT NOT NULL,
  action VARCHAR(100) NOT NULL,
  resourceType VARCHAR(50),
  resourceId INT,
  details JSON,
  status ENUM('success', 'failure') DEFAULT 'success',
  ipAddress VARCHAR(45),
  userAgent TEXT,
  createdAt TIMESTAMP DEFAULT CURRENT_TIMESTAMP NOT NULL,
  FOREIGN KEY (userId) REFERENCES users(id),
  INDEX idx_userId (userId),
  INDEX idx_action (action),
  INDEX idx_createdAt (createdAt)
);
```

**Fields**:
- `id`: Unique log entry identifier
- `userId`: User who performed action
- `action`: Action type (CREATE, UPDATE, DELETE, etc.)
- `resourceType`: Type of resource affected
- `resourceId`: ID of affected resource
- `details`: Additional details in JSON format
- `status`: Operation status
- `ipAddress`: User IP address
- `userAgent`: Browser/client information
- `createdAt`: Action timestamp

## Relationship Diagram

```
users (1) ──────────────── (many) vessels
  │                           │
  │                           ├──────────── (many) invoices
  │                           │
  │                           └──────────── (many) memos
  │                                           │
  │                                           └──────────── (many) archives
  │
  ├──────────────────────────────────────────────────────── (many) audit_logs
  │
  └──────────────────────────────────────────────────────── (many) archives
```

## Indexes and Performance

### Primary Indexes (Automatic)
- All primary keys are indexed

### Secondary Indexes
- `users.openId` - OAuth lookups
- `users.email` - Email-based searches
- `users.role` - Role-based filtering
- `vessels.name` - Vessel name searches
- `vessels.status` - Status filtering
- `invoices.invoiceNum` - Invoice number lookups
- `invoices.vesselId` - Vessel-based queries
- `invoices.status` - Status filtering
- `memos.vesselId` - Vessel-based queries
- `memos.status` - Status filtering
- `archives.documentType` - Document type filtering
- `audit_logs.userId` - User activity tracking
- `audit_logs.action` - Action type filtering

### Query Performance Tips

1. **Always use indexes**: Filter by indexed columns when possible
2. **Batch Operations**: Use batch inserts for bulk imports
3. **Pagination**: Implement pagination for large result sets
4. **Caching**: Cache frequently accessed data
5. **Archival**: Archive old records to maintain performance

## Data Types and Constraints

### String Fields
- `VARCHAR(255)`: Standard text fields (names, titles)
- `VARCHAR(320)`: Email addresses
- `VARCHAR(500)`: File paths and URLs
- `TEXT`: Long text content
- `LONGTEXT`: Very long content (memos, descriptions)

### Numeric Fields
- `INT`: Whole numbers (IDs, counts, tonnage)
- `DECIMAL(12,2)`: Currency amounts (USD)
- `DECIMAL(10,2)`: Smaller currency amounts (fees)

### Date/Time Fields
- `DATE`: Date only (YYYY-MM-DD)
- `DATETIME`: Date and time
- `TIMESTAMP`: Automatic timestamps

### Enum Fields
- `role`: admin, accountant, reviewer, user
- `status`: Various status values depending on table
- `documentType`: invoice, memo, report, external, other

## Backup and Recovery

### Backup Strategy
- Daily automated backups
- Weekly full backups
- Monthly archive backups
- Backup retention: 90 days

### Recovery Procedures
1. Identify backup date needed
2. Restore from backup
3. Verify data integrity
4. Notify users of recovery

## Migration and Updates

When modifying schema:

1. **Create Migration Script**: Write SQL migration
2. **Test in Development**: Verify changes work
3. **Schedule Maintenance**: Plan downtime if needed
4. **Backup Before Migration**: Always backup first
5. **Execute Migration**: Run on production
6. **Verify Results**: Check data integrity
7. **Document Changes**: Update this schema document

## Example Queries

### Get all invoices for a vessel
```sql
SELECT i.* FROM invoices i
JOIN vessels v ON i.vesselId = v.id
WHERE v.name = 'BREEZE'
ORDER BY i.invoiceDate DESC;
```

### Get pending invoices by user
```sql
SELECT i.* FROM invoices i
WHERE i.status = 'pending'
AND i.createdBy = ?
ORDER BY i.dueDate ASC;
```

### Get user activity log
```sql
SELECT * FROM audit_logs
WHERE userId = ?
ORDER BY createdAt DESC
LIMIT 100;
```

### Calculate total revenue
```sql
SELECT 
  DATE_TRUNC(invoiceDate, MONTH) as month,
  SUM(amountUsd) as total
FROM invoices
WHERE status = 'paid'
GROUP BY month
ORDER BY month DESC;
```

## Security Considerations

1. **Encryption**: Sensitive fields encrypted at rest
2. **Access Control**: Row-level security based on user role
3. **Audit Trail**: All modifications logged
4. **Data Retention**: Old data archived after 2 years
5. **GDPR Compliance**: User data deletion procedures
6. **PCI Compliance**: Payment information handling
